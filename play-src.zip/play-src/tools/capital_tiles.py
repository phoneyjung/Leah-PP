from PIL import Image,ImageDraw,ImageFont
from collections import Counter,deque
im=Image.open('/home/claude/capital/v41_full.png').convert('RGB');px=im.load()
W,H,T=96,64,32
hexs=lambda h:tuple(int(h[i:i+2],16) for i in (1,3,5))
WATER={hexs(c) for c in ['#4f78c0','#3d5a9a','#7fb6d8','#e9f4ff']};WALL={hexs(c) for c in ['#d9c7a0','#a8926a']}
GREEN={hexs(c) for c in ['#3f7a3a','#2c5a2a','#c05a8a']};GRASS={(0x5f,0x8a,0x47),(0x6f,0x9a,0x52),(0x7a,0xa6,0x5c)}
OPEN={hexs(c) for c in ['#e8dcc0','#efe4c8','#cdb88f','#f1e6cc','#8c6a4a','#f0dcae','#eadcc4','#f3e6cc','#b8862e','#9a6fb0','#c86a8a','#4f9ad8','#c9a0d8','#d9a0c0','#9a6b3f','#6b4a2a','#f2e3b3','#e07a5f']}
def cat(c):
    if c in WATER:return 'water'
    if c in WALL:return 'wall'
    if c in GREEN:return 'green'
    if c in GRASS:return 'grass'
    if c in OPEN:return 'open'
    return 'building'
cats=[[None]*W for _ in range(H)];cols=[[None]*W for _ in range(H)]
for ty in range(H):
    for tx in range(W):
        cc=Counter();ce=Counter()
        for yy in range(ty*T+1,ty*T+T,3):
            for xx in range(tx*T+1,tx*T+T,3):
                c=px[xx,yy];k=cat(c);cc[k]+=1;ce[(k,c)]+=1
        solid=cc['water']+cc['wall']+cc['green']+cc['building'];walk=cc['open']+cc['grass']
        if walk>=solid:k='open' if cc['open']>=cc['grass'] else 'grass'
        else:k=max(['water','wall','green','building'],key=lambda q:cc[q])
        cats[ty][tx]=k;cols[ty][tx]=max([(n,c) for (kk,c),n in ce.items() if kk==k])[1]
SOLIDK={'water','wall','green','building'}
# walkable pockets closed in by trees/hedges become bushes (seen = walkable, so no hidden dead ends)
def bfs(start):
    seen={start};q=deque([start])
    while q:
        x,y=q.popleft()
        for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            nx,ny=x+dx,y+dy
            if 0<=nx<W and 0<=ny<H and cats[ny][nx] not in SOLIDK and (nx,ny) not in seen:seen.add((nx,ny));q.append((nx,ny))
    return seen
reach0=bfs((49,40))
for y in range(H):
    for x in range(W):
        if cats[y][x] not in SOLIDK and (x,y) not in reach0:cats[y][x]='green';cols[y][x]=(0x3f,0x7a,0x3a)
grid=[''.join('1' if cats[y][x] in SOLIDK else '0' for x in range(W)) for y in range(H)]
open('/home/claude/capital/grid41.txt','w').write('\n'.join(grid))
# tile-aligned picture: exactly what collides is what you see
S=16;out=Image.new('RGB',(W*S,H*S));d=ImageDraw.Draw(out)
for y in range(H):
    for x in range(W):
        k=cats[y][x];c=cols[y][x];x0,y0=x*S,y*S
        if k=='grass':c=(0x6f,0x9a,0x52) if (x+y)%2 else (0x6a,0x95,0x4e)
        d.rectangle([x0,y0,x0+S-1,y0+S-1],fill=c)
        if k=='green':d.rectangle([x0,y0,x0+S-1,y0+S-1],fill=(0x5f,0x8a,0x47));d.ellipse([x0+1,y0+1,x0+S-2,y0+S-2],fill=c,outline=(0x2c,0x5a,0x2a))
        if k=='wall':d.line([(x0,y0+S//2),(x0+S,y0+S//2)],fill=(0xa8,0x92,0x6a));d.line([(x0+S//2,y0),(x0+S//2,y0+S//2)],fill=(0xa8,0x92,0x6a))
        if k=='water' and (x*7+y*3)%9==0:d.line([(x0+3,y0+S//2),(x0+S-4,y0+S//2)],fill=(0x8f,0xb0,0xe8))
# outlines around buildings and water edges
for y in range(H):
    for x in range(W):
        if cats[y][x] in ('building','water'):
            for dx,dy,seg in [(1,0,((S-1,0),(S-1,S-1))),(-1,0,((0,0),(0,S-1))),(0,1,((0,S-1),(S-1,S-1))),(0,-1,((0,0),(S-1,0)))]:
                nx,ny=x+dx,y+dy
                if 0<=nx<W and 0<=ny<H and cats[ny][nx]!=cats[y][x]:
                    (a,b),(c2,e)=seg;d.line([(x*S+a,y*S+b),(x*S+c2,y*S+e)],fill=(0x3a,0x1e,0x3f),width=2)
# stairs on the wall rows where the walls open
wall_rows=[y for y in range(H) if sum(1 for x in range(W) if cats[y][x]=='wall')>20]
for y in wall_rows:
    for x in range(W):
        if cats[y][x]!='wall' and ((x>0 and cats[y][x-1]=='wall') or (x<W-1 and cats[y][x+1]=='wall') or any(cats[y][xx]=='wall' for xx in range(max(0,x-6),min(W,x+7)))):
            for k2 in range(1,4):d.line([(x*S,y*S+k2*4),(x*S+S,y*S+k2*4)],fill=(0x8c,0x7a,0x5a))
f=ImageFont.truetype('/usr/share/fonts/opentype/tlwg/Loma-Bold.otf',15)
k=96/72;X=lambda v:v*k;Y=lambda v:v*64/48;cx,cy=X(36.5),Y(25)
labels=[('Lantern Academy',96*0.618,Y(5.5)),('วิหารตะเกียงแรก',X(8),Y(5)),('หอสมาคมอาชีพ',X(65.5),Y(5.5)),('ศาลโคม',cx+13,cy-10),('กระดาน',cx-13,cy-10),
 ('บ้าน',X(6),Y(17.5)),('บ้าน',X(6),Y(30.5)),('ร้านอาหาร',X(14),Y(30.5)),('ตลาด',X(57),Y(17.5)),('ตีเหล็ก',X(67.5),Y(17.5)),('ไปรษณีย์+คลัง',X(55.5),Y(30.5)),('บ้าน',X(66),Y(30.5)),
 ('สวน ศาลา',X(13),Y(35)),('ลานฝึก',X(56),Y(35)),('ลานเทศกาล',56,54.5),('ถนนตั้งแผง',78.5,33.3),('ลานถ่ายรูป',96*0.618,15.6),('จุดนัดพบ',cx,cy+6),('สวนผลไม้',36,6),('ศาลาริมน้ำ',6,54.5),('สนามเด็กเล่น',86.5,56.5),('ประตูเหนือ',cx,1.2)]
for t,x,y in labels:
    tw=d.textlength(t,font=f);d.rectangle([x*S-tw/2-4,y*S-10,x*S+tw/2+4,y*S+10],fill=(20,14,36));d.text((x*S-tw/2,y*S-9),t,font=f,fill='#ffe7b0')
out.save('/mnt/user-data/outputs/capital-greybox.png',optimize=True)
# checks: every walkable tile reachable from the meeting spot; every road/zone tile walkable
start=(49,40);seen={start};q=deque([start])
while q:
    x,y=q.popleft()
    for dx,dy in [(1,0),(-1,0),(0,1),(0,-1)]:
        nx,ny=x+dx,y+dy
        if 0<=nx<W and 0<=ny<H and grid[ny][nx]=='0' and (nx,ny) not in seen:seen.add((nx,ny));q.append((nx,ny))
walk=sum(r.count('0') for r in grid);print('walkable',walk,'reachable',len(seen),'unreachable pockets',walk-len(seen))
unre=[(x,y) for y in range(H) for x in range(W) if grid[y][x]=='0' and (x,y) not in seen];print('pockets sample',unre[:12])
ends={'NW end':(16,12),'NE end':(80,12),'SW end':(39,48),'SE end':(76,50.7),'north gate':(48,0),'orchard':(32,7),'playground':(86,56),'pavilion':(6,57),'west gate':(0,33),'east gate':(95,33),'pier':(48,63),'festival':(55,54),'academy terrace':(59,16),'market street':(80,31)}
for n,(x,y) in ends.items():
    t=(int(x),int(y));ok=t in seen or any((t[0]+a,t[1]+b) in seen for a in (-1,0,1) for b in (-1,0,1));print(f'{n:16s} reachable {ok}')
