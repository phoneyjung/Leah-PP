import numpy as np,colorsys
from PIL import Image
def rgb2hsv(a):
    r,g,b=a[...,0],a[...,1],a[...,2];mx=a.max(-1);mn=a.min(-1);d=mx-mn;h=np.zeros_like(mx)
    m=d>0;rm=(mx==r)&m;gm=(mx==g)&m&~rm;bm=m&~rm&~gm
    h[rm]=((g-b)[rm]/d[rm])%6;h[gm]=(b-r)[gm]/d[gm]+2;h[bm]=(r-g)[bm]/d[bm]+4;h=h*60
    s=np.where(mx>0,d/np.maximum(mx,1e-6),0);return h,s,mx
def hsv2rgb(h,s,v):
    h=(h%360)/60;i=np.floor(h).astype(int)%6;f=h-np.floor(h);p=v*(1-s);q=v*(1-s*f);t=v*(1-s*(1-f))
    out=np.zeros(h.shape+(3,));
    for k,(a,b,c) in enumerate([(v,t,p),(q,v,p),(p,v,t),(p,q,v),(t,p,v),(v,p,q)]):
        m=i==k;out[...,0][m]=a[m];out[...,1][m]=b[m];out[...,2][m]=c[m]
    return out
def la_grade(img,strength=1.0):
    a=np.asarray(img.convert('RGB'),dtype=float)/255;h,s,v=rgb2hsv(a)
    # 1) less yellow wash on grass: a bit less saturated and a touch greener
    yg=(h>=45)&(h<110)&(s>.3);s=np.where(yg,s*(1-.22*strength),s);h=np.where(yg,h+6*strength,h)
    # 2) golden glow on the ground becomes warm cream (lanterns = the very brightest stay gold)
    gl=(h>=28)&(h<72)&(s>.45)&(v>.55)&(v<.93);s=np.where(gl,s*(1-.38*strength),s)
    # 2b) sandy paths lean cream (they were close to the lantern-gold signal)
    pa=(h>=20)&(h<45)&(s>.3)&(v>.55);s=np.where(pa,s*(1-.25*strength),s)
    # 3) very saturated cyan water calmer and a little deeper (cyan is the crystal signal)
    cy=(h>=175)&(h<210)&(s>.45);s=np.where(cy,s*(1-.2*strength),s);h=np.where(cy,h+10*strength,h)
    out=hsv2rgb(h,s,v)
    # 4) LA family: shadows lean dusk violet, highlights lean warm cream (split toning)
    L=out@np.array([.3,.59,.11]);tsh=np.clip((.55-L)/.55,0,1)[...,None]*strength;thi=np.clip((L-.72)/.28,0,1)[...,None]*strength
    out=out*(1+tsh*(np.array([.84,.74,1.16])-1)*1.15)
    h2,s2,_=rgb2hsv(out);warm=((h2<40)|(h2>300)|(s2<.2))[...,None]  # warm only skin/wood/stone highlights, not yellow grass
    out=out*(1+thi*warm*(np.array([1.03,1.0,.95])-1))
    return Image.fromarray((np.clip(out,0,1)*255).astype('uint8'))
