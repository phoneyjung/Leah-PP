from PIL import Image,ImageDraw,ImageFont
import random,sys
T=32
B='/usr/share/fonts/opentype/tlwg/Loma-Bold.otf';R='/usr/share/fonts/opentype/tlwg/Loma.otf'
GRASS=[(0x5f,0x8a,0x47),(0x6f,0x9a,0x52),(0x7a,0xa6,0x5c)]
def build(W,H,labels,plazaR):
    k=W/72  # positions spread with the map; sizes (roads, buildings) stay the same
    X=lambda v:v*k;Y=lambda v:v*H/48
    im=Image.new('RGB',(W*T,H*T),GRASS[1]);d=ImageDraw.Draw(im)
    F=ImageFont.truetype(B,34);f=ImageFont.truetype(R,26)
    def R_(x0,y0,x1,y1,c,o=None,w=0):d.rectangle([x0*T,y0*T,x1*T,y1*T],fill=c,outline=o,width=w)
    top=Y(14);low=Y(33.5);lake=H-4.5
    R_(0,0,W,top,GRASS[0]);R_(0,low,W,lake,GRASS[2])
    road='#e8dcc0';cx,cy=X(36.5),Y(25)
    R_(0,cy-2.5,W,cy+2.5,road);R_(cx-2.5,top,cx+2.5,lake,road)
    nx=X(28.5);R_(nx-2.5,0,nx+2.5,top,road);R_(nx-2.5,top-3,cx+2.5,top,road)
    ax=W*0.618;R_(ax-2.5,Y(10),ax+2.5,top+2,road)
    for (tx,ty) in [(X(12),Y(9)),(X(60),Y(9)),(X(15),Y(38)),(X(57),Y(38))]:
        for i in range(81):x=cx+(tx-cx)*i/80;y=cy+(ty-cy)*i/80;d.ellipse([x*T-64,y*T-64,x*T+64,y*T+64],fill=road)
    py=Y(37.5);R_(X(5),py-2,W-X(5),py+2,road)
    d.ellipse([(cx-plazaR)*T,(cy-plazaR)*T,(cx+plazaR)*T,(cy+plazaR)*T],fill='#efe4c8',outline='#cdb88f',width=6);d.ellipse([(cx-3)*T,(cy-3)*T,(cx+3)*T,(cy+3)*T],fill='#7fb6d8',outline='#e9f4ff',width=6)
    # walls with stairs where avenues cross
    gaps_top=[(nx-2.5,nx+2.5),(cx-2.5,cx+2.5),(ax-2.5,ax+2.5),(X(12)-2,X(12)+2)];gaps_low=[(cx-2.5,cx+2.5),(X(57)-2,X(57)+2),(X(15)-2,X(15)+2)]
    for xx in range(int(W)):
        if not any(a<=xx+.5<=b for a,b in gaps_top):R_(xx,top-.5,xx+1,top+.5,'#d9c7a0','#a8926a',2)
        if not any(a<=xx+.5<=b for a,b in gaps_low):R_(xx,low-.5,xx+1,low+.5,'#d9c7a0','#a8926a',2)
    pts=[(X(17),0),(X(17.5),Y(5)),(X(19),Y(11)),(X(20.5),Y(17)),(X(22.5),Y(24)),(X(25),Y(31)),(X(27.5),Y(38)),(X(30),H-3)]
    for i in range(len(pts)-1):
        (a,b),(c,e)=pts[i],pts[i+1]
        for s in range(41):x=a+(c-a)*s/40;y=b+(e-b)*s/40;d.ellipse([x*T-46,y*T-46,x*T+46,y*T+46],fill='#4f78c0')
    def lerp(t):
        # point on the canal polyline nearest to height t
        for (a,b),(c,e) in zip(pts,pts[1:]):
            if b<=t<=e:return a+(c-a)*(t-b)/(e-b+1e-9)
        return pts[-1][0]
    for yy in [top-1.5,cy,py]:bx=lerp(yy);d.rectangle([(bx-3)*T,(yy-2.3)*T,(bx+3)*T,(yy+2.3)*T],fill='#f1e6cc',outline='#8c6a4a',width=5)
    R_(0,lake,W,H,'#3d5a9a');R_(cx-3.5,lake-3,cx+3.5,H,'#9a6b3f')
    # buildings keep their real size (tiles) and are placed around the spread-out plan
    bl=[('Lantern Academy',W*0.618,Y(5.5),18,10,'#a0522d'),('วิหารตะเกียงแรก',X(8),Y(5),12,9,'#8e5a3a'),('หอสมาคมอาชีพ',X(65.5),Y(5.5),11,8,'#8b5e3c'),
        ('ศาลโคม',cx+plazaR+1,cy-plazaR+2,5,4,'#b0643c'),('กระดาน',cx-plazaR-1,cy-plazaR+2,3,3,'#7a5230'),
        ('บ้านล้านนา',X(6),Y(17.5),7,6,'#9c5a3c'),('บ้านล้านนา',X(6),Y(30.5),7,6,'#9c5a3c'),('ร้านอาหาร',X(14),Y(30.5),7,5,'#b86a3a'),
        ('ตลาด',X(57),Y(17.5),13,6,'#8a4f8f'),('ตีเหล็ก',X(67.5),Y(17.5),6,6,'#6d6d7a'),('ไปรษณีย์+คลัง',X(55.5),Y(30.5),10,5,'#7a6a4a'),('บ้านล้านนา',X(66),Y(30.5),7,6,'#9c5a3c'),
        ('สวน ศาลา',X(13),Y(35),14,2.5,'#6aa64a'),('ลานฝึก',X(56),Y(35),16,2.5,'#c9a46b')]
    for name,bx,by,bw,bh,c in bl:
        R_(bx-bw/2,by-bh/2,bx+bw/2,by+bh/2,c,'#3a1e3f',4)
        if labels:tw=d.textlength(name,font=f);d.rectangle([bx*T-tw/2-6,by*T-18,bx*T+tw/2+6,by*T+18],fill=(20,14,36));d.text((bx*T-tw/2,by*T-16),name,font=f,fill='#ffe7b0')
    zones=[('ลานเทศกาลโคม · เวทีตอบคำถาม',43,51,69,58,'#f0dcae','#b8862e'),('ถนนตั้งแผง (ตลาดนัดผู้เล่น)',62,29.5,95,37,'#eadcc4','#9a6fb0'),
           ('ลานหน้า Academy · ซุ้มถ่ายรูปรวม',W*0.618-10,13,W*0.618+10,18.2,'#f3e6cc','#c86a8a'),('จุดนัดพบ น้ำพุ',cx-6,cy+4,cx+6,cy+8,'#efe4c8','#4f9ad8')]
    if W==96:
        for name,x0,y0,x1,y1,c,o in zones:
            R_(x0,y0,x1,y1,c,o,6)
        # stage, photo arch, stall slots, meeting board
        R_(65,51.5,69,57.5,'#b86a3a','#3a1e3f',4)                  # stage at the east end of the festival square (the canal runs along the west side)
        R_(W*0.618-1.5,13.2,W*0.618+1.5,15,'#d9a0c0','#3a1e3f',4)  # photo arch in front of the Academy
        for i in range(8):
            for yy in (29.8,35.2):R_(64+i*4,yy,66+i*4,yy+1.8,'#c9a0d8','#3a1e3f',2)   # 16 stall slots along the street
        R_(cx+5,cy+5,cx+6.5,cy+7,'#7a5230','#3a1e3f',3)            # meeting board by the fountain
        if labels:
            for name,x0,y0,x1,y1,c,o in zones:
                tw=d.textlength(name,font=f);mx=(x0+x1)/2*T;my=(y0+y1)/2*T;d.rectangle([mx-tw/2-6,my-18,mx+tw/2+6,my+18],fill=o);d.text((mx-tw/2,my-16),name,font=f,fill='#ffffff')
    if W==96:
        for name,bx,by,bw,bh,c in bl:
            if bh>3:R_(bx-bw/2,by+bh/2,bx+bw/2,by+bh/2+1.2,'#c05a8a','#2c5a2a',2)   # flower bed in front of the building
            if bw>6:R_(bx-bw/2-1.4,by-bh/2,bx-bw/2-0.2,by+bh/2,'#3f7a3a','#2c5a2a',2);R_(bx+bw/2+0.2,by-bh/2,bx+bw/2+1.4,by+bh/2,'#3f7a3a','#2c5a2a',2)  # hedges beside it
    random.seed(7)
    for _ in range(int(420*k*k)):
        x=random.uniform(0,W);y=random.uniform(0,lake-1)
        if any(bx-bw/2-1<=x<=bx+bw/2+1 and by-bh/2-1<=y<=by+bh/2+2 for _,bx,by,bw,bh,_ in bl):continue
        if W==96 and any(x0-1<=x<=x1+1 and y0-1<=y<=y1+1 for _,x0,y0,x1,y1,_,_ in zones):continue
        c=im.getpixel((int(min(W*T-1,x*T)),int(min(H*T-1,y*T))))
        if c in GRASS:d.ellipse([x*T-22,y*T-22,x*T+22,y*T+22],fill='#3f7a3a',outline='#2c5a2a',width=2)
    # walkable share: roads, plaza and open grass (not buildings, trees, water, walls)
    small=im.resize((W*4,H*4),Image.NEAREST);px=list(small.getdata())
    walk=sum(1 for c in px if c in GRASS or c in [(0xe8,0xdc,0xc0),(0xef,0xe4,0xc8),(0xf1,0xe6,0xcc),(0xf0,0xdc,0xae),(0xea,0xdc,0xc4),(0xf3,0xe6,0xcc)])/len(px)
    return im,walk
out={}
for (W,H,pr) in [(72,48,10),(96,64,12)]:
    im,walk=build(W,H,True,pr);out[(W,H)]=(im,walk)
    print(f'{W}x{H}: walkable {walk*100:.0f}% · walk across {W*32/100:.0f} s at walking speed')
a,wa=out[(72,48)];b,wb=out[(96,64)]
F=ImageFont.truetype(B,40)
# show both at the same on-screen size to compare density
aw=1152;A=a.resize((aw,int(aw*a.height/a.width)));Bi=b.resize((aw,int(aw*b.height/b.width)))
o=Image.new('RGB',(aw*2+30,A.height+70),'#1b1330');o.paste(A,(0,70));o.paste(Bi,(aw+30,70));d=ImageDraw.Draw(o)
d.text((10,10),f'v2 · 72×48 ช่อง · เดินได้ {wa*100:.0f}%',font=F,fill='#ffe7b0');d.text((aw+40,10),f'v3 · 96×64 ช่อง · เดินได้ {wb*100:.0f}%',font=F,fill='#b8f5a8')
o.save('/mnt/user-data/outputs/capital-v2-vs-v3.png')
b.save('/mnt/user-data/outputs/capital-blueprint-v3.png')
bc,_=build(96,64,False,12);bc.resize((1536,1024),Image.LANCZOS).save('/mnt/user-data/outputs/capital-blueprint-v3-clean.png')
print('saved')
