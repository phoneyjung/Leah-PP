# World overview V.1 · five maps on one hillside, drawn in the LA palette and measured for 60-30-10
from PIL import Image,ImageDraw
import math,random,sys
sys.path.insert(0,'/home/claude/capital');import bp51
C=dict(bp51.C);C['rock']=(0x5d,0x50,0x88);T=8;W,H=96,64
def base(seed,mount,c3,c2,shore,has_mount=True):
    im=Image.new('RGB',(W*T,H*T),C['t2']);d=ImageDraw.Draw(im)
    for px in range(W*T):
        x=px/T
        if has_mount:d.line([(px,0),(px,mount(x)*T)],fill=C['mount']);d.line([(px,(mount(x)*.4)*T),(px,(mount(x)*.4+.6)*T)],fill=C['ridge'])
        d.line([(px,mount(x)*T if has_mount else 0),(px,c3(x)*T)],fill=C['t3']);d.line([(px,c3(x)*T),(px,c2(x)*T)],fill=C['t2']);d.line([(px,c2(x)*T),(px,shore(x)*T)],fill=C['t1'])
        d.line([(px,shore(x)*T),(px,H*T)],fill=C['lake'])
        for e in (c3(x),c2(x)):d.line([(px,e*T),(px,(e+1.7)*T)],fill=C['face']);d.line([(px,(e+1.7)*T),(px,(e+2.3)*T)],fill=C['shadow'])
    return im,d
def blob(d,x,y,r,col):d.ellipse([x*T-r*T,y*T-r*T,x*T+r*T,y*T+r*T],fill=col)
def path(d,pts,w,col=None):
    col=col or C['road']
    for (a,b),(c,e) in zip(pts,pts[1:]):
        n=int(max(abs(c-a),abs(e-b))*2)+1
        for k in range(n+1):blob(d,a+(c-a)*k/n,b+(e-b)*k/n,w/2,col)
def lamp(d,x,y):blob(d,x,y,1.5,(0xff,0xd6,0x82));blob(d,x,y,.45,C['gold'])
def trees(im,d,n,seed,ok=None):
    random.seed(seed)
    for _ in range(n):
        x=random.uniform(0,W);y=random.uniform(0,H)
        c=im.getpixel((int(x*T)%(W*T),int(min(H*T-1,y*T))))
        if c in (C['t3'],C['t2'],C['t1']):r=random.uniform(.6,.85);blob(d,x+.5,y+.45,r+.1,C['shadow']);blob(d,x,y,r,C['treeD']);blob(d,x,y-.15,r-.18,C['tree'])
def house(d,bx,by,bw,bh,door=True):
    d.rectangle([(bx-bw/2+.9)*T,(by+bh/2)*T,(bx+bw/2+.9)*T,(by+bh/2+1.5)*T],fill=C['shadow'])
    d.rectangle([(bx-bw/2)*T,(by-bh/2)*T,(bx+bw/2)*T,(by+bh/2)*T],fill=C['roof'],outline=C['shadow'],width=2)
    d.rectangle([(bx-bw/2)*T,(by+bh/2-1.1)*T,(bx+bw/2)*T,(by+bh/2)*T],fill=C['teak'])
    wx=bx-bw/2+.8
    while wx<bx+bw/2-.8:
        if abs(wx-bx)>1.3:d.rectangle([wx*T,(by+bh/2-1.0)*T,(wx+.9)*T,(by+bh/2-.25)*T],fill=(0xff,0xd6,0x82))
        wx+=1.5
    if door:d.rectangle([(bx-.9)*T,(by+bh/2-.9)*T,(bx+.9)*T,by*T+bh/2*T],fill=C['gold'])
S=lambda f:f  # helper
# ---------------- north: source & crystal cave (highest map: peaks fill more, terraces higher)
def north():
    mount=lambda x:18+3*math.sin(x/9)+1.5*math.sin(x/3.4);c3=lambda x:34+2*math.sin(x/12+1);c2=lambda x:48+1.8*math.sin(x/10+2);shore=lambda x:70
    im,d=base(1,mount,c3,c2,shore)
    d.rectangle([18*T,0,23*T,mount(20)*T+T],fill=C['fall']);blob(d,20.5,mount(20)+6,6.5,C['stream'])          # big waterfall + source pool
    d.rectangle([26*T,(mount(20)+5.5)*T,33*T,(mount(20)+6.6)*T],fill=C['teak']);lamp(d,33.2,mount(20)+6)      # fishing dock
    path(d,[(20,mount(20)+11),(18,40),(15,52),(15,64)],3.4,C['stream'])                                        # river to the capital's waterfall (x≈15)
    for e in (c3(17),c2(15.5)):d.rectangle([14*T,e*T,19*T,(e+2.2)*T],fill=C['fall'])
    blob(d,52,mount(52)-.6,3.2,C['cave']);lamp(d,47.5,mount(52)+1);lamp(d,56.5,mount(52)+1)                     # crystal cave with lanterns
    path(d,[(48,64),(48,40),(52,mount(52)+2)],5);path(d,[(52,28),(70,27),(96,26)],4)                           # gorge road up to the cave · road east
    d.rectangle([80*T,23.5*T,84*T,29*T],fill=C['rock']);d.line([(80*T,23.5*T),(84*T,29*T)],fill=C['gold'],width=3);d.line([(84*T,23.5*T),(80*T,29*T)],fill=C['gold'],width=3)   # rockfall + lantern seal (closed)
    for e,x in [(c3(48),48),(c2(48),48)]:d.rectangle([(x-2.5)*T,e*T,(x+2.5)*T,(e+2.2)*T],fill=C['stair'])
    for y in (36,44,56):lamp(d,44.7,y);lamp(d,51.3,y)
    for x,y in [(49,mount(52)+.4),(55,mount(52)+.4),(51.5,mount(52)+1.6)]:blob(d,x,y,.9,C['cyan'])
    for x,y in [(30,44),(72,36),(80,48),(38,56)]:blob(d,x,y,1.3,(0xff,0xd6,0x82));blob(d,x,y,.5,C['gold'])
    house(d,62,40,6,4)   # wizard teacher's hut
    for x,y in [(24,mount(20)+11),(14,mount(20)+4),(27,mount(20)+2),(60,27.5),(68,27),(76,26.5),(58,44),(66,45),(36,40),(28,48),(20,56),(10,50)]:lamp(d,x,y)
    trees(im,d,250,5);return im
# ---------------- capital: the v5.1 plan
def capital():
    return Image.open('/home/claude/capital/v51_full.png').convert('RGB').resize((W*T,H*T),Image.NEAREST)
# ---------------- west: my farm
GM=lambda x:6.6+1.5*math.sin(x/8.5)+0.8*math.sin(x/3.3+1)
def farm():
    o=-96;mount=lambda x:GM(x+o);c3=lambda x:bp51.c3(x+o);c2=lambda x:bp51.c2(x+o);shore=lambda x:bp51.shore(x+o)
    im,d=base(2,mount,c3,c2,shore)
    random.seed(4)
    for _ in range(105):x=random.uniform(2,94);y=random.uniform(mount(x)+1,c3(x)-1);blob(d,x,y,random.uniform(.9,1.5),C['treeD'])           # wild land on the top terrace
    for _ in range(60):x=random.uniform(4,92);y=random.uniform(mount(x)+1,c3(x)-1);blob(d,x,y,.5,C['rock'])
    for row in range(3):                                                                                             # terraced fields (rice-terrace style)
        for i in range(6):
            x0=12+i*12;y0=c3(x0+5)+3.2+row*5.4
            d.rounded_rectangle([x0*T,y0*T,(x0+10)*T,(y0+4)*T],radius=8,fill=(0x8a,0x6a,0x42),outline=C['face'],width=2)
            for k in range(4):d.line([((x0+.6)*T,(y0+.8+k*.9)*T),((x0+9.4)*T,(y0+.8+k*.9)*T)],fill=(0x5c,0x96,0x46),width=3)
            if (row+i)%2==0:
                for k in range(8):blob(d,x0+1+k*1.1,y0+1.2+(k%3)*.9,.55,(0xff,0xd6,0x82));blob(d,x0+1+k*1.1,y0+1.2+(k%3)*.9,.25,C['gold'])   # ready to harvest
    path(d,[(8,64),(8,20)],3,C['stream']);path(d,[(8,24),(90,24.5)],1,C['stream'])                                 # stream + irrigation channel
    blob(d,70,52,6,C['stream']);d.ellipse([(70-6)*T,(52-4)*T,(70+6)*T,(52+4)*T],fill=C['stream'])                 # fish pond
    for k in range(7):lamp(d,66+k*1.4,51+(k%2))                                                                    # fish ready to collect
    house(d,40,50,9,6)                                                                                               # our house
    blob(d,56,49,4.2,C['shadow']);blob(d,55,47.5,3.8,C['treeD']);blob(d,55,47,3.3,C['tree']);d.rectangle([57*T,50*T,59*T,51*T],fill=C['teak'])  # big tree + swing
    path(d,[(96,29.6),(60,31),(40,33),(40,c2(40)-1)],4);d.rectangle([37.5*T,c2(40)*T,42.5*T,(c2(40)+2.2)*T],fill=C['stair']);path(d,[(40,c2(40)+2.2),(40,56),(40,57.4),(8,57.4)],3)
    for x in (14,26,38,50,62,74,86):lamp(d,x,c3(x)+2.6)
    for x in (20,32,52,62,82):lamp(d,x,c2(x)+3.4)
    for x,y in [(66,47),(76,55),(46,55),(30,57.4),(16,57.4)]:lamp(d,x,y)
    d.rectangle([80*T,45*T,86*T,50*T],fill=(0x9a,0x9a,0xb0));blob(d,83,44.2,1.2,C['gold'])                          # robot shed
    trees(im,d,160,6);return im
# ---------------- east: training valley
def field():
    o=96;mount=lambda x:GM(x+o);c3=lambda x:bp51.c3(x+o);c2=lambda x:bp51.c2(x+o);shore=lambda x:bp51.shore(x+o)
    im,d=base(3,mount,c3,c2,shore)
    ew0=bp51.C and (32-2.4)
    path(d,[(0,29.6),(20,31),(40,35),(60,34),(80,28),(88,c3(88)+3),(90,c3(90)-2),(92,10)],4)
    for x in (88.5,):d.rectangle([(x-2.5)*T,c3(x)*T,(x+2.5)*T,(c3(x)+2.2)*T],fill=C['stair'])                                             # valley road climbing east
    for x,y in [(30,28),(38,31),(46,29),(54,28)]:d.rectangle([x*T,y*T,(x+3)*T,(y+5)*T],fill=(0xb8,0xa8,0x8a),outline=C['shadow'],width=2)   # Lanna ruins (middle)
    for x,y in [(84,12),(88,8)]:d.rectangle([x*T,y*T,(x+4)*T,(y+3)*T],fill=C['rock'])
    blob(d,90,9,2.2,C['shadow']);d.text((86*T,6*T),'boss',fill=C['gold'])
    for x,y in [(6,33),(14,34),(24,34.5),(32,36.5),(44,38.5),(52,37.5),(62,37.5),(70,33.5),(78,31),(84,28.5),(86,24),(89,16),(28,32),(50,32)]:lamp(d,x,y)
    for x,y in [(18,50),(40,52),(66,48)]:d.rectangle([x*T,y*T,(x+2)*T,(y+2)*T],fill=(0x9a,0x86,0xa8))           # rest stones
    for x,y in [(12,27),(30,45),(48,26),(58,50),(72,40),(80,52),(20,52),(66,24),(90,34),(36,49)]:blob(d,x,y,1.3,(0xff,0xd6,0x82));d.rectangle([(x-.6)*T,(y-.4)*T,(x+.6)*T,(y+.4)*T],fill=C['gold'])   # chests and dig spots
    for x,y in [(18,24),(34,22),(58,21),(74,19),(26,40),(44,44),(64,44),(84,46)]:d.ellipse([(x-1.6)*T,(y-1.1)*T,(x+1.6)*T,(y+1.1)*T],fill=C['rock'])
    trees(im,d,560,7);return im
# ---------------- south: lotus lake & floating market (mostly water)
def south():
    im=Image.new('RGB',(W*T,H*T),C['lake']);d=ImageDraw.Draw(im)
    for py in range(H*T):y=py/T;l=5+1.5*math.sin(y/6);r=91-1.5*math.sin(y/7+1);d.line([(0,py),(l*T,py)],fill=C['t1']);d.line([(l*T,py),((l+1)*T,py)],fill=C['sand']);d.line([((r-1)*T,py),(r*T,py)],fill=C['sand']);d.line([(r*T,py),(W*T,py)],fill=C['t1'])
    d.rectangle([46*T,0,50*T,10*T],fill=C['teak'])                                                                   # the capital's pier continues
    random.seed(9)
    for _ in range(420):x=random.uniform(6,90);y=random.uniform(12,62);blob(d,x,y,1.1,(0x3f,0x7a,0x3a));blob(d,x,y-.2,.4,(0xf2,0x9a,0xc0))   # lotus beds
    for ix,iy,r in [(22,50,5),(84,20,4.5)]:blob(d,ix,iy,r,C['sand']);blob(d,ix,iy,r-.8,C['t1']);blob(d,ix+.4,iy+.4,r*.45,C['treeD'])   # small green islands
    for _ in range(26):x=random.uniform(10,86);y=random.uniform(34,62);lamp(d,x,y)   # floating lanterns and krathongs
    for pts in [[(48,10),(48,30),(20,30),(20,50)],[(48,30),(78,30),(84,20)],[(48,30),(48,46),(70,46)],[(10,40),(20,40)],[(78,30),(88,40)]]:path(d,pts,3.2,C['teak']);path(d,pts,2.2,(0xb8,0x8a,0x5a))
    for i in range(8):x=20+i*7;y=26+2*math.sin(i);d.rounded_rectangle([x*T,y*T,(x+5)*T,(y+2)*T],radius=6,fill=C['teak']);d.rectangle([(x+1)*T,(y-1)*T,(x+4)*T,y*T],fill=(0x8a,0x4f,0x8f));lamp(d,x+2.5,y-1.6)  # floating market boats
    blob(d,70,48,7,C['t2']);blob(d,70,48,6,C['t1']);house(d,70,46.5,5,3.6);lamp(d,66,50)                            # island shrine
    for x in range(10,90,9):blob(d,x+3,58,.7,C['gold'])                                                               # krathong lights
    return im
maps={'north':north(),'west':farm(),'capital':capital(),'east':field(),'south':south()}
for k,v in maps.items():v.save(f'/home/claude/world/{k}.png')
# composite overview
tw,th=W*T,H*T;gap=10
O=Image.new('RGB',(3*tw+2*gap,3*th+2*gap),(0x1b,0x13,0x30))
pos={'north':(1,0),'west':(0,1),'capital':(1,1),'east':(2,1),'south':(1,2)}
for k,(cx,cy) in pos.items():O.paste(maps[k],(cx*(tw+gap),cy*(th+gap)))
O.save('/mnt/user-data/outputs/world-overview-v1.png');O.resize((O.width//2,O.height//2)).save('/home/claude/chunks/world_overview.jpg',quality=85)
print('ok',O.size)
