# Capital v5.2 greybox: exact-colour plan -> tile categories -> collision grid + tile-aligned picture + game data (exits, spawn, board, NPC routes)
import sys,json,math
from collections import Counter,deque
from PIL import Image,ImageDraw,ImageFont
sys.path.insert(0,'/home/claude/capital');import bp52 as bp
C=bp.C;im=bp.build(False);px=im.load();BL=bp.build.BL
W,H,T=96,64,32
WALK={C[k] for k in ['t3','t2','t1','sand','road','plaza','bridge','stair','shadow','gold']}|{(0xff,0xd6,0x82),C['cave']}
WATER={C[k] for k in ['lake','stream','fall']}
cats=[[None]*W for _ in range(H)];cols=[[None]*W for _ in range(H)]
for ty in range(H):
    for tx in range(W):
        w=s=wt=0;cw=Counter();cs=Counter();cwt=Counter()
        for yy in range(ty*T+1,ty*T+T,3):
            for xx in range(tx*T+1,tx*T+T,3):
                c=px[xx,yy][:3]
                if c in WALK:w+=1;cw[c]+=1
                elif c in WATER:wt+=1;cwt[c]+=1
                else:s+=1;cs[c]+=1
        if 46<=tx<=49 and ty>=bp.shore(48)-.3:k='open';cw[C['teak']]+=99            # the pier is walkable
        elif w>=s+wt:k='open'
        elif wt>=s:k='water'
        else:k='solid'
        cats[ty][tx]=k;cols[ty][tx]=(cw if k=='open' else cwt if k=='water' else cs).most_common(1)[0][0] if (cw if k=='open' else cwt if k=='water' else cs) else C['road']   # colour from the tile's own category only
# pockets of walkable ground that cannot be reached become bushes (what you see = where you can go)
def bfs(st):
    seen={st};q=deque([st])
    while q:
        x,y=q.popleft()
        for dx,dy in((1,0),(-1,0),(0,1),(0,-1)):
            nx,ny=x+dx,y+dy
            if 0<=nx<W and 0<=ny<H and cats[ny][nx]=='open' and (nx,ny) not in seen:seen.add((nx,ny));q.append((nx,ny))
    return seen
SPAWN=(48,38)
reach=bfs(SPAWN);pockets=0
for y in range(H):
    for x in range(W):
        if cats[y][x]=='open' and (x,y) not in reach:cats[y][x]='solid';cols[y][x]=C['treeD'];pockets+=1
grid=''.join('0' if cats[y][x]=='open' else '1' for y in range(H) for x in range(W))
# tile-aligned picture (16 px per tile, drawn 2x in the game)
S=16;out=Image.new('RGB',(W*S,H*S));d=ImageDraw.Draw(out);LAMPS=[]
for y in range(H):
    for x in range(W):
        c=cols[y][x];k=cats[y][x];x0,y0=x*S,y*S
        if k=='open' and c in (C['shadow'],(0xff,0xd6,0x82),C['gold'],C['cave']):   # walkable tiles never look like walls: shadows and lamp glows become the ground under them
            yy=y+.5;xx=x+.5
            onroad=any(cols[y+dy][x+dx] in (C['road'],C['plaza'],C['stair']) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)) if 0<=x+dx<W and 0<=y+dy<H)
            c=C['road'] if onroad else (C['t3'] if yy<bp.c3(xx) else C['t2'] if yy<bp.c2(xx) else C['t1'])
            if cols[y][x]==C['shadow']:c=tuple(max(0,v-10) for v in c)
            if cols[y][x] in ((0xff,0xd6,0x82),C['gold']) and (x*3+y*5)%4==0:LAMPS.append((x,y))
        if k=='open' and c in (C['t3'],C['t2'],C['t1']):c=tuple(max(0,v-4) for v in c) if (x+y)%2 else c
        d.rectangle([x0,y0,x0+S-1,y0+S-1],fill=c)
        if k=='solid' and c in (C['treeD'],C['tree'],C['shadow'],(0x5c,0x96,0x46)):   # anything solid that is foliage or its shade reads as a bush, never a dark hole
            yy=y+.5;xx=x+.5;g=C['t3'] if yy<bp.c3(xx) else C['t2'] if yy<bp.c2(xx) else C['t1']
            d.rectangle([x0,y0,x0+S-1,y0+S-1],fill=g);d.ellipse([x0+1,y0+1,x0+S-2,y0+S-2],fill=C['tree'],outline=C['treeD']);cols[y][x]=C['treeD']
        if c==C['face']:d.line([(x0,y0+S//2),(x0+S,y0+S//2)],fill=C['shadow']);d.line([(x0+(8 if (x+y)%2 else 0),y0),(x0+(8 if (x+y)%2 else 0),y0+S//2)],fill=C['shadow'])
        if c==C['stair']:[d.line([(x0,y0+k2*4),(x0+S,y0+k2*4)],fill=C['face']) for k2 in (1,2,3)]
        if k=='water' and (x*7+y*3)%9==0:d.line([(x0+3,y0+S//2),(x0+S-4,y0+S//2)],fill=(0x8f,0xb0,0xe8))
for y in range(H):
    for x in range(W):
        if cats[y][x]!='open':
            for dx,dy,seg in [(1,0,((S-1,0),(S-1,S-1))),(-1,0,((0,0),(0,S-1))),(0,1,((0,S-1),(S-1,S-1))),(0,-1,((0,0),(S-1,0)))]:
                nx,ny=x+dx,y+dy
                if 0<=nx<W and 0<=ny<H and cats[ny][nx]=='open' and cols[y][x] not in (C['treeD'],C['tree'],C['mount'],C['ridge'],C['rockD']):
                    (a,b),(c2,e)=seg;d.line([(x*S+a,y*S+b),(x*S+c2,y*S+e)],fill=C['shadow'],width=2)
for (lx,ly) in LAMPS:d.ellipse([lx*S+5,ly*S+4,lx*S+11,ly*S+10],fill=C['gold'],outline=C['shadow'])
f=ImageFont.truetype('/usr/share/fonts/opentype/tlwg/Loma-Bold.otf',14)
labels=[(n,bx,by) for n,bx,by,bw,bh,door in BL]+[('ลานน้ำพุ',48,29.5),('จุดนัดพบ',44,37.6),('ต้นไทรใหญ่',39.5,43.2),('ช่องเขา',48,5.2),('ลานเทศกาล',49,bp.shore(48)-2.8),('ถนนตั้งแผง',78,bp.C and 34.6),('ลานชมวิว',59.3,18.6),('สวนผลไม้',35,8.4),('สนามเด็กเล่น',87,bp.shore(88)-3.2),('ท่าเรือ',48,62)]
for n,x,y in labels:
    tw=d.textlength(n,font=f);d.rectangle([x*S-tw/2-3,y*S-9,x*S+tw/2+3,y*S+9],fill=(20,14,36));d.text((x*S-tw/2,y*S-8),n,font=f,fill='#ffe7b0')
out.save('/mnt/user-data/outputs/capital-greybox.png',optimize=True)
# game data
def door_spot(n,bx,by,bw,bh,door):
    return [bx,by+bh/2+1.4] if door=='down' else [bx,by-bh/2-1.1]
ew=lambda x:32-2.4*((x-48)/48)**2;sh=bp.shore
data={'grid':grid,'spawn':[48,38.5],'exits':{'n':[48,0.4],'w':[0.4,ew(0)],'e':[95.6,ew(96)],'s':[48,63.6]},
 'board':[b for b in [(bx,by+bh/2+1.2) for n,bx,by,bw,bh,door in BL if n=='กระดาน']][0],
 'leah':[44,38],'doors':{n:door_spot(n,bx,by,bw,bh,door) for n,bx,by,bw,bh,door in BL if door},
 'routes':[[[48,4],[48,60]],[[x,ew(x)] for x in range(2,95,8)],[[48,18],[40,16],[30,15.5],[22,15],[13,16]],[[48,18],[56,18.5],[62,18.8],[66,17.5],[76,15.5],[84,15]],
           [[x,sh(x)-5.2] for x in range(6,92,8)],[[18.2,32],[18.2,41],[21,43.6],[18,47.5],[20,52]],[[74,31.2],[78,37],[75,41],[77,46.5],[76,52]],
           [[56,27.5],[61,24],[63,19.5]],[[58,32],[48,41],[38,32],[48,23.5],[58,32]],[[13,16],[14.5,20],[15,26],[16,29.5]]],
 'stands':[[70,34.2,0],[82,34.2,0],[45,sh(48)-3,0],[52,sh(48)-3,0],[50,61,4],[41.5,41.5,2],[12,19,0],[59.3,19.5,0],[23,35.2,0],[10,31.5,0]],
 'pockets':pockets,'walkable':sum(1 for c in grid if c=='0')}
json.dump(data,open('/home/claude/capital/cap52.json','w'))
print('walkable',data['walkable'],'pockets closed',pockets,'| board',[round(v,1) for v in data['board']],'| doors',len(data['doors']))
out.resize((1152,768),Image.NEAREST).save('/home/claude/chunks/grey52.png')
