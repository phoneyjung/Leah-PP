from PIL import Image
import numpy as np
SIG=np.array([[255,200,87],[127,224,255]]);FAM=np.array([[75,63,114],[58,30,63],[243,227,195],[27,19,48]])
def hsl(px):
    mx=px.max(1);mn=px.min(1);l=(mx+mn)/2;d=mx-mn;s=np.where(d==0,0,d/(1-np.abs(2*l-1)+1e-6))
    r,g,b=px[:,0],px[:,1],px[:,2];h=np.zeros(len(px));m=d>0;rm=(mx==r)&m;gm=(mx==g)&m&~rm;bm=m&~rm&~gm
    h[rm]=((g-b)[rm]/d[rm])%6;h[gm]=(b-r)[gm]/d[gm]+2;h[bm]=(r-g)[bm]/d[bm]+4;return h*60,s,l
def stats(img):
    a=np.asarray(img.convert('RGB').resize((384,256)),dtype=float)/255;px=a.reshape(-1,3);h,s,l=hsl(px)
    yg=((h>=45)&(h<110)&(s>.35)).mean();gold=((h>=30)&(h<58)&(s>.55)&(l>.55)).mean();violet=((h>=240)&(h<320)&(s>.15)).mean()
    p=px*255;dS=np.min(np.linalg.norm(p[:,None,:]-SIG[None],axis=2),axis=1);dF=np.min(np.linalg.norm(p[:,None,:]-FAM[None],axis=2),axis=1)
    sig=dS<60;fam=(~sig)&((dF<45)|(l*255<38));zone=~(sig|fam)
    return dict(zone=round(zone.mean()*100),family=round(fam.mean()*100),signal=round(sig.mean()*100),yellowGreen=round(yg*100),goldGlow=round(gold*100),violet=round(violet*100),avgSat=round(float(s.mean()),2))
