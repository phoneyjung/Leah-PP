# Capital v5.1 · hill town, terrain first, LA palette (60 zone · 30 LA family · 10 signal)
from PIL import Image,ImageDraw,ImageFont
import math,random
T=32;W,H=96,64
B='/usr/share/fonts/opentype/tlwg/Loma-Bold.otf';Rf='/usr/share/fonts/opentype/tlwg/Loma.otf'
mount=lambda x:6.6+1.5*math.sin(x/8.5)+0.8*math.sin(x/3.3+1)-(3.0 if abs(x-48)<3.5 else 0)
c3=lambda x:22.6+2.2*math.sin(x/13.0+.6)
c2=lambda x:44+2.2*math.sin(x/10.5+2.0)
shore=lambda x:58.6+1.2*math.sin(x/7.5+.4)
C={ # 60% zone identity: garden greens, cream stone, terracotta, teak
 't3':(0x86,0xb0,0x68),'t2':(0x76,0xa0,0x5a),'t1':(0x6a,0x93,0x4e),'sand':(0xe6,0xd2,0xa6),'tree':(0x3f,0x7a,0x3a),'treeD':(0x2c,0x5a,0x2a),
 'road':(0xd9,0xc4,0x98),'plaza':(0xe0,0xcc,0xa0),'bridge':(0xe4,0xd2,0xaa),'stair':(0xc8,0xb2,0x86),'roof':(0xa8,0x55,0x3a),'teak':(0x8e,0x5a,0x3a),
 # 30% LA family: dusk violet rock and water, plum shadows, cream light
 'mount':(0x4b,0x3f,0x72),'ridge':(0x5d,0x50,0x88),'rockD':(0x3a,0x30,0x5c),'face':(0x6a,0x5a,0x8a),'shadow':(0x3a,0x1e,0x3f),'lake':(0x4a,0x40,0x78),'stream':(0x46,0x62,0xa8),'fall':(0xe8,0xf2,0xff),'cave':(0x1b,0x13,0x30),
 # 10% signal: gold = doors / lanterns / things to touch · cyan = crystal
 'gold':(0xff,0xc8,0x57),'cyan':(0x7f,0xe0,0xff)}
def build(labels=True):
    im=Image.new('RGB',(W*T,H*T),C['t2']);d=ImageDraw.Draw(im)
    F=ImageFont.truetype(B,34);f=ImageFont.truetype(Rf,26)
    # --- terrain: mountain with layered ridges, three terraces with thick stone faces and shadow, lake with a sandy shore
    for px in range(W*T):
        x=px/T;m=mount(x)
        d.line([(px,0),(px,m*T)],fill=C['mount'])
        for k,col in [(0.35,C['ridge']),(0.62,C['rockD'])]:     # ridge bands give the mountain depth
            y0=(m*k+0.8*math.sin(x/5+k*7))*T;d.line([(px,y0),(px,y0+0.6*T)],fill=col)
        d.line([(px,m*T),(px,c3(x)*T)],fill=C['t3']);d.line([(px,c3(x)*T),(px,c2(x)*T)],fill=C['t2']);d.line([(px,c2(x)*T),(px,shore(x)*T)],fill=C['t1'])
        d.line([(px,(shore(x)-1.2)*T),(px,shore(x)*T)],fill=C['sand']);d.line([(px,shore(x)*T),(px,H*T)],fill=C['lake'])
        for e in (c3(x),c2(x)):   # retaining wall: 1.4-tile stone face + plum shadow at its foot
            d.line([(px,e*T),(px,(e+1.7)*T)],fill=C['face']);d.line([(px,(e+1.7)*T),(px,(e+2.3)*T)],fill=C['shadow'])
        d.line([(px,(m-0.8)*T),(px,m*T)],fill=C['shadow'])     # cliff foot shadow
    # --- stream: waterfall → spring pool → S-curves with a resting pond and a 2-tile cascade at each terrace → delta into the lake
    pts=[(15,m0:=mount(15)+2),(17,13),(20.5,16.5),(22.5,19.5),(23.5,c3(23.5)+1),(26.5,26),(24.5,29.5),(26,33),(29.5,37),(31,41.5),(31.5,c2(31.5)+1),(33.5,49.5),(35,53),(36.5,shore(36.5))]
    def blob(x,y,r,col):d.ellipse([x*T-r*T,y*T-r*T,x*T+r*T,y*T+r*T],fill=col)
    for (a,b),(c,e) in zip(pts,pts[1:]):
        for k in range(41):blob(a+(c-a)*k/40,b+(e-b)*k/40,1.35,C['stream'])
    for i in range(9):blob(36.5+(i-4)*.3,shore(36.5)-.2+abs(i-4)*.1,1.45+abs(i-4)*.08,C['stream'])   # delta
    d.rectangle([13.6*T,0.6*T,16.4*T,(mount(15)+.3)*T],fill=C['fall'])                              # main waterfall
    blob(15.2,mount(15)+2.2,2.6,C['stream'])                                                           # spring pool
    blob(22.2,19.2,1.9,C['stream']);blob(30.2,40.6,1.9,C['stream'])                                    # resting ponds
    for xx in (23.5,31.5):ee=c3(xx) if xx<28 else c2(xx);d.rectangle([(xx-1.1)*T,(ee-.1)*T,(xx+1.1)*T,(ee+2.0)*T],fill=C['fall'])   # cascades
    # --- roads that follow the slope
    def path(pts,w):
        for (a,b),(c,e) in zip(pts,pts[1:]):
            n=int(max(abs(c-a),abs(e-b))*4)+1
            for k in range(n+1):blob(a+(c-a)*k/n,b+(e-b)*k/n,w/2,C['road'])
    cx,cy=48,32
    ew=lambda x:cy-2.4*((x-cx)/48)**2                              # east-west road bends with the middle terrace
    path([(x,ew(x)) for x in range(0,97,4)],5)
    path([(cx,H),(cx,0)],5)                                           # grand axis: pier → festival → plaza → forecourt → gorge
    path([(cx,17.5),(40,16),(30,15.5),(22,15),(13,16)],4)             # upper west branch to the temple at the spring
    path([(cx,17.5),(56,18.5),(62,18.8)],4);path([(66,17.5),(76,15.5),(84,15)],4)   # upper east branch: forecourt → Academy → guild hall
    path([(56,27.5),(61,24),(63,19.5)],4)                             # plaza → Academy side stairs
    path([(x,shore(x)-5.2) for x in range(4,93,4)],4)                 # lakeside promenade follows the shore
    path([(18.2,32),(18.2,41),(21,43.6),(18,47.5),(20,52)],4)   # west slope road between the restaurant and the tea house, zig-zag after the stairs
    path([(13,16),(14.5,20),(15,26),(16,29.5)],4)                       # temple terrace → west houses (stairs at the terrace edge)
    path([(74,31.2),(78,37),(75,41),(77,46.5),(76,52)],4)             # east slope road down to the lakeside
    # stairs where a road crosses a terrace edge (lanterns on the grand stairs)
    def stairs(x,e,w=5):
        d.rectangle([(x-w/2)*T,(e-.2)*T,(x+w/2)*T,(e+2.0)*T],fill=C['stair'])
        for k in range(6):d.line([((x-w/2)*T,(e+k*.35)*T),((x+w/2)*T,(e+k*.35)*T)],fill=C['face'],width=4)
    for x in (cx,):stairs(x,c3(x),6);stairs(x,c2(x),6)
    for x,e in [(63.3,c3(63.3)),(21.0,c2(21.0)),(76.3,c2(76.3)),(15.0,c3(15.0))]:stairs(x,e,4)
    for x in (cx-3.4,cx+3.4):
        for e in (c3(cx),c2(cx)):blob(x,e+0.2,.35,C['gold']);blob(x,e+1.8,.35,C['gold'])   # lantern pairs on the grand stairs
    # street lanterns (the 10% accent): warm glow pools along the grand axis, the east-west road, the promenade and around the plaza
    def lamp(x,y):blob(x,y,1.5,(0xff,0xd6,0x82));blob(x,y,.45,C['gold'])
    for y in range(4,62,5):
        if not (22<y<42):lamp(cx-3.3,y);lamp(cx+3.3,y)
    for x in range(4,94,7):
        if abs(x-cx)>11:lamp(x,ew(x)-3.1);lamp(x+3.5,ew(x+3.5)+3.1)
    for x in range(6,92,7):
        if abs(x-cx)>6:lamp(x,shore(x)-7.6)
    for a in range(0,360,45):lamp(cx+11*math.cos(math.radians(a)),cy+10*math.sin(math.radians(a)))
    for x in range(41,58,2):blob(x,shore(48)-4.8,.3,C['gold'])     # festival lantern string
    for p in [(40,16),(30,15.5),(22,15),(56,18.5),(76,15.5),(84,15),(61,24),(18.2,36.5),(18.2,40.5),(18,47.5),(78,37),(75,41),(77,46.5),(13,20),(15,26)]:lamp(*p)   # lanterns along the terrace paths and slope roads
    for a in range(0,360,20):blob(cx+7*math.cos(math.radians(a)),cy+6.3*math.sin(math.radians(a)),.5,(0xff,0xd6,0x82))   # lantern ring around the fountain
    for i in range(14):lamp(52+i*1.2 if i<7 else 58+(i-7)*1.6,16.6 if i<7 else 20.0) if False else None
    # bridges (arched stone) where roads cross the stream
    for bx,by in [(20.8,15.1),(25.6,ew(25.6)),(33.2,shore(33.2)-5.2)]:d.rounded_rectangle([(bx-2.3)*T,(by-2.5)*T,(bx+2.3)*T,(by+2.5)*T],radius=26,fill=C['bridge'],outline=C['teak'],width=5)
    # gorge + cave mouth at the north gate
    d.rectangle([(cx-2.5)*T,0,(cx+2.5)*T,(mount(cx)+.2)*T],fill=C['road']);d.ellipse([(cx-2.2)*T,.2*T,(cx+2.2)*T,3.6*T],fill=C['cave'])
    # plaza, fountain, meeting banyan
    d.ellipse([(cx-10)*T,(cy-9)*T,(cx+10)*T,(cy+9)*T],fill=C['plaza'],outline=C['face'],width=6);blob(cx,cy,3,C['stream']);blob(cx,cy,1.2,C['fall'])
    # zones
    Z=[('ลานหน้า Academy · จุดชมวิว',52,16.4,67,c3(59)-0.4,C['plaza']),('ถนนตั้งแผง',61,ew(78)+2.4,95,ew(78)+5.0,C['plaza']),('ลานเทศกาลโคม',38,shore(48)-4.6,60,shore(48)-1.0,C['plaza']),('สนามเด็กเล่น',80,shore(88)-5.6,94,shore(88)-1.4,C['sand'])]
    for n,x0,y0,x1,y1,c in Z:d.rounded_rectangle([x0*T,y0*T,x1*T,y1*T],radius=30,fill=c)
    d.rectangle([(cx-2)*T,(shore(cx)-.3)*T,(cx+2)*T,H*T],fill=C['teak'])                       # pier
    # buildings (terracotta roofs, teak), each with a gold door facing its road
    BL=[('Lantern Academy',59.3,12.0,16,7,'down',3),('วิหารตะเกียงแรก',8.5,12.5,10,6.5,'down',3),('หอสมาคมอาชีพ',84,12.0,10,6,'down',3),
        ('บ้าน',7,28.5,7,4.5,'down',2),('บ้าน',15.2,27.8,6,4,'down',2),('ร้านน้ำชาริมลำธาร',23.0,38.2,5,3.2,'up',2),('บ้าน',5.6,38.2,7,4.5,'up',2),('ร้านอาหาร',13.0,38.4,6,4.5,'up',2),
        ('ศาลโคม',57.5,26.5,4,3.4,'down',2),('กระดาน',38.5,26.5,2.6,1.8,'down',2),('ตลาด',72,27.0,12,4.2,'down',2),('ตีเหล็ก',88.5,27.0,6,4.2,'down',2),
        ('ไปรษณีย์+คลัง',66,38.4,10,4.6,'up',2),('บ้าน',86,38.2,7,4.6,'up',2),('ศาลา สวนดอกไม้',10,50.2,10,2.8,None,1),('ลานฝึก',66,50.2,11,2.8,None,1),('ศาลาริมน้ำ',6.5,shore(6.5)-3.2,5,2.8,'down',1)]
    # every building sits wholly inside one terrace (none may straddle a stone face): snap its y into the room its terrace leaves at that x
    TIERS={3:(lambda x:mount(x)+1.2,lambda x:c3(x)-0.5),2:(lambda x:c3(x)+2.3,lambda x:c2(x)-0.5),1:(lambda x:c2(x)+2.3,lambda x:shore(x)-1.5)}
    build.warn=[]
    def fit(n,bx,by,bw,bh,tier):
        xs=[bx-bw/2+i*bw/8 for i in range(9)];top,bot=TIERS[tier]
        lo=max(top(x) for x in xs)+bh/2;hi=min(bot(x) for x in xs)-bh/2
        if lo>hi:build.warn.append(n);return (lo+hi)/2
        return min(max(by,lo),hi)
    BL=[(n,bx,fit(n,bx,by,bw,bh,tr),bw,bh,door) for n,bx,by,bw,bh,door,tr in BL]
    for n,bx,by,bw,bh,door in BL:d.rectangle([(bx-bw/2+.9)*T,(by+bh/2)*T,(bx+bw/2+.9)*T,(by+bh/2+1.5)*T],fill=C['shadow']);d.rectangle([(bx+bw/2)*T,(by-bh/2+.9)*T,(bx+bw/2+.9)*T,(by+bh/2)*T],fill=C['shadow'])
    build.BL=BL
    for n,bx,by,bw,bh,door in BL:
        d.rectangle([(bx-bw/2)*T,(by-bh/2)*T,(bx+bw/2)*T,(by+bh/2)*T],fill=C['roof'] if door else C['t1'],outline=C['shadow'],width=5)
        d.rectangle([(bx-bw/2)*T,(by+bh/2-1.1)*T,(bx+bw/2)*T,(by+bh/2)*T],fill=C['teak'])           # front wall
        if door:
            wx=bx-bw/2+.8
            while wx<bx+bw/2-.8:
                if abs(wx-bx)>1.3:d.rectangle([wx*T,(by+bh/2-1.0)*T,(wx+.9)*T,(by+bh/2-.25)*T],fill=(0xff,0xd6,0x82))   # warm lit windows
                wx+=1.5
        if door:dy=by+bh/2-.9 if door=='down' else by-bh/2;d.rectangle([(bx-.9)*T,dy*T,(bx+.9)*T,(dy+.9)*T],fill=C['gold'])
    for n,bx,by,bw,bh,door in BL:
        if door:
            fy=by+bh/2+1.5 if door=='down' else by-bh/2-1.0
            for a,b in [(bx-bw/2,bx-1.3),(bx+1.3,bx+bw/2)]:
                if b>a:d.rectangle([a*T,fy*T,b*T,(fy+.8)*T],fill=(0xc0,0x5a,0x8a),outline=C['treeD'],width=3)
    for n,bx,by,bw,bh,door in BL:
        if n=='ศาลโคม':d.rectangle([(bx-.8)*T,(by-bh/2+.4)*T,(bx+.8)*T,(by-bh/2+1.6)*T],fill=C['cyan'])     # shrine crystal (the only cyan)
        if n=='Lantern Academy':blob(bx+5.2,by-bh/2+.4,1.3,(0xff,0xd6,0x82));blob(bx+5.2,by-bh/2+.4,.7,C['gold'])   # the great lantern on the Academy tower
    # landmarks: great banyan (meeting spot), Lanna city gate at the pier, stall frames, playground
    blob(39.5,39.5,3.1,C['treeD']);blob(39.5,39.2,2.7,C['tree']);d.rectangle([43*T,40.5*T,44.4*T,42*T],fill=C['teak'])     # banyan + meeting board
    for gx in (cx-2.8,cx+2.8):d.rectangle([(gx-.5)*T,(shore(cx)-1.9)*T,(gx+.5)*T,(shore(cx)-.4)*T],fill=C['roof'])  # city gate pillars
    random.seed(11)
    for i in range(9):sx=62.5+i*3.5;sy=ew(sx)+2.9+(0.35 if i%2 else 0);d.rectangle([sx*T,sy*T,(sx+2.2)*T,(sy+1.5)*T],fill=C['teak']);d.rectangle([sx*T,sy*T,(sx+2.2)*T,(sy+.45)*T],fill=(0x8a,0x4f,0x8f))  # stall frames in one gently staggered row, purple awnings
    d.rectangle([84.5*T,(shore(88)-4.2)*T,86.5*T,(shore(88)-3)*T],fill=C['teak']);d.rectangle([89*T,(shore(88)-4.4)*T,91*T,(shore(88)-2.6)*T],fill=C['roof'])
    # orchard in loose clusters (not a grid), trees on slopes and lawns
    for (ox,oy) in [(30,10.5),(33,12.2),(36.2,10.8),(31.5,15.2),(35,14.5),(38.6,13.2),(40,10)]:blob(ox,oy,1.05,C['treeD']);blob(ox,oy-.2,.85,(0x5c,0x96,0x46));blob(ox+.3,oy-.4,.18,C['gold'])
    for _ in range(380):
        x=random.uniform(0,W);y=random.uniform(mount(x)+.5,shore(x)-1.4)
        c=im.getpixel((int(x*T)%(W*T),int(min(H*T-1,y*T))))
        if c in (C['t3'],C['t2'],C['t1']):r=random.uniform(.6,.85);blob(x+.5,y+.45,r+.1,C['shadow']);blob(x,y,r,C['treeD']);blob(x,y-.15,r-.18,C['tree'])
    if labels:
        for n,bx,by,bw,bh,door in BL:tw=d.textlength(n,font=f);d.rectangle([bx*T-tw/2-6,by*T-18,bx*T+tw/2+6,by*T+18],fill=(20,14,36));d.text((bx*T-tw/2,by*T-16),n,font=f,fill='#ffe7b0')
        for n,x0,y0,x1,y1,c in Z:tw=d.textlength(n,font=f);mx=(x0+x1)/2*T;my=(y0+y1)/2*T;d.rectangle([mx-tw/2-6,my-18,mx+tw/2+6,my+18],fill=(20,14,36));d.text((mx-tw/2,my-16),n,font=f,fill='#ffe7b0')
        for t,x,y in [('น้ำตก',15,2.2),('ช่องเขา · ไปตีนเขา/ถ้ำ',cx,5.2),('ต้นไทรใหญ่ · จุดนัดพบ',39.5,43.4),('ซุ้มประตูเมือง',cx+6.5,shore(cx)+.4),('สวนผลไม้',35,8.2),('แอ่งน้ำ',22.2,17),('แอ่งน้ำ',30.2,38.4),('ชั้น 3',80,19.8),('ชั้น 2',92,36),('ชั้น 1',92,49.5)]:
            tw=d.textlength(t,font=F);d.rectangle([x*T-tw/2-8,y*T-22,x*T+tw/2+8,y*T+24],fill=(58,30,63));d.text((x*T-tw/2,y*T-20),t,font=F,fill='#ffffff')
    return im
if __name__=='__main__':
    im=build(True);print('placement warnings:',build.warn);im.save('/mnt/user-data/outputs/capital-blueprint-v51.png');im.resize((1152,768)).save('/home/claude/chunks/bp51.jpg',quality=85)
    build(False).save('/home/claude/capital/v51_full.png')
    print('ok')
