// ===== online (Firebase Realtime Database) =====
// Off until firebase-config.js sets window.FB_CONFIG. No chat box on purpose: only positions, emotes and house points (safe for kids).
const FB_VER='10.12.2';
const Net={online:false,ready:false,room:null,uid:null,db:null,me:null,others:{},roomPts:null,last:0,lastKey:'',
  loadScript(src){return new Promise((res,rej)=>{const s=document.createElement('script');s.src=src;s.onload=res;s.onerror=rej;document.head.appendChild(s)})},
  async init(){if(this.ready)return true;if(!window.FB_CONFIG)return false;
    try{const b=`https://www.gstatic.com/firebasejs/${FB_VER}/`;await this.loadScript(b+'firebase-app-compat.js');await this.loadScript(b+'firebase-auth-compat.js');await this.loadScript(b+'firebase-database-compat.js');
      firebase.initializeApp(window.FB_CONFIG);const cred=await firebase.auth().signInAnonymously();this.uid=cred.user.uid;this.db=firebase.database();this.ready=true;return true}catch(e){console.warn('online off',e);return false}},
  async join(code){code=(code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8);if(code.length<4)return false;if(!await this.init())return false;this.leave();
    const r=this.db.ref('rooms/'+code);this.room=code;this.ref=r;this.me=r.child('players/'+this.uid);this.me.onDisconnect().remove();
    r.child('players').on('value',snap=>{const v=snap.val()||{},now={};for(const [id,p] of Object.entries(v)){if(id===this.uid)continue;const o=this.others[id]||{x:p.x,y:p.y};Object.assign(o,{p,tx:p.x,ty:p.y});now[id]=o}this.others=now});
    r.child('emotes').limitToLast(12).on('child_added',snap=>{const e=snap.val();if(!e||Date.now()-e.t>8000)return;if(e.u===this.uid)return;const o=this.others[e.u];if(o){o.emote=e.e;o.emoteT=2.6}});
    r.child('points').on('value',snap=>{this.roomPts=snap.val()||{}});this.online=true;S.room=code;save();this.send(true);if(M)this.enterMap(M.id);this.publishHome();const t1=Date.now();r.child('knock/'+this.uid).limitToLast(5).on('child_added',s=>{const k=s.val();if(k&&k.t>t1-3000){say('🔔 '+k.n+' '+t('knock'));msgT=5;sfx('warp')}});return true},
  leave(){if(this.ref){this.ref.child('players').off();this.ref.child('emotes').off();this.ref.child('points').off();if(this.me)this.me.remove()}this.ref=null;this.me=null;this.others={};this.online=false;this.room=null},
  send(force){if(!this.online||!S||!M)return;const now=performance.now();const k=[mapKey(),Math.round(P.x/4),Math.round(P.y/4),P.row,P.moving?1:0].join();if(!force&&(k===this.lastKey||now-this.last<180))return;this.last=now;this.lastKey=k;
    this.me.set({hc:S.hc||0,ec:S.ec||0,z:document.hidden?1:0,ti:titleOf(S.title),n:S.name,k:S.kid,h:S.house,a:S.age<12?1:0,m:mapKey(),x:Math.round(P.x),y:Math.round(P.y),r:P.row,w:P.moving?1:0,lv:S.lv,t:firebase.database.ServerValue.TIMESTAMP})},
  emote(e){if(this.online)this.ref.child('emotes').push({u:this.uid,e,t:Date.now()})},
  addPoints(n){if(!this.online||!n)return;this.ref.child('points/'+HOUSES[S.house].id).transaction(v=>(v||0)+n)},
  tick(dt){if(!this.online)return;this.send(false);this.swT=(this.swT||0)-dt;if(this.swT<=0){this.swT=60;this.sweep()}for(const o of Object.values(this.others)){const d=Math.hypot(o.tx-o.x,o.ty-o.y);if(d>200){o.x=o.tx;o.y=o.ty}else{o.x+=(o.tx-o.x)*Math.min(1,dt*10);o.y+=(o.ty-o.y)*Math.min(1,dt*10)}o.dist=(o.dist||0)+d*.5;if(o.emoteT>0)o.emoteT-=dt}}};
const KCODE={slime:0,bat:1,mushbug:2,golem:3},KNAME=['slime','bat','mushbug','golem'];
Object.assign(Net,{mref:null,lastPub:0,lastClean:0,
  inMap(){return M?Object.entries(this.others).filter(([id,o])=>o.p&&o.p.m===mapKey()&&!o.p.z):[]},
  coop(){return this.online&&!!M&&M.kind==='cave'&&this.inMap().length>0},
  isHost(){return !this.coop()||this.inMap().every(([id])=>this.uid<id)},   // lowest id in the same cave floor runs the monsters
  enterMap(id){if(!this.online)return;if(this.mref)['mons','hits','dmg','fx'].forEach(k=>this.mref.child(k).off());this.mref=this.ref.child('maps/'+id);const t0=Date.now();
    this.mref.child('mons').on('value',s=>{if(!this.isHost())applySnap(s.val())});
    this.mref.child('hits').limitToLast(30).on('child_added',s=>{const h=s.val();if(!h||h.t<t0-2000||h.u===this.uid||!this.isHost())return;const mo=MONS[h.i];if(mo)monHit(mo,h.d,'net',h.w||null)});
    this.mref.child('dmg').limitToLast(30).on('child_added',s=>{const h=s.val();if(h&&h.t>=t0-2000&&h.to===this.uid)hurtPlayer(h.n)});
    this.mref.child('fx').limitToLast(20).on('child_added',s=>{const f=s.val();if(!f||f.t<t0-2000||this.isHost())return;if(f.k==='tele')FX.push({k:'tele',x:f.x,y:f.y,r:f.r,t:0,life:.95,vis:1});else if(f.k==='rock')SHOTS.push({k:'rock',from:'b',x:f.x,y:f.y,vx:f.vx,vy:f.vy,life:2.2,vis:1})})},
  publish(){if(!this.coop()||!this.isHost()||!this.mref)return;const now=performance.now();if(now-this.lastPub<200)return;this.lastPub=now;
    this.mref.child('mons').set(MONS.map(o=>[Math.round(o.x),Math.round(o.y),Math.max(0,Math.round(o.hp)),o.happy?1:0,KCODE[o.kind],o.boss?1:0]));
    if(now-this.lastClean>30000){this.lastClean=now;['hits','dmg','fx'].forEach(k=>this.mref.child(k).set(null))}},
  publishHome(){if(!this.online)return;const h=HOME.get();this.ref.child('homes/'+this.uid).set({lv:houseLv(h),rooms:h.rooms||{1:h.room||[]}})},
  async getHome(uid){try{const s=await this.ref.child('homes/'+uid).once('value');const v=s.val();if(Array.isArray(v))return{lv:1,rooms:{1:v}};return v||{lv:1,rooms:{}}}catch(e){return{lv:1,rooms:{}}}},
  knock(uid){if(this.online)this.ref.child('knock/'+uid).push({n:S.name,t:Date.now()})},
  async sweep(){if(!this.online||!this.ref)return;const cut=Date.now()-45000,clean=async q=>{try{const s=await q.orderByChild('t').endAt(cut).limitToFirst(60).once('value');const v=s.val()||{};for(const k of Object.keys(v))q.ref?q.ref.child(k).remove():q.child(k).remove()}catch(e){}};
    if(this.mref&&this.isHost())for(const k of ['hits','dmg','fx'])await clean(this.mref.child(k));if(Object.keys(this.others).every(id=>this.uid<id))await clean(this.ref.child('emotes'));await clean(this.ref.child('knock/'+this.uid))},
  async autoJoin(code,tries=0){if(this.online||!S)return;let ok=false;try{ok=await this.join(code)}catch(e){ok=false}if(ok){this.watch();return}if(tries===0)say(t('netFail'));if(tries<10)setTimeout(()=>this.autoJoin(code,tries+1),30000)},
  watch(){if(this.watching||!this.db)return;this.watching=1;let first=true;try{this.db.ref('.info/connected').on('value',s=>{const c=!!s.val();if(first){first=false;return}say(c?t('netBack'):t('netLost'));if(c){this.send(true);catchUp()}})}catch(e){}},
  hit(i,d,ty){if(this.mref)this.mref.child('hits').push({i,d,u:this.uid,t:Date.now(),w:ty||''})},
  dmg(to,n){if(this.mref)this.mref.child('dmg').push({to,n,t:Date.now()})},
  fx(f){if(this.mref&&this.coop())this.mref.child('fx').push(Object.assign(f,{t:Date.now()}))}});
async function catchUp(){if(!Net.online||!Net.mref)return;try{const s=await Net.mref.child('mons').once('value');applySnap(s.val())}catch(e){}}
function applySnap(arr){if(!arr||!M||M.kind!=='cave')return;const mul=M.mul||{cave1:1,cave2:1.6,cave3:2.3}[M.id]||1;arr.forEach((a,i)=>{if(!a)return;let mo=MONS[i];
  if(!mo){mo=mkMon(KNAME[a[4]]||'slime',a[0],a[1],mul);mo.idx=i;if(a[5]){mo.boss=1;mo.w=72;mo.h=72;M.boss=mo}MONS[i]=mo}
  mo.tx=a[0];mo.ty=a[1];if(a[2]<mo.hp&&!mo.happy)mo.flash=.12;mo.hp=a[2];
  if(a[3]&&!mo.happy){mo.happy=1;mo.gone=1.6;sfx('kill');if(mo.hitByMe){gainExp(mo.exp);drop(mo);mission('help');bump('help');if(S.job){S.jp=S.jp||{};S.jp[S.job]=(S.jp[S.job]||0)+(mo.boss?10:1)}if(!mo.boss)tryPet(mo.kind);if(mo.boss){S.boss=true;S.pts=(S.pts||0)+10;save();bossWin()}}}})}
// sprite sheets of other players (their own character and house colour)
const OTH={};function othSheets(k,h,hc,ec){const key2=k+'-'+h+'-'+(hc||0)+'-'+(ec||0);if(!OTH[key2]){const n=KIDS[k]?KIDS[k][0]:KIDS[0][0],KY=KIDS[k]&&KIDS[k][3];const st=IMG['s_'+n]?recolorKey(IMG['s_'+n],HOUSES[h].h):fakeSheet(8,1),wk=IMG['w_'+n]?recolorKey(IMG['w_'+n],HOUSES[h].h):fakeSheet(6,8);if(KY){if(IMG['s_'+n])keyFix(st,hc,ec,[[0,1]]);if(IMG['w_'+n])keyFix(wk,hc,ec,[[0,6]])}OTH[key2]={stand:st,walk:wk}}return OTH[key2]}
function drawOther(o){if(o.p&&o.p.z){ctx.globalAlpha=.4}const p=o.p,sh=othSheets(p.k,p.h,p.hc,p.ec),F=Math.round(sh.walk.height/8),mv=p.w&&Math.hypot(o.tx-o.x,o.ty-o.y)>1,f=mv?Math.floor((o.dist||0)/10)%6:0;
  ctx.save();ctx.imageSmoothingEnabled=true;ctx.globalCompositeOperation='multiply';softAO(ctx,o.x-camX,o.y-camY,22,.8);ctx.restore();
  if(mv)ctx.drawImage(sh.walk,f*F,p.r*F,F,F,Math.round(o.x-F/2-camX),Math.round(o.y-(F-2)-camY),F,F);else ctx.drawImage(sh.stand,p.r*F,0,F,F,Math.round(o.x-F/2-camX),Math.round(o.y-(F-2)-camY),F,F);
  label(o.x-camX,o.y-camY-F-2,(p.ti?'«'+p.ti+'» ':'')+p.n+' Lv'+p.lv,HOUSES[p.h].col);if(o.emoteT>0)emoteBubble(o.x-camX,o.y-camY-F-16,o.emote,o.emoteT);ctx.globalAlpha=1;if(o.p&&o.p.z)label(o.x-camX,o.y-camY+8,'💤 '+t('away'))}
function emoteBubble(x,y,e,tt){ctx.save();const a=Math.min(1,tt*2),s=Math.min(1,(2.6-tt)*6);ctx.globalAlpha=a;ctx.fillStyle='#fdf6e8';ctx.fillRect(Math.round(x-9),Math.round(y-10),18,15);ctx.fillRect(Math.round(x-2),Math.round(y+5),4,2);ctx.font=`${Math.round(11*s)}px system-ui,"Segoe UI Emoji","Apple Color Emoji",sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(e,x,y-2);ctx.restore()}
let myEmote=null,myEmoteT=0;function sendEmote(e){myEmote=e;myEmoteT=2.6;Net.emote(e);sfx('pick')}
