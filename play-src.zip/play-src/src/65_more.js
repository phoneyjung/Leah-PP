// ================= v0.36 · life skills, kid tools, family gift box =================
// Kids have no combat stats. They grow through 5 life skills (Stardew style) and 5 tools.
const LIFE=[['fish','ตกปลา','Fishing','🎣'],['dig','ขุด','Digging','⛏️'],['farm','ปลูกผัก','Farming','🌱'],['cook','ทำอาหาร','Cooking','🍳'],['know','ความรู้','Knowledge','📚']];
const LIFE_PERK={fish:{3:['ปลาหายากขึ้นเล็กน้อย','Rare fish a bit more often'],5:['ได้ปลา 2 ตัวบางครั้ง','Sometimes catch 2 fish'],7:['ปลากินเบ็ดเร็วขึ้น','Fish bite sooner'],10:['ปลาในตำนานโผล่บ่อยขึ้น','Legendary fish appear more']},
  dig:{3:['เจออัญมณีบ่อยขึ้น','More gems'],5:['เจอฟอสซิลบ่อยขึ้น','More fossils'],7:['ขุดได้เหรียญเพิ่ม','Extra coins when digging'],10:['จุดขุดพิเศษวันละ 1 จุด','A bonus dig spot every day']},
  farm:{3:['ผักโตเร็วขึ้น','Crops grow faster'],5:['ผักดาวโดยไม่ใช้ปุ๋ยบางครั้ง','Sometimes a star crop without fertiliser'],7:['เก็บผักได้ +1','Harvest +1'],10:['ผักสายรุ้ง (ขายแพง)','Rainbow crops']},
  cook:{3:['ของกินอยู่ได้นานขึ้น','Food buffs last longer'],5:['ทำอาหารได้ 2 จานบางครั้ง','Sometimes cook 2 dishes'],7:['ของกินอยู่ได้นานขึ้นอีก','Buffs last even longer'],10:['เชฟแห่งหมู่บ้าน','Village chef']},
  know:{3:['ปุ่มตัวช่วย 💡 ตัดคำตอบผิด 1 ข้อ (วันละ 3)','💡 hint removes 1 wrong answer (3 a day)'],5:['ได้เหรียญเพิ่มเมื่อตอบถูก','More coins for right answers'],7:['คอมโบได้เหรียญ ×2','Combo coins ×2'],10:['นักปราชญ์น้อย','Little sage']}};
const LIFE_NEED=lv=>Math.round(20*Math.pow(lv,1.55));
function fixLife(){if(!S)return;S.life=S.life||{};for(const [k] of LIFE)S.life[k]=S.life[k]||{lv:1,xp:0};S.tools=S.tools||{};for(const [k] of TOOLS)S.tools[k]=S.tools[k]||1}
function lifeLv(k){if(!S)return 1;fixLife();return S.life[k].lv}
function lifeName(k){const d=LIFE.find(x=>x[0]===k);return d?(LANG==='en'?d[2]:d[1]):k}
function lifeXp(k,n){if(!S)return;fixLife();const L=S.life[k];if(L.lv>=10)return;L.xp+=Math.max(1,Math.round(n));let up=0;while(L.lv<10&&L.xp>=LIFE_NEED(L.lv)){L.xp-=LIFE_NEED(L.lv);L.lv++;up=1}
  if(up){const d=LIFE.find(x=>x[0]===k),pk=(LIFE_PERK[k]||{})[L.lv];sfx('lvl');say(`${d[3]} ${lifeName(k)} Lv${L.lv}!`+(pk?' · '+(LANG==='en'?pk[1]:pk[0]):''));for(let i=0;i<20;i++)FX.push({k:'star',x:P.x,y:P.y-40,vx:(rnd()-.5)*90,vy:-40-rnd()*60,t:0,life:1});if(L.lv===10)bump&&bump('life10');save()}}
// ---- tools (upgrade with coins; every level helps the matching life activity) ----
const TOOLS=[['brush','ไม้ปัดฝุ่นแสง','Light brush','🪶'],['lantern','ตะเกียง','Lantern','🏮'],['glass','แว่นขยาย','Magnifier','🔍'],['shovel','พลั่ว','Shovel','⛏️'],['rod','คันเบ็ด','Fishing rod','🎣']];
const TOOL_COST=[0,60,160,360,720];
const TOOL_FX={brush:['ปัดฝุ่นมอนเร็วขึ้น','Dust monsters faster'],lantern:['แสงในถ้ำกว้างขึ้น','Wider light in caves'],glass:['เข็มทิศชี้นานขึ้น','Compass lasts longer'],shovel:['ช่องทองตอนขุดกว้างขึ้น','Wider gold zone when digging'],rod:['ช่วงแตะตอนปลากินเบ็ดนานขึ้น','Longer time to tap when a fish bites']};
function tool(k){if(!S)return 1;fixLife();return S.tools[k]||1}
// numbers used by the hooks (all measured in tests)
const fishBiteMul=()=>1+.06*(lifeLv('fish')-1)+.08*(tool('rod')-1);
const fishWaitMul=()=>lifeLv('fish')>=7?.7:1;
const digMul=()=>1+.05*(lifeLv('dig')-1)+.08*(tool('shovel')-1);
const farmMul=()=>Math.max(.6,1-.04*(lifeLv('farm')-1));
const cookMul=()=>1+.05*(lifeLv('cook')-1)+(lifeLv('cook')>=7?.25:0);
const brushMul=()=>1+.15*(tool('brush')-1);
// ---- family gift box: kept outside any one player's save so everyone on this device shares it ----
const GIFT={get(){const d=Store.all();return d.gift||[]},put(a){const d=Store.all();d.gift=a.slice(-40);Store.put(d)},add(item,from){const a=this.get();a.push({item,from:from||'',t:Date.now()});this.put(a)}};
function giftFromKid(item){GIFT.add(item,S.name);S.good=(S.good||0)+1;say('🎁 '+t('giftKept'));sfx('pick')}
// hooks ---------------------------------------------------------------------------
{const _pick=pickUp;pickUp=function(d){if(isKid()&&d&&d.k==='item'){giftFromKid(d.item);return}return _pick(d)}}
{const _cf=catchFish;catchFish=function(){const f=FISH[FISHING.fish]||[0];lifeXp('fish',8+f[0]*4);const r=_cf.apply(this,arguments);if(lifeLv('fish')>=5&&Math.random()<.15){S.fishBag=S.fishBag||[];S.fishBag.push(FISHING.fish);setTimeout(()=>say('🐟🐟 '+t('twoFish')),900)}return r}}
{const _dd=doDig;doDig=function(d){const was=DIG;const r=_dd.apply(this,arguments);if(!was&&DIG)lifeXp('dig',8);return r}}
{const _dh=digHit;digHit=function(){const r=_dh.apply(this,arguments);if(lifeLv('dig')>=7&&S){S.coins+=2+lifeLv('dig');}return r}}
{const _ck=cookDish;cookDish=function(id){const ok=_ck.apply(this,arguments);if(ok){lifeXp('cook',12);if(lifeLv('cook')>=5&&Math.random()<.2){const h=HOME.get();h.dishes[id]=(h.dishes[id]||0)+1;HOME.put(h);setTimeout(()=>say('🍽️ '+t('twoDish')),700)}}return ok}}
{const _qr=qResult;qResult=function(q,firstOk){const r=_qr.apply(this,arguments);lifeXp('know',firstOk?10:3);if(firstOk&&lifeLv('know')>=5&&S)S.coins+=Math.floor(lifeLv('know')/2);return r}}
// harvest xp: wrap plotAct and detect a crop that disappeared from the plot
{const _pa=plotAct;plotAct=function(p){const before=(HOME.get().plots||{})[p.i];const r=_pa.apply(this,arguments);const after=(HOME.get().plots||{})[p.i];if(before&&before.st==='ripe'&&!after){lifeXp('farm',12);const h=HOME.get();if(lifeLv('farm')>=7){h.pantry[before.crop]=(h.pantry[before.crop]||0)+1;HOME.put(h)}}return r}}
// knowledge hint: remove one wrong answer (kids with Knowledge 3+, 3 times a day)
function hintBtn(q){if(!S||lifeLv('know')<3||!q)return;const day=new Date().toDateString();if(S.hintDay!==day){S.hintDay=day;S.hintN=0}const box=$('qSay');if(!box)return;const b=document.createElement('button');b.id='qHint';b.textContent='💡 '+t('hint')+' ('+(3-S.hintN)+')';b.style.marginLeft='6px';if(S.hintN>=3)b.disabled=true;
  b.onclick=()=>{if(S.hintN>=3)return;const wrong=[...document.querySelectorAll('.ch button')].filter(x=>+x.dataset.i!==q.answer&&!x.disabled);if(!wrong.length)return;const w=wrong[Math.floor(Math.random()*wrong.length)];w.disabled=true;w.style.opacity=.35;S.hintN++;b.textContent='💡 '+t('hint')+' ('+(3-S.hintN)+')';if(S.hintN>=3)b.disabled=true;sfx('pick')};box.after(b)}
// one-time: gear that a kid carries (not what they hold) moves to the family box
function kidGearMigrate(){if(!S||!isKid())return;S.inv=S.inv||[];
  // repair saves hit by the v0.36 bug (equipped weapon was moved out): give the starter brush-sword back
  if(!S.inv[S.eq]||S.inv[S.eq].slot){S.inv.unshift(mkItem('sw',0));S.eq=0;if(typeof S.eqA==='number')S.eqA++;if(typeof S.eqC==='number')S.eqC++;save()}
  if(S.giftMig2)return;S.giftMig2=1;const keepIdx=[S.eq,S.eqA,S.eqC].filter(i=>typeof i==='number'&&S.inv[i]);const keep=keepIdx.map(i=>S.inv[i]);
  const move=S.inv.filter(i=>!keep.includes(i));if(move.length){move.forEach(i=>GIFT.add(i,S.name));S.inv=keep;const pos=it=>S.inv.indexOf(it);
    const w=S.inv.find(i=>!i.slot),a=S.inv.find(i=>i.slot==='armor'),c=S.inv.find(i=>i.slot==='acc');S.eq=w?pos(w):0;if(S.eqA!=null)S.eqA=a?pos(a):null;if(S.eqC!=null)S.eqC=c?pos(c):null;save()}}
// ---- kid bag: life skills, tools, collections, gift box ----
function lifeBar(k){const L=S.life[k],need=LIFE_NEED(L.lv),pc=L.lv>=10?100:Math.round(L.xp/need*100),d=LIFE.find(x=>x[0]===k);const nxt=Object.keys(LIFE_PERK[k]||{}).map(Number).find(v=>v>L.lv);const pk=nxt?(LIFE_PERK[k][nxt]):null;
  return `<div class="pn" style="margin:0;padding:6px 8px"><b>${d[3]} ${lifeName(k)} Lv${L.lv}</b><div style="height:8px;background:#2a2340;border-radius:4px;margin:4px 0"><div style="height:8px;width:${pc}%;background:#ffd23f;border-radius:4px"></div></div><small>${L.lv>=10?t('maxLv'):(pk?`Lv${nxt}: ${LANG==='en'?pk[1]:pk[0]}`:'')}</small></div>`}
function openKidBag(){fixLife();kidGearMigrate();const g=GIFT.get().filter(x=>x.from===S.name).length;
  const tl=TOOLS.map(([k,th,en,ic])=>{const lv=tool(k),cost=TOOL_COST[lv]||0;return `<div class="pn" style="margin:0;padding:6px 8px;display:flex;align-items:center;gap:8px"><span style="font-size:22px">${ic}</span><div style="flex:1"><b>${LANG==='en'?en:th} Lv${lv}</b><br><small>${LANG==='en'?TOOL_FX[k][1]:TOOL_FX[k][0]}</small></div>${lv>=5?'<small>MAX</small>':`<button data-tool="${k}">⬆️ ${cost}🪙</button>`}</div>`}).join('');
  modal(`<h2>🎒 ${t('kidBag')}</h2><h3>${t('lifeSk')}</h3><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px">${LIFE.map(([k])=>lifeBar(k)).join('')}</div><h3>${t('tools')}</h3><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px">${tl}</div><p class="note">🎁 ${t('giftGiven')}: ${g} · 🪙 ${S.coins}</p><p><button id="kbOther">📦 ${t('otherItems')}</button></p>`);
  document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{const k=b.dataset.tool,lv=tool(k),c=TOOL_COST[lv];if(S.coins<c){say(t('noCoin'));sfx('wrong');return}S.coins-=c;S.tools[k]=lv+1;sfx('lvl');say('✨ '+(LANG==='en'?TOOLS.find(x=>x[0]===k)[2]:TOOLS.find(x=>x[0]===k)[1])+' Lv'+(lv+1));save();hud();openKidBag()});
  $('kbOther').onclick=()=>{closeModal();_openBag()}}
// adults: gift box button inside the bag
function openGiftBox(){const a=GIFT.get();modal(`<h2>🎁 ${t('giftBox')}</h2>${a.length?a.map((g,i)=>`<div class="it" style="display:flex;gap:6px;align-items:center;width:100%"><span style="flex:1">${itemLine?itemLine(g.item):g.item.name||'?'} <small>· ${t('from')} ${g.from||'?'}</small></span><button data-gi="${i}">${t('take')}</button></div>`).join(''):`<p class="note">${t('giftEmpty')}</p>`}`);
  document.querySelectorAll('[data-gi]').forEach(b=>b.onclick=()=>{const a2=GIFT.get(),g=a2.splice(+b.dataset.gi,1)[0];if(!g)return;GIFT.put(a2);S.inv=S.inv||[];S.inv.push(g.item);sfx('coin');say('🎁 '+t('thanksKid')+' '+(g.from||''));save();openGiftBox()})}
const _openBag=openBag;openBag=function(){if(isKid())return openKidBag();_openBag.apply(this,arguments);const n=GIFT.get().length;const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!document.getElementById('gbBtn')){const b=document.createElement('button');b.id='gbBtn';b.textContent='🎁 '+t('giftBox')+(n?' ('+n+')':'');b.style.marginLeft='8px';b.onclick=openGiftBox;h.after(b)}};

// ================= controls: number keys, dash (light-foot), meditation, gamepad =================
const PADK={prev:[]};let DASH={t:0,cd:0,vx:0,vy:0};const lastMove={x:0,y:1};
function doDash(){if(!S||PAUSE||P.dead||DASH.cd>0||P.sit)return;const d=Math.hypot(lastMove.x,lastMove.y)||1;DASH={t:.2,cd:isKid()?1.8:2.6,vx:lastMove.x/d*460,vy:lastMove.y/d*460};P.path=null;sfx('shoot');for(let i=0;i<10;i++)FX.push({k:'spark',x:P.x,y:P.y-6,vx:(rnd()-.5)*60,vy:-10-rnd()*30,t:0,life:.5})}
function toggleSit(){if(!S||isKid()||P.dead||PAUSE)return;if(P.sit){P.sit=0;return}const near=MONS.some(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<110);if(near){say(t('sitNo'));return}P.sit=1;P.path=null;say('🧘 '+t('sitOn'))}
addEventListener('keydown',e=>{if(!S||PAUSE||DLG)return;const k=e.key;if(k==='1')useSkill();else if(k==='2')useJob((S.slots||[])[0]);else if(k==='3')useJob((S.slots||[])[1]);else if(k==='4')usePotion();else if(k==='Shift')doDash();else if(k==='q'||k==='Q')toggleSit();else if(k==='f'||k==='F'){if(typeof fishNear==='function'&&fishNear())fishAct()}else if(k==='t'||k==='T'){if(typeof openAuto==='function')openAuto()}});
function padPoll(){const gp=(navigator.getGamepads?[...navigator.getGamepads()]:[]).find(g=>g&&g.connected);if(!gp){if(JOY.id==='pad'){JOY.id=null;JOY.x=JOY.y=0}return}
  const ax=gp.axes[0]||0,ay=gp.axes[1]||0;if(Math.hypot(ax,ay)>.25){JOY.id='pad';JOY.x=ax;JOY.y=ay}else if(JOY.id==='pad'){JOY.id=null;JOY.x=JOY.y=0}
  const b=gp.buttons.map(x=>x&&x.pressed),hit=i=>b[i]&&!PADK.prev[i];
  if(hit(0)){if(DIG&&!DIG.done)digHit();else if(DLG)nextLine();else if(typeof fishNear==='function'&&fishNear())fishAct();else if(!PAUSE)autoAct()}
  if(!PAUSE){if(hit(1))useSkill();if(hit(2))useJob((S.slots||[])[0]);if(hit(3))useJob((S.slots||[])[1]);if(hit(4))usePotion();if(hit(5))doDash();if(hit(6))toggleSit()}
  if(hit(9))openSettings();if(hit(8))openBag();if(hit(1)&&PAUSE&&!DLG)closeModal();FISHING.hold=!!b[0]&&FISHING.st==='reel';PADK.prev=b}
{const _up=update;update=function(dt){padPoll();
  // remember facing for the dash; moving or getting hit stands you up from meditation
  let mx=0,my=0;if(keys.ArrowLeft||keys.a)mx--;if(keys.ArrowRight||keys.d)mx++;if(keys.ArrowUp||keys.w)my--;if(keys.ArrowDown||keys.s)my++;if(JOY.id!==null&&Math.hypot(JOY.x,JOY.y)>.2){mx=JOY.x;my=JOY.y}
  if(mx||my){lastMove.x=mx;lastMove.y=my;if(P.sit){P.sit=0}}else if(P.path&&P.path.length){const q=P.path[0];const dx=q[0]-P.x,dy=q[1]-P.y;if(Math.hypot(dx,dy)>2){lastMove.x=dx;lastMove.y=dy}if(P.sit)P.sit=0}
  if(DASH.cd>0)DASH.cd-=dt;
  if(DASH.t>0&&!PAUSE){DASH.t-=dt;for(let s=0;s<4;s++){const nx=P.x+DASH.vx*dt/4,ny=P.y+DASH.vy*dt/4;if(!blockedAt(M,nx,P.y))P.x=nx;if(!blockedAt(M,P.x,ny))P.y=ny}if(Math.random()<.6)FX.push({k:'spark',x:P.x,y:P.y-4,vx:0,vy:-10,t:0,life:.35})}
  if(P.sit&&S&&!isKid()){const fire=M.fire&&Math.hypot(M.fire.x-P.x,M.fire.y-P.y)<90?2:1;P.sitT=(P.sitT||0)+dt;if(P.sitT>.5){P.sitT=0;S.hp=Math.min(hpMax(),S.hp+Math.ceil(hpMax()*.03*fire));hud()}if(Math.random()<.08)FX.push({k:'spark',x:P.x+(rnd()-.5)*20,y:P.y-20,vx:0,vy:-25,t:0,life:.8})}
  return _up.apply(this,arguments)}}
{const _hp=hurtPlayer;hurtPlayer=function(n){if(P.sit)P.sit=0;if(DASH.t>0&&!isKid())return;return _hp.apply(this,arguments)}}
function addCtlButtons(){const sk=$('bSk');if(!sk||$('bDash'))return;const mk=(id,ic,lab,fn)=>{const b=sk.cloneNode(true);b.id=id;b.innerHTML=`${ic}<small>${lab}</small>`;b.onclick=fn;sk.parentNode.insertBefore(b,sk);return b};mk('bDash','💨',t('dash'),doDash);mk('bSit','🧘',t('sit'),toggleSit)}
function ctlVis(){const d=$('bDash'),s=$('bSit');if(!d)return;s.style.display=S&&!isKid()?'':'none';d.style.display=S&&!kidUI()?'':'none'}

// ================= fishing: the sea (beach) and the waterfall, each with its own fish =================
// new fish appended to FISH: [difficulty, min cm, max cm, hours, price, exp, colour]
const FISH_BASE=FISH.length;
FISH.push([0,10,18,null,6,5,'#6ab0e0'],[1,8,14,null,9,7,'#ff8a3d'],[1,20,40,[5,10],14,10,'#8fd0c8'],[2,30,70,null,22,16,'#c05a7a'],[2,15,25,[19,23],26,18,'#ffe066'],[4,80,150,[23,3],140,90,'#5ad8ff'],
  [0,8,15,null,5,4,'#b8c8a0'],[1,20,35,[5,9],12,9,'#e8a8c8'],[2,40,80,null,24,18,'#f0a040'],[2,10,18,'light',28,20,'#c0f0ff'],[3,25,45,[16,19],40,30,'#a0e080'],[4,50,90,[4,6],120,80,'#ffe8a0']);
const FLOC={lake:[0,1,2,3,4,5,6,7,8,9,10,11],beach:[FISH_BASE,FISH_BASE+1,FISH_BASE+2,FISH_BASE+3,FISH_BASE+4,FISH_BASE+5],falls:[FISH_BASE+6,FISH_BASE+7,FISH_BASE+8,FISH_BASE+9,FISH_BASE+10,FISH_BASE+11]};
const FLOCW=[5,4,3,2,1.2,.15];
function fishWeights(){const id=M&&M.id,pool=FLOC[id]||FLOC.lake;let base=id==='lake'||!FLOC[id]?fwNow().filter(([i])=>pool.includes(i)):pool.map((i,k)=>[i,FLOCW[k]]);
  if(isRainy()&&FLOC[id]&&id!=='lake')base=base.map(([i,w])=>[i,FISH[i][0]>=2?w*1.8:w]);
  const lv=lifeLv('fish');return base.map(([i,w])=>[i,w*(FISH[i][0]>=2&&lv>=3?1.4:1)*(FISH[i][0]>=4&&lv>=10?3:1)])}
function rollFish(){const h=new Date().getHours(),pool=fishWeights().filter(([i])=>hourOk(h,FISH[i][3]));const tot=pool.reduce((a,[,w])=>a+w,0);let r=Math.random()*tot;for(const [i,w] of pool){if((r-=w)<=0)return i}return pool.length?pool[0][0]:0}
function buildBeach(){SEED=61;const m=newMap('beach','town',34,22,61);m.nameKey='beach';m.theme='beach';
  for(let y=0;y<m.h+1;y++)for(let x=-1;x<m.w+1;x++){const shore=13+Math.round(1.6*Math.sin(x*.42)+.8*Math.sin(x*1.1));if(y>=shore||(x>=27&&y>=8+Math.round(Math.sin(y*.7))))m.WATER.add(key(x,y))}
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(!m.WATER.has(key(x,y)))m.PATH.add(key(x,y))};
  for(let x=0;x<27;x++){const shore=13+Math.round(1.6*Math.sin(x*.42)+.8*Math.sin(x*1.1));pr(x,shore-3,x,shore-1)}pr(0,7,6,8);
  m.WATER.forEach(k=>m.SOLID.add(k));
  const px=15,top=13+Math.round(1.6*Math.sin(px*.42)+.8*Math.sin(px*1.1));for(let y=top-1;y<=top+4;y++)for(const x of [px-1,px])m.SOLID.delete(key(x,y));m.decks.push({img:'pier',x:px*T,y:(top-1)*T+8,oy:0});
  m.fishSpot={x:px*T-16,y:(top+3)*T+10,wx:px*T-16,wy:(top+5)*T+8};
  [['palm',3,4],['palm',9,3],['palm',20,4],['palm',24,6],['bananaB',12,5],['frangi',17,6],['palm',2,10],['bananaB',22,9],['roundA',6,2],['pink',14,2]].forEach(a=>addTree(m,...a));
  addDeco(m,'rocks',26,10,0);addDeco(m,'boulder',25,12,1);addDeco(m,'grass',8,8,0);addDeco(m,'flowers',18,8,0);addProp(m,'lamp',13,9);
  addNpc(m,'mom',19,10,2);
  m.exits.push({id:'w',x:14,y:7.5*T,to:'lake',toExit:'e',label:'lake'});m.spawnDefault=[2*T,7.5*T];return m}
function buildFalls(){SEED=67;const m=newMap('falls','town',34,22,67);m.nameKey='falls';m.falls={x0:15*T,x1:19*T,y0:0,y1:8*T};
  for(let x=-1;x<=m.w;x++)for(let y=-1;y<=5+Math.round(Math.sin(x*.6));y++)if(x<15||x>18)m.CLIFF.add(key(x,y));
  for(let y=-1;y<=8;y++)for(let x=15;x<=18;x++)m.WATER.add(key(x,y));
  for(let y=0;y<m.h+1;y++)for(let x=0;x<m.w;x++){const dx=(x-16.5)/6.5,dy=(y-11.5)/3.6;if(dx*dx+dy*dy<1)m.WATER.add(key(x,y))}
  for(let y=14;y<m.h+1;y++){const c=16+Math.round(1.3*Math.sin(y*.5));m.WATER.add(key(c,y));m.WATER.add(key(c+1,y))}
  m.CLIFF.forEach(k=>m.SOLID.add(k));m.WATER.forEach(k=>m.SOLID.add(k));
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(!m.WATER.has(key(x,y))&&!m.CLIFF.has(key(x,y)))m.PATH.add(key(x,y))};pr(0,11,9,12);pr(9,9,10,14);
  const br=[];for(const y of [17,18])for(let x=0;x<m.w;x++)if(m.WATER.has(key(x,y))){m.SOLID.delete(key(x,y));br.push(x)}m.decks.push({img:'bridgeRope',x:(Math.min(...br)+Math.max(...br)+1)/2*T,y:18*T,oy:61});
  m.fishSpot={x:9.5*T,y:11.5*T,wx:11.5*T,wy:11.5*T};
  [['pine',2,8],['pineTwin',4,15],['pine2',1,18],['pineThick',7,19],['pine',12,19],['pineYoung',23,16],['pine',26,9],['pineThick',29,12],['pine2',31,17],['roundA',22,20],['pineBird',28,7],['pink',6,7]].forEach(a=>addTree(m,...a));
  addDeco(m,'mossRock',11,8,0);addDeco(m,'fern',22,8,0);addDeco(m,'boulder',24,12,1);addDeco(m,'flowers',5,13,0);addDeco(m,'berry',27,19,1);addDeco(m,'log',20,14,1);
  m.exits.push({id:'w',x:14,y:11.5*T,to:'mountain',toExit:'e',label:'mountain'});m.spawnDefault=[2*T,11.5*T];return m}
MAPS.beach=buildBeach;MAPS.falls=buildFalls;
// waterfall + surf animation drawn over the ground
function drawWater2(tm){if(M.falls){const f=M.falls;ctx.save();for(let i=0;i<34;i++){const x=f.x0+((i*37)%(f.x1-f.x0)),y=((i*53+tm*260)%(f.y1-f.y0+40))-20;if(x-camX<-10||x-camX>VW+10)continue;ctx.fillStyle=i%3?'rgba(255,255,255,.55)':'rgba(190,235,255,.7)';ctx.fillRect(Math.round(x-camX),Math.round(y-camY),2,10)}
    ctx.fillStyle='rgba(255,255,255,.5)';for(let i=0;i<14;i++){const a=i/14*Math.PI*2+tm*1.4,r=18+6*Math.sin(tm*3+i);ctx.beginPath();ctx.arc(Math.round((f.x0+f.x1)/2+Math.cos(a)*r*1.6-camX),Math.round(f.y1+10+Math.sin(a)*r*.5-camY),3,0,7);ctx.fill()}ctx.restore()}
  if(M.id==='beach'){ctx.save();ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=2;for(let x=0;x<27;x++){const shore=13+Math.round(1.6*Math.sin(x*.42)+.8*Math.sin(x*1.1)),o=Math.sin(tm*1.6+x*.6)*3;ctx.beginPath();ctx.moveTo(x*T-camX,shore*T+4+o-camY);ctx.lineTo(x*T+T-camX,shore*T+4+Math.sin(tm*1.6+(x+1)*.6)*3-camY);ctx.stroke()}ctx.restore()}}

{const _hud=hud;hud=function(){const r=_hud.apply(this,arguments);try{addCtlButtons();ctlVis()}catch(e){}return r}}

// ================= adults: detailed stats, qi (ปราณ), promotions, meditation regen, limited auto, goodness =================
// Qi: permanent passive points (1 per level from Lv10). Tiers unlock with promotions. Free reset until Lv30.
const QI=[['combo',1,20,'โจมตีต่อเนื่อง','Double strike','ตีปกติมีโอกาสตีซ้ำ +1%/แต้ม','Normal hits may strike twice +1%/pt'],['cdmg',1,20,'แรงคริ','Crit power','แรงคริ +2%/แต้ม','Crit damage +2%/pt'],['hp',1,20,'กายแกร่ง','Tough body','เลือดสูงสุด +1%/แต้ม','Max HP +1%/pt'],
  ['acc',2,20,'ตาเหยี่ยว','Hawk eye','ความแม่นยำ +2/แต้ม','Accuracy +2/pt'],['eva',2,20,'เงาพริ้ว','Drifting shadow','หลบหลีก +0.5%/แต้ม','Evade +0.5%/pt'],['regen',2,20,'ปราณไหล','Flowing qi','ฟื้นเลือด +5%/แต้ม','Regen +5%/pt'],
  ['cdr',3,15,'ใจแน่วแน่','Steady mind','คูลดาวน์ท่า −1%/แต้ม','Skill cooldown −1%/pt'],['boss',3,15,'ใจสิงห์','Lion heart','ตีบอสแรงขึ้น +1.5%/แต้ม','Damage to bosses +1.5%/pt']];
function qi(k){if(!S||isKid()||!S.qi)return 0;const d=QI.find(x=>x[0]===k);if(!d||(S.tier||1)<d[1]||!S.job)return 0;return S.qi[k]||0}
const qiTotal=()=>S?Math.max(0,S.lv-9):0,qiSpent=()=>S&&S.qi?Object.values(S.qi).reduce((a,b)=>a+b,0):0;
// promotions: tier 1 = job chosen at Lv10 · tier 2 Lv30 · tier 3 Lv50, each with a quest from the wizard
const TIER_NAME={sword:['นักดาบ','อัศวินแสง','จอมดาบรุ่งอรุณ','Swordsman','Knight of Light','Dawn Blade Master'],archer:['นักธนู','พรานเหยี่ยว','จอมธนูดาวตก','Archer','Hawk Ranger','Shooting Star Archer'],mage:['นักเวท','ผู้ใช้เวทคริสตัล','ปราชญ์แห่งแสง','Mage','Crystal Caster','Sage of Light'],hunter:['นักล่าสมบัติ','นักสำรวจเงา','ตำนานนักล่าสมบัติ','Treasure Hunter','Shadow Explorer','Legendary Hunter']};
const TIER_Q={2:{lv:30,kills:60,chap:3},3:{lv:50,kills:120,chap:5}};
const tierBonus=()=>S&&!isKid()?[0,0,.08,.15][S.tier||1]:0;
function tierName(){const n=TIER_NAME[S.job];if(!n)return'';const i=(S.tier||1)-1;return LANG==='en'?n[3+i]:n[i]}
// numbers
const accVal=()=>12+ST('dex')*1.2+S.lv*.6+qi('acc')*2;
const monEva=mo=>6+((M&&M.mul)||1)*4+(mo.boss?6:0);
const hitCh=mo=>isKid()?1:Math.max(.65,Math.min(1,.88+(accVal()-monEva(mo))*.01));
const critMul=()=>(S.job==='hunter'?1.65:1.5)+qi('cdmg')*.02+((gear().cdmg||0)/100);
const regenPS=()=>isKid()?0:Math.max(1,hpMax()*.01)*(1+qi('regen')*.05);
// hooks into the existing formulas
{const _hm=hpMax;hpMax=function(){return Math.round(_hm()*(1+qi('hp')*.01)*(1+tierBonus()))}}
{const _ap=atkPow;atkPow=function(){return Math.round(_ap.apply(this,arguments)*(1+tierBonus()))}}
{const _fc=fleeCh;fleeCh=function(){return Math.min(.65,_fc()+qi('eva')*.005)}}
{const _cd=cdrMul;cdrMul=function(){return Math.max(.45,_cd()-qi('cdr')*.01)}}
let lastHurt=0,S_combo=0;{const _h2=hurtPlayer;hurtPlayer=function(n){lastHurt=performance.now();return _h2.apply(this,arguments)}}
{const _mh=monHit;monHit=function(mo,dmg,src,type){const was=!!(mo&&mo.happy);if(src!=='net'&&mo&&!mo.happy&&!isKid()){if(Math.random()>hitCh(mo)){TXT.push({x:mo.x,y:mo.y-(mo.h||20)-12,s:'MISS',c:'#c8c8d8',t:0});return}
    if(mo.boss)dmg=Math.round(dmg*(1+qi('boss')*.015));if(Math.random()<qi('combo')*.01){dmg*=2;TXT.push({x:mo.x+10,y:mo.y-(mo.h||20)-26,s:'×2',c:'#ffd23f',t:0})}}
  const r=_mh.call(this,mo,dmg,src,type);if(mo&&!was&&mo.happy&&src!=='net'&&S&&!isKid()&&!mo.boss){S.tq=S.tq||{};S.tq.kills=(S.tq.kills||0)+1;goodTick()}return r}}
// crit power: replace the fixed crit multiplier
function goodTick(){if(!Net||!Net.online)return;const kid=Object.values(Net.others||{}).some(o=>o.p&&o.p.a&&o.p.m===Net.mapKey?.());if(kid){S.goodN=(S.goodN||0)+1;if(S.goodN%5===0){S.good=(S.good||0)+1;if([20,60,150].includes(S.good))say('💛 '+t('goodTitle')+' '+goodTitle())}}}
function goodTitle(){const g=S.good||0;return g>=150?t('good3'):g>=60?t('good2'):g>=20?t('good1'):''}
// regen out of combat (adults)
{const _up2=update;update=function(dt){const r=_up2.apply(this,arguments);if(S&&!isKid()&&!P.dead&&!PAUSE&&S.hp<hpMax()&&performance.now()-lastHurt>4000&&!MONS.some(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<150)){P.rgT=(P.rgT||0)+dt;if(P.rgT>=1){P.rgT=0;S.hp=Math.min(hpMax(),S.hp+Math.round(regenPS()));hud()}}autoTick(dt);return r}}
// ---- Qi panel ----
function openQi(){if(isKid())return;if(!S.job){say(t('jobNeed'));return}S.qi=S.qi||{};const left=qiTotal()-qiSpent();
  const rows=QI.map(([k,tier,max,th,en,dth,den])=>{const lock=(S.tier||1)<tier,v=S.qi[k]||0;return `<div class="pn" style="margin:4px 0;opacity:${lock?.45:1}"><b>${LANG==='en'?en:th}</b> <small>${v}/${max}</small><br><small>${LANG==='en'?den:dth}${lock?' · 🔒 '+t('tierNeed')+' '+tier:''}</small><div style="float:right;margin-top:-26px">${lock?'':`<button data-qi="${k}" data-n="1" ${left<1||v>=max?'disabled':''}>+1</button><button data-qi="${k}" data-n="5" ${left<1||v>=max?'disabled':''}>+5</button>`}</div></div>`}).join('');
  const cost=S.lv<30?0:S.lv*50;modal(`<h2>☯️ ${t('qiT')}</h2><p class="note">${t('qiLeft')}: <b>${left}</b> · ${t('qiHow')}</p>${rows}<p><button id="qiReset">🔄 ${t('qiReset')} ${cost?cost+'🪙':t('free')}</button></p>`);
  document.querySelectorAll('[data-qi]').forEach(b=>b.onclick=()=>{const k=b.dataset.qi,max=QI.find(x=>x[0]===k)[2];const n=Math.min(+b.dataset.n,qiTotal()-qiSpent(),max-(S.qi[k]||0));if(n<=0)return;S.qi[k]=(S.qi[k]||0)+n;sfx('pick');save();hud();openQi()});
  $('qiReset').onclick=()=>{if(S.coins<cost){say(t('noCoin'));return}S.coins-=cost;S.qi={};sfx('lvl');save();hud();openQi()}}
// ---- promotion panel (added to the wizard's job screen) ----
function promoHtml(){if(!S.job)return'';const tr=S.tier||1;if(tr>=3)return `<div class="pn"><b>👑 ${tierName()}</b> · ${t('tierMax')}</div>`;const q=TIER_Q[tr+1],k=(S.tq&&S.tq.kills)||0,st=S.tq&&S.tq.on===tr+1;
  const okLv=S.lv>=q.lv,okCh=(S.chap||2)>=q.chap,okK=st&&k>=q.kills;return `<div class="pn"><b>⭐ ${t('promo')} ${tr+1}: ${(LANG==='en'?TIER_NAME[S.job][3+tr]:TIER_NAME[S.job][tr])}</b><br><small>${okLv?'✅':'⬜'} Lv${q.lv} · ${okCh?'✅':'⬜'} ${t('chapN')} ${q.chap} · ${st?(okK?'✅':'⬜')+` ${t('calmN')} ${Math.min(k,q.kills)}/${q.kills}`:'⬜ '+t('calmN')+' '+q.kills}</small><br>${!st?`<button id="tqStart" ${okLv?'':'disabled'}>${t('tqStart')}</button>`:`<button id="tqDone" ${okLv&&okCh&&okK?'':'disabled'}>${t('tqDone')}</button>`}</div>`}
{const _oj=openJobs;openJobs=function(){const r=_oj.apply(this,arguments);if(S&&S.lv>=10&&S.job){const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h){const d=document.createElement('div');d.innerHTML=promoHtml()+`<p><button id="qiOpen">☯️ ${t('qiT')}</button></p>`;h.after(d);
    const st=$('tqStart');if(st)st.onclick=()=>{S.tq={on:(S.tier||1)+1,kills:0};save();sfx('pick');say('📜 '+t('tqGo'));openJobs()};const dn=$('tqDone');if(dn)dn.onclick=()=>{S.tier=(S.tier||1)+1;S.tq=null;S.hp=hpMax();sfx('lvl');save();hud();say('👑 '+tierName()+'!');for(let i=0;i<50;i++)FX.push({k:'star',x:P.x,y:P.y-40,vx:(rnd()-.5)*120,vy:-60-rnd()*80,t:0,life:1.3});openJobs()};$('qiOpen').onclick=openQi}}return r}}
// ---- detailed stats (adults) appended to the stats screen ----
{const _os=openStats;openStats=function(){const r=_os.apply(this,arguments);if(S&&!isKid()){const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('stDetail')){const d=document.createElement('div');d.id='stDetail';d.className='pn';
    const red=Math.round((1-50/(50+defVal()))*100),row=(a,b)=>`<div class="row2" style="justify-content:space-between"><span>${a}</span><b>${b}</b></div>`;
    d.innerHTML=`<b>📐 ${t('detail')}</b>${tierName()?` · 👑 ${tierName()}`:''}${goodTitle()?` · 💛 ${goodTitle()}`:''}`+row(t('dAtk'),atkPow())+row(t('dAcc'),Math.round(accVal()))+row(t('dCrit'),Math.round(critCh()*100)+'%')+row(t('dCdmg'),Math.round(critMul()*100)+'%')+row(t('dEva'),Math.round(fleeCh()*100)+'%')+row(t('dRed'),red+'%')+row(t('dRegen'),Math.round(regenPS())+'/s')+row(t('dAspd'),Math.round(aspdMul()*100)+'%')+row('💛 '+t('good'),S.good||0)+`<p><button id="qiOpen2">☯️ ${t('qiT')}</button></p>`;
    h.after(d);$('qiOpen2').onclick=openQi}}return r}}
// ---- limited auto (adults): only on floors you have already cleared, never bosses, never quizzes ----
const AUTO={on:false,t:0,cfg:null};
function autoCfg(){S.auto=S.auto||{pot:35,sit:45,stand:90,lvl:6};return S.auto}
function mapCleared(){if(!M||M.kind!=='cave')return false;S.cleared=S.cleared||{};if(S.cleared[M.id])return true;const all=M.crystals&&M.crystals.length&&M.crystals.every(c=>c.awake);if(all){S.cleared[M.id]=1;return true}return false}
function openAuto(){if(isKid())return;const c=autoCfg(),ok=mapCleared();
  const sl=(id,v,a,b,lab)=>`<div class="row2" style="margin:6px 0"><span style="width:150px">${lab}</span><input type="range" id="${id}" min="${a}" max="${b}" value="${v}" style="flex:1"><b id="${id}v" style="width:40px;text-align:right">${v}</b></div>`;
  modal(`<h2>🤖 ${t('autoT')}</h2><p class="note">${ok?t('autoOk'):t('autoNo')}</p><div class="pn">✅ ${t('autoR1')}<br>✅ ${t('autoR2')}<br>✅ ${t('autoR3')}</div>${sl('aPot',c.pot,0,80,t('aPot')+' %')}${sl('aSit',c.sit,0,90,t('aSit')+' %')}${sl('aStand',c.stand,50,100,t('aStand')+' %')}<p><button id="aGo" ${ok?'':'disabled'}>${AUTO.on?'⏹️ '+t('autoStop'):'▶️ '+t('autoStart')}</button></p>`);
  ['aPot','aSit','aStand'].forEach(id=>$(id).oninput=e=>{$(id+'v').textContent=e.target.value;const k={aPot:'pot',aSit:'sit',aStand:'stand'}[id];c[k]=+e.target.value;save()});
  $('aGo').onclick=()=>{AUTO.on=!AUTO.on;closeModal();say(AUTO.on?'🤖 '+t('autoStart'):'⏹️ '+t('autoStop'))}}
function autoTick(dt){if(!AUTO.on||!S)return;if(isKid()||!mapCleared()){AUTO.on=false;return}if(PAUSE||DLG||P.dead)return;AUTO.t-=dt;if(AUTO.t>0)return;AUTO.t=.4;const c=autoCfg(),hp=S.hp/hpMax()*100;
  if(hp<=c.pot&&(S.potions||0)>0){usePotion();return}
  const near=MONS.filter(o=>!o.happy&&!o.boss).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y));
  if(P.sit){if(hp>=c.stand)P.sit=0;return}
  if(hp<=c.sit&&!(near[0]&&Math.hypot(near[0].x-P.x,near[0].y-P.y)<110)){toggleSit();return}
  if(P.target&&!P.target.happy)return;const mo=near[0];if(mo)attackTarget(mo)}
{const _ac=addCtlButtons;addCtlButtons=function(){_ac();const sk=$('bSk');if(!sk||$('bAuto'))return;const b=sk.cloneNode(true);b.id='bAuto';b.innerHTML=`🤖<small>${t('autoBtn')}</small>`;b.onclick=openAuto;sk.parentNode.insertBefore(b,sk)}}
{const _cv=ctlVis;ctlVis=function(){_cv();const a=$('bAuto');if(a)a.style.display=S&&!isKid()&&S.lv>=10?'':'none';if(a)a.style.outline=AUTO.on?'2px solid #7fffa0':''}}
{const _gm=goMap;goMap=function(){AUTO.on=false;if(P)P.sit=0;return _gm.apply(this,arguments)}}

// ================= story: 6 lands and an ending =================
// Chapter 1 village + crystal cave · 2 stone guardian (cave 3) · 3 glowing mushroom forest · 4 pyramid desert · 5 underground lake · 6 sky castle → ending
const LANDS={3:['forest','fire','mushking',2.8],4:['desert','storm','sphinx',3.6],5:['ulake','ice','turtle',4.4],6:['sky','storm','mist',5.2]};
for(const [ch,[th,el,boss,mul]] of Object.entries(LANDS)){const n=+ch,a=th+'1',b=th+'2',sd=7000+n*100;
  CAVE_CFG[a]={gw:4,gh:3,branch:2,seed:sd+1,crystals:5,digs:4,mons:[['slime',4+n],['mushbug',3+Math.floor(n/2)],['bat',2+Math.floor(n/2)]],next:b,up:th==='ulake'?'lake':'plaza',upExit:th==='ulake'?'cave':'x',mul,theme:th,land:n,floor:1};
  CAVE_CFG[b]={gw:4,gh:3,branch:1,seed:sd+37,crystals:3,digs:3,mons:[['mushbug',4+Math.floor(n/2)],['slime',3+Math.floor(n/2)]],boss:true,bossEl:el,up:a,upExit:'down',mul:mul+.4+(n===6?.6:0),theme:th,land:n,floor:2,bossName:boss};
  MAPS[a]=()=>buildCave(a);MAPS[b]=()=>buildCave(b)}
const THEME={forest:{f:[[30,42,22],[48,70,34],[70,98,46],[98,128,62],[132,160,86]],w:[[10,30,26],[18,48,40],[28,68,54],[44,92,70]],tint:'hue-rotate(70deg) saturate(1.1)',bright:0},
  desert:{f:[[112,82,44],[160,120,62],[196,154,88],[222,190,120],[242,220,158]],w:[[70,40,24],[106,60,34],[140,84,46],[176,112,64]],tint:'sepia(.55) saturate(1.3) hue-rotate(-12deg)',bright:1},
  ulake:{f:[[36,50,74],[50,72,104],[70,96,138],[90,122,166],[122,154,192]],w:[[12,20,40],[20,34,62],[28,48,88],[40,66,116]],tint:'hue-rotate(185deg) saturate(1.1)',bright:0},
  sky:{f:[[138,138,168],[168,168,196],[196,196,218],[220,220,236],[240,240,248]],w:[[90,122,168],[122,154,200],[160,188,224],[200,220,244]],tint:'brightness(1.2) saturate(.8)',bright:1},
  beach:{f:[[184,152,88],[208,176,112],[224,200,136],[238,220,170],[248,236,200]],sandOnly:1}};
function themeGround(m){const th=THEME[m.theme];if(!th||!m.ground)return;const c=m.ground,g=c.getContext('2d'),d=g.getImageData(0,0,c.width,c.height),p=d.data;
  const pick=(ramp,l,lo,hi)=>ramp[Math.max(0,Math.min(ramp.length-1,Math.floor((l-lo)/(hi-lo+1e-6)*ramp.length)))];
  // the ground uses a small palette, so each distinct colour is classified once (cache) instead of per pixel
  const cache=new Map(),NONE=-1;
  for(let i=0;i<p.length;i+=4){if(p[i+3]<10)continue;const key=(p[i]<<16)|(p[i+1]<<8)|p[i+2];let v=cache.get(key);
    if(v===undefined){const [h,s,l]=hslOf(p[i]/255,p[i+1]/255,p[i+2]/255),cc=(Math.max(p[i],p[i+1],p[i+2])-Math.min(p[i],p[i+1],p[i+2]))/255;let c2=null;
      if(th.sandOnly){if(h>=12&&h<=50&&cc>.1&&l>.12&&l<.75)c2=pick(th.f,l,.12,.75)}
      else if(h>=220&&h<=320&&cc>.03)c2=pick(th.w,l,.03,.55);else if(h>=5&&h<=60&&cc>.05)c2=pick(th.f,l,.05,.7);else if(cc<.06&&l<.25)c2=pick(th.w,l,0,.25);
      v=c2?(c2[0]<<16)|(c2[1]<<8)|c2[2]:NONE;cache.set(key,v)}
    if(v!==NONE){p[i]=v>>16;p[i+1]=(v>>8)&255;p[i+2]=v&255}}g.putImageData(d,0,0);if(th.bright)m.bright=1}
{const _gm2=getMap;getMap=function(id){const had=!!CACHE[id];const m=_gm2.apply(this,arguments);if(!had&&m&&!m._themed){const C=CAVE_CFG[id]||{};if(C.theme)m.theme=C.theme;if(m.theme){themeGround(m);m._themed=1}if(C.land){m.land=C.land;m.floor=C.floor;m.bossName=C.bossName||null}}return m}}
// monster colours per land: tinted once per sprite and cached (a ctx.filter on every frame cost 44 fps in t66)
const TINT={forest:{h:70,s:1.1,l:1},desert:{h:0,s:1.2,l:1.05,to:36,mix:.6},ulake:{h:185,s:1.1,l:1},sky:{h:0,s:.8,l:1.2}},TCACHE={};
function tintCanvas(src,tp){const c=document.createElement('canvas');c.width=src.width;c.height=src.height;const g=c.getContext('2d');g.drawImage(src,0,0);const d=g.getImageData(0,0,c.width,c.height),p=d.data;
  for(let i=0;i<p.length;i+=4){if(p[i+3]<8)continue;let [h,s,l]=hslOf(p[i]/255,p[i+1]/255,p[i+2]/255);h=(h+tp.h+360)%360;if(tp.to!==undefined){let dh=((tp.to-h+540)%360)-180;h=(h+dh*tp.mix+360)%360}s=Math.min(1,s*tp.s);l=Math.min(1,l*tp.l);const [r,g2,b]=rgbOf(h,Math.min(1,s),l);p[i]=Math.round(r*255);p[i+1]=Math.round(g2*255);p[i+2]=Math.round(b*255)}g.putImageData(d,0,0);return c}
function tintedArt(key,theme){const tp=TINT[theme];if(!tp||!MON_ART[key])return null;const ck=theme+'|'+key;if(!TCACHE[ck])TCACHE[ck]=MON_ART[key].map(fr=>tintCanvas(fr,tp));return TCACHE[ck]}
{const _dm=drawMon;drawMon=function(mo,tm){const th=M&&M.theme;if(!th||!TINT[th])return _dm.apply(this,arguments);const key=mo.kind+(mo.happy?1:0),art=tintedArt(key,th);if(!art)return _dm.apply(this,arguments);const orig=MON_ART[key];MON_ART[key]=art;try{return _dm.apply(this,arguments)}finally{MON_ART[key]=orig}}}
// scenes (speakers: leah · peb · the four land guardians)
const LAND_BOSS={mushking:1,sphinx:1,turtle:1,mist:1};
Object.assign(SCENES,{L3in:[['leah','s3a'],['peb','s3b']],L3boss:[['mushking','s3c'],['leah','s3d']],L3win:[['mushking','s3e'],['mushking','s3f'],['leah','s3g']],
  L4in:[['leah','s4a'],['peb','s4b']],L4boss:[['sphinx','s4c'],['leah','s4d']],L4win:[['sphinx','s4e'],['sphinx','s4f'],['peb','s4g']],
  L5in:[['leah','s5a'],['peb','s5b']],L5boss:[['turtle','s5c'],['leah','s5d']],L5win:[['turtle','s5e'],['turtle','s5f'],['leah','s5g']],
  L6in:[['leah','s6a'],['peb','s6b']],L6boss:[['mist','s6c'],['leah','s6d']],L6win:[['mist','s6e'],['leah','s6f'],['mist','s6g']],
  ending:[['peb','e1'],['leah','e2'],['guardian','e3'],['leah','e4']]});
{const _sl=showLine;showLine=function(){const [who]=DLG.lines[DLG.i];if(LAND_BOSS[who]){DLG.lines[DLG.i]=DLG.lines[DLG.i];const r=_sl.apply(this,arguments);const c=$('dlgP'),g=c.getContext('2d');const a=MON_ART.golem1&&MON_ART.golem1[0];if(a){g.clearRect(0,0,64,64);const th=THEME[{mushking:'forest',sphinx:'desert',turtle:'ulake',mist:'sky'}[who]];if(th&&th.tint)g.filter=th.tint;g.drawImage(a,4,6,56,56);g.filter='none'}return r}return _sl.apply(this,arguments)}}
function chap(){return S?(S.chap||(S.boss?3:1)):1}
function setChap(n){if(!S)return;S.chap=Math.max(chap(),n);TX.th.town='เมืองพาเพลิน · บทที่ '+Math.min(6,S.chap);TX.en.town='Paphloen Town · Chapter '+Math.min(6,S.chap);save()}
{const _bw=bossWin;bossWin=function(){const r=_bw.apply(this,arguments);setChap(3);setTimeout(()=>{try{celebrate()}catch(e){}},1700);setTimeout(()=>say('🌀 '+t('landOpen')+' '+t('forest1')),9000);return r}}
// entering land floors: scenes; lake's coral cave opens at chapter 5
{const _gm3=goMap;goMap=function(){const r=_gm3.apply(this,arguments);try{if(S)setChap(chap());if(S&&M&&/^cave[123]$/.test(M.id)&&chap()<2)setChap(2);if(M&&M.id==='lake'){const e=M.exits.find(x=>x.id==='cave');if(e&&chap()>=5){e.locked=0;e.to='ulake1';e.toExit='up';e.label='ulake1'}}
  if(M&&M.land){const L=M.land;setTimeout(()=>{if(!M||M.land!==L||DLG)return;playScene(M.floor===1?'L'+L+'in':'L'+L+'boss');if(M.floor===2&&M.boss)say('⚠️ '+t('n_'+M.bossName))},900)}}catch(e){}return r}}
// a land guardian calmed (works for co-op too: checked every frame)
{const _up3=update;update=function(dt){const r=_up3.apply(this,arguments);if(S&&M&&M.land&&M.floor===2&&M.boss&&M.boss.happy&&!M.landDone){M.landDone=1;const L=M.land;setChap(L+1);bump('land'+L);
    LIGHT=1;for(let i=0;i<70;i++)FX.push({k:'star',x:M.boss.x+(rnd()-.5)*70,y:M.boss.y-40+(rnd()-.5)*50,vx:(rnd()-.5)*90,vy:-40-rnd()*70,t:0,life:1.5});
    S.landWon=S.landWon||{};const first=!S.landWon[L];S.landWon[L]=1;save();setTimeout(()=>{if(!first){say('🌟 '+t('n_'+M.bossName)+' · '+t('againWin'));return}playScene('L'+L+'win',()=>{celebrate();if(L===6)startEnding();else{showCard(t('chDone')+' '+L,t('landOpen')+' '+t(LANDS[L+1][0]+'1'));sfx('lvl')}})},1700)}return r}}
// ending + credits
function startEnding(){S.seen=S.seen||{};delete S.seen.ending;S.ended=1;bump('ending');save();playScene('ending',showCredits)}
function showCredits(){const st=`🗺️ ${t('crLands')}: 6/6 · 💎 ${typeof totalCrystals==='function'?totalCrystals():0} · 🐟 ${Object.keys(S.fish||{}).length} · 🧹 ${CNT('help')} · ⭐ Lv${S.lv}`;
  modal(`<div style="text-align:center"><h2>🌈 ${t('crTitle')}</h2><div id="crRoll" style="height:190px;overflow:hidden;position:relative"><div id="crIn" style="position:absolute;width:100%;top:190px;line-height:1.9">
    <p><b>Leah พาเพลิน</b></p><p>${t('crStory')}</p><p>🧒 ${t('crKids')}</p><p>👨‍👩‍👧 ${t('crFam')}</p><p>🎨 PixelLab · 🤖 Claude</p><p>💛 ${t('crThanks')}</p><p>${st}</p></div></div>
    <p class="note">${t('crAfter')}</p><button id="crOk">✨ ${t('crCont')}</button></div>`);
  let y=190;const iv=setInterval(()=>{const el=$('crIn');if(!el){clearInterval(iv);return}y-=1;el.style.top=y+'px';if(y<-el.offsetHeight)y=190},30);$('crOk').onclick=()=>{clearInterval(iv);closeModal();showCard(t('crTitle'),t('crAfter'))};sfx('lvl')}
// travel: lands appear in the warp menu once unlocked
{const _ow=openWarp;openWarp=function(){const r=_ow.apply(this,arguments);const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(!h||!S)return r;const ch=chap(),rows=[];
  for(const [n,[th]] of Object.entries(LANDS)){const ok=ch>=+n;rows.push(`<button class="it" data-land="${th}1" ${ok?'':'disabled'} style="width:100%">${ok?'🌀':'🔒'} ${t(th+'1')}${ok?'':' · '+t('chapN')+' '+n}</button>`)}
  rows.push(`<button class="it" data-land="beach" style="width:100%">🎣 ${t('beach')}</button>`,`<button class="it" data-land="falls" style="width:100%">🎣 ${t('falls')}</button>`);
  const d=document.createElement('div');d.innerHTML=`<h3>🌀 ${t('landsT')}</h3><div class="grid">${rows.join('')}</div>`;const grid=h.parentNode.querySelector('.grid');(grid||h).after(d);
  d.querySelectorAll('[data-land]').forEach(b=>b.onclick=()=>{if(b.disabled)return;closeModal();goMap(b.dataset.land,'up')});return r}}

// ---- goal line after the cave guardian: point to the next land (the old text said "other caves soon") ----
{const _ug=updateGoal;updateGoal=function(){const r=_ug.apply(this,arguments);try{if(!S||!M||!S.boss)return r;const ch=chap(),el=$('goal');if(!el)return r;let g=null;
  if(M.land){const f=floorStats();if(isKid())g=f.aw<f.n?t('goalKid')+' '+f.aw+'/'+f.n:(M.floor===2?(M.boss&&!M.boss.happy?t('goalHelp')+' '+t('n_'+M.bossName):t('floorDone')):t('goalDown'));else g=M.floor===2&&M.boss&&!M.boss.happy?t('goalHelp')+' '+t('n_'+M.bossName):(f.mon?t('goalAdult')+' · '+t('goalDown'):t('goalDown'))}
  else if(M.kind!=='cave'||M.id==='cave3'){g=ch>=7?t('goalEnd'):t('goalLand')+' '+t(LANDS[Math.min(6,Math.max(3,ch))][0]+'1')}
  if(g)el.textContent=(g.trim().startsWith('🎯')?'':'🎯 ')+g}catch(e){}return r}}
// adults also level life skills (fishing, digging…) — show them in the detailed stats
{const _os2=openStats;openStats=function(){const r=_os2.apply(this,arguments);try{if(S&&!isKid()&&$('stDetail')&&!$('stLife')){fixLife();const d=document.createElement('div');d.id='stLife';d.className='pn';d.innerHTML=`<b>🌱 ${t('lifeSk')}</b> `+LIFE.map(([k,,,ic])=>`${ic} ${S.life[k].lv}`).join(' · ');$('stDetail').after(d)}}catch(e){}return r}}

// ================= fish: freshwater / saltwater, where to catch, and what fish are for =================
// 0-11 pond/lake · 12-17 sea (beach) · 18-23 waterfall. Uses: cooking (some dishes need a kind) · selling at Grandma Nuan · collection (fish book) · the princess's requests
const fishType=i=>i>=FISH_BASE&&i<FISH_BASE+6?'salt':'fresh';
const fishPlace=i=>i<FISH_BASE?'lake':i<FISH_BASE+6?'beach':'falls';
const isFishK=k=>k==='fish'||k==='sfish'||k==='ffish';
function fishCount(k){const b=S.fishBag||[];return k==='fish'?b.length:b.filter(i=>fishType(i)===(k==='sfish'?'salt':'fresh')).length}
function fishTake(k,n){S.fishBag=S.fishBag||[];for(let c=0;c<n;c++){const j=k==='fish'?0:S.fishBag.findIndex(i=>fishType(i)===(k==='sfish'?'salt':'fresh'));if(j>=0)S.fishBag.splice(j,1)}}
Object.assign(RECIPES,{tomyum:{need:{sfish:1,tom:1},buff:{atkP:15}},congee:{need:{ffish:2},buff:{hpP:18}}});
function fishHourText(i){const h=FISH[i][3];if(!h)return t('fhAny');if(h==='light')return t('fhLight');return `${h[0]}:00–${h[1]}:00`}
const fishPrice=i=>Math.max(1,Math.round(FISH[i][4]*.8));
// fish book: kind + place + time for fish you have caught, and the uses at the top
{const _fb=openFishBook;openFishBook=function(){const r=_fb.apply(this,arguments);try{const got=S.fish||{};const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('fbUse')){const u=document.createElement('p');u.id='fbUse';u.className='note';u.innerHTML=`🍳 ${t('fuCook')} · 🪙 ${t('fuSell')} · 👑 ${t('fuReq')} · 📖 ${t('fuBook')}`;h.after(u)}
  document.querySelectorAll('[data-f]').forEach(sp=>{const i=+sp.dataset.f,box=sp.parentNode.querySelector('.note');if(!box)return;const kind=fishType(i)==='salt'?'🌊 '+t('salt'):'🏞️ '+t('fresh');box.innerHTML=(got[i]?box.innerHTML+'<br>':'')+`${kind} · ${t(fishPlace(i))}`+(got[i]?` · 🕒 ${fishHourText(i)} · ${fishPrice(i)}🪙`:'')})}catch(e){}return r}}
// kitchen: count freshwater/saltwater separately
{const _ok=openKitchen;openKitchen=function(){const r=_ok.apply(this,arguments);try{const n=document.querySelector('#modal .note,.modal .note');if(n)n.innerHTML=n.innerHTML.replace(/🐟 \d+/,`🏞️ ${fishCount('ffish')} · 🌊 ${fishCount('sfish')}`);
  document.querySelectorAll('[data-ck]').forEach(b=>{const r2=RECIPES[b.dataset.ck],h=HOME.get();const ok=Object.entries(r2.need).every(([k,n])=>isFishK(k)?fishCount(k)>=n:(h.pantry[k]||0)>=n);b.disabled=!ok;const note=b.querySelector('.note');if(note)note.textContent=t('need')+' '+Object.entries(r2.need).map(([k,n])=>(k==='fish'?t('anyFish'):k==='sfish'?t('seaFish'):k==='ffish'?t('freshFish'):t('cr_'+k))+' ×'+n).join(' + ')})}catch(e){}return r}}
// selling fish at Grandma Nuan's shop (a real use for the price every fish already had)
function openFishSell(){const b=S.fishBag||[],cnt={};b.forEach(i=>cnt[i]=(cnt[i]||0)+1);const rows=Object.entries(cnt).map(([i,n])=>`<div class="it" style="display:flex;gap:6px;align-items:center;width:100%"><span style="flex:1">${fishType(+i)==='salt'?'🌊':'🏞️'} ${t('f'+i)} ×${n} · ${fishPrice(+i)}🪙</span><button data-sell="${i}">${t('sell1')}</button><button data-sellall="${i}">${t('sellAll')}</button></div>`).join('');
  modal(`<h2>🐟 ${t('sellFish')}</h2><p class="note">${t('sellTip')}</p>${rows||`<p class="note">${t('noFish')}</p>`}`);
  const sell=(i,all)=>{let n=0;S.fishBag=S.fishBag.filter(x=>{if(x===+i&&(all||n<1)){n++;return false}return true});const got=n*fishPrice(+i);S.coins+=got;sfx('coin');say('🪙 +'+got);save();hud();openFishSell()};
  document.querySelectorAll('[data-sell]').forEach(x=>x.onclick=()=>sell(x.dataset.sell,false));document.querySelectorAll('[data-sellall]').forEach(x=>x.onclick=()=>sell(x.dataset.sellall,true))}
{const _sh=openShop;openShop=function(){const r=_sh.apply(this,arguments);try{const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('fsBtn')){const b=document.createElement('button');b.id='fsBtn';b.textContent='🐟 '+t('sellFish')+' ('+(S.fishBag||[]).length+')';b.style.marginLeft='8px';b.onclick=openFishSell;h.after(b)}}catch(e){}return r}}

// ================= kids can finish the story too: 3 "guardian crystals" in every boss room =================
// The boss only fights grown-ups. A kid (alone or with the family) wakes the 3 crystals around the guardian with questions; when all 3 are awake the guardian calms down.
{const _bc=buildCave;buildCave=function(id){const m=_bc.apply(this,arguments);try{const C=CAVE_CFG[id];if(C&&C.boss&&m.bossRoom){const R=m.bossRoom;const spots=[[R.x+1,R.y+1],[R.x+R.w-2,R.y+1],[R.x+Math.floor(R.w/2),R.y+R.h-1]];let k=0;
    for(const [x,y] of spots){const kk=key(x,y);if(!m.FLOOR.has(kk)||m.SOLID.has(kk))continue;if(m.crystals.some(c=>Math.hypot(c.tx-x,c.ty-y)<2))continue;m.crystals.push({id:id+'-k'+(k++),tx:x,ty:y,x:x*T+16,y:y*T+22,awake:false,kidOnly:1})}}}catch(e){}return m}}
MAPS.cave3=()=>buildCave('cave3');for(const [ch,[th]] of Object.entries(LANDS)){const b=th+'2';MAPS[b]=()=>buildCave(b)}
{const _oq=openQuiz;openQuiz=function(c){if(c&&c.kidOnly&&!isKid()){say('💎 '+t('kidCrystal'));return}return _oq.apply(this,arguments)}}
function kidCrystals(){return (M&&M.crystals||[]).filter(c=>c.kidOnly)}
{const _up4=update;update=function(dt){const r=_up4.apply(this,arguments);try{if(M&&M.boss&&!M.boss.happy&&M.bossRoom){const kc=kidCrystals();if(kc.length&&kc.every(c=>c.awake)){const b=M.boss;if(Net&&Net.coop&&Net.coop()&&!Net.isHost()){try{Net.hit(b.idx,b.hp+9999,'sw')}catch(e){}}b.happy=1;b.gone=1.6;b.hitByMe=1;sfx('kill');say('✨ '+t('bossCalmed'));LIGHT=1;
    for(let i=0;i<50;i++)FX.push({k:'star',x:b.x+(rnd()-.5)*70,y:b.y-40+(rnd()-.5)*50,vx:(rnd()-.5)*90,vy:-40-rnd()*70,t:0,life:1.4});
    if(M.id==='cave3'&&!S.boss){S.boss=true;S.pts=(S.pts||0)+10;save();bossWin()}}}}catch(e){}return r}}
// goal line for kids on a boss floor
{const _ug2=updateGoal;updateGoal=function(){const r=_ug2.apply(this,arguments);try{if(S&&isKid()&&M&&M.boss&&!M.boss.happy){const kc=kidCrystals();if(kc.length){const aw=kc.filter(c=>c.awake).length;const el=$('goal');if(el&&inRoom(P.x,P.y,M.bossRoom))el.textContent='🎯 '+t('goalKidBoss')+' '+aw+'/'+kc.length}}}catch(e){}return r}}
{const _gt=guideTarget;guideTarget=function(){const r=_gt.apply(this,arguments);try{if(S&&isKid()&&M&&M.boss&&!M.boss.happy){const c=kidCrystals().filter(c=>!c.awake).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y))[0];const others=(M.crystals||[]).filter(c=>!c.kidOnly&&!c.awake);if(c&&!others.length)return{x:c.x,y:c.y}}}catch(e){}return r}}

// ================= combat feel: hit sparks, weapon arcs, crits with hit-stop, skill bursts, popping damage numbers =================
// Everything is drawn with code (no new image files). Kids get soft sparkle/dust versions; eco mode halves the particles.
let HITSTOP=0;const FXCAP=320;
const fxN=n=>Math.max(1,Math.round(n*(S&&S.eco?.5:1)));
function fx(o){if(FX.length>=FXCAP)return;FX.push(Object.assign({t:0,life:.4},o))}
function burst(x,y,n,col,sp,life,k){for(let i=0;i<fxN(n);i++){const a=Math.random()*6.283,v=sp*(.4+Math.random()*.8);fx({k:k||'spark2',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-20,life:life*(.7+Math.random()*.5),c:col,s:1+Math.random()*1.6})}}
const WCOL={sw:'255,236,170',dag:'235,245,255',bow:'170,255,190',staff:'210,170,255'};
function hitFx(mo,dmg,type,crit){if(!mo)return;const x=mo.x,y=mo.y-(mo.h||20)*.6,a=Math.atan2(mo.y-P.y,mo.x-P.x);
  if(isKid()){burst(x,y,8,'255,220,250',60,.5,'star2');fx({k:'puff',x,y,life:.45});return}
  const c=WCOL[type]||WCOL.sw;
  if(type==='sw'||!type)fx({k:'arc2',x,y,a,life:.22,c,r:crit?26:20});
  else if(type==='dag'){fx({k:'xcut',x,y,a,life:.18,c});}
  else if(type==='staff')fx({k:'ring2',x,y,life:.3,c,r:crit?30:22});
  else if(type==='bow')fx({k:'star2',x,y,life:.25,c,s:3});
  burst(x,y,crit?16:7,c,crit?150:90,.35);
  mo.kb={x:Math.cos(a),y:Math.sin(a),t:.12};
  if(crit){fx({k:'star2',x,y,life:.35,c:'255,190,90',s:6});fx({k:'ring2',x,y,life:.35,c:'255,200,120',r:36});HITSTOP=Math.max(HITSTOP,.06);SHAKE=Math.max(SHAKE||0,.08)}}
// hook: every successful hit (MISS returns before) gets the new effects; crit is known from the text the game just pushed
{const _mh3=monHit;monHit=function(mo,dmg,src,type){const n0=TXT.length,was=!!(mo&&mo.happy);const r=_mh3.apply(this,arguments);try{if(mo&&!was&&src!=='net'){const added=TXT.slice(n0);const miss=added.some(x=>x.s==='MISS');if(!miss){const crit=TXT.slice(Math.max(0,n0-3)).some(x=>x.s===t('crit')&&x.t<.05);hitFx(mo,dmg,type||(weapon()&&weapon().type),crit)}
  if(mo.happy){burst(mo.x,mo.y-16,isKid()?14:10,isKid()?'255,240,200':'255,255,255',110,.6,'star2');fx({k:'ring2',x:mo.x,y:mo.y-10,life:.4,c:'255,255,230',r:28})}}}catch(e){}return r}}
// skills: big readable bursts
const SKFX={bash:p=>{fx({k:'star2',x:p.x,y:p.y,life:.4,c:'255,210,120',s:9});fx({k:'ring2',x:p.x,y:p.y,life:.4,c:'255,200,120',r:48});burst(p.x,p.y,18,'255,220,150',170,.45);SHAKE=Math.max(SHAKE||0,.15)},
  guard:p=>fx({k:'shield2',x:P.x,y:P.y-24,life:1.2,c:'150,210,255',follow:1}),
  provoke:p=>{for(let i=0;i<3;i++)fx({k:'ring2',x:P.x,y:P.y-10,life:.5+i*.15,c:'255,110,110',r:30+i*22})},
  shower:p=>{for(let i=0;i<fxN(26);i++)fx({k:'rain2',x:p.x+(Math.random()-.5)*150,y:p.y-150-Math.random()*60,vx:-40,vy:520,life:.34+Math.random()*.2,c:'190,255,200'})},
  evade:p=>{for(let i=0;i<5;i++)fx({k:'after',x:P.x,y:P.y,life:.25+i*.07,ox:(Math.random()-.5)*16})},
  hawk:p=>burst(P.x,P.y-30,16,'230,230,200',120,.6,'feather'),
  fire:p=>{fx({k:'ring2',x:p.x,y:p.y,life:.45,c:'255,140,60',r:54});burst(p.x,p.y,24,'255,150,60',150,.6,'ember');fx({k:'star2',x:p.x,y:p.y,life:.3,c:'255,220,140',s:8});SHAKE=Math.max(SHAKE||0,.12)},
  ice:p=>{for(let i=0;i<fxN(12);i++){const a=i/12*6.283;fx({k:'shard',x:p.x,y:p.y,vx:Math.cos(a)*140,vy:Math.sin(a)*90,life:.5,a,c:'170,235,255'})}fx({k:'ring2',x:p.x,y:p.y,life:.5,c:'180,240,255',r:46})},
  bolt:p=>{const ts=MONS.filter(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<220).slice(0,4);let a={x:P.x,y:P.y-30};for(const o of ts){fx({k:'bolt2',x:a.x,y:a.y,x2:o.x,y2:o.y-16,life:.28,seed:Math.random()*99});a={x:o.x,y:o.y-16}}if(!ts.length)fx({k:'bolt2',x:P.x,y:P.y-160,x2:P.x,y2:P.y-20,life:.25,seed:3});SHAKE=Math.max(SHAKE||0,.1)},
  steal:p=>burst(p.x,p.y,12,'255,220,90',100,.6,'star2'),dash:p=>{for(let i=0;i<8;i++)fx({k:'speed',x:P.x,y:P.y-20+(Math.random()-.5)*30,life:.3,a:Math.atan2(lastMove.y,lastMove.x)})}};
function nearestTarget(){return MONS.filter(o=>!o.happy).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y))[0]}
{const _uj=useJob;useJob=function(k){const before=JCD[k]||0;const r=_uj.apply(this,arguments);try{if((JCD[k]||0)!==before&&SKFX[k]){const mo=P.target&&!P.target.happy?P.target:nearestTarget();SKFX[k](mo&&Math.hypot(mo.x-P.x,mo.y-P.y)<260?{x:mo.x,y:mo.y-14}:{x:P.x,y:P.y-14})}}catch(e){}return r}}
{const _us=useSkill;useSkill=function(){const before=P.skCd||0;const r=_us.apply(this,arguments);try{if((P.skCd||0)>before&&!isKid()){const c=WCOL[weapon().type]||WCOL.sw;for(let i=0;i<3;i++)fx({k:'ring2',x:P.x,y:P.y-12,life:.35+i*.12,c,r:40+i*30});burst(P.x,P.y-14,22,c,190,.5);SHAKE=Math.max(SHAKE||0,.12)}}catch(e){}return r}}
// hit-stop + arrow trails + knockback decay
{const _up5=update;update=function(dt){if(HITSTOP>0){HITSTOP-=dt;dt*=.12}try{for(const s of SHOTS)if(s.from==='p'&&Math.random()<.7)fx({k:'trail',x:s.x,y:s.y,life:.22,c:WCOL[s.k]||'255,255,255'});for(const m of MONS)if(m.kb&&m.kb.t>0)m.kb.t-=dt}catch(e){}return _up5.call(this,dt)}}
// monsters squash when hit and get pushed back a little
{const _dm2=drawMon;drawMon=function(m,tm){const k=m.flash>0?Math.min(1,m.flash/.15):0,kb=m.kb&&m.kb.t>0?m.kb.t/.12:0;if(!k&&!kb)return _dm2.apply(this,arguments);
  const mx=m.x-camX,my=m.y-camY;ctx.save();ctx.translate(mx+(kb?m.kb.x*5*kb:0),my+(kb?m.kb.y*3*kb:0));ctx.scale(1+.14*k,1-.12*k);ctx.translate(-mx,-my);const r=_dm2.apply(this,arguments);ctx.restore();return r}}
// drawn in two batches (normal, then additive light) so there is no save/restore per particle — measured in t65
const ADD={arc2:1,xcut:1,ring2:1,star2:1,shield2:1,bolt2:1,rays:1};
function drawVFX2(tm){const list=FX;if(!list.length)return;
  for(const f of list){if(ADD[f.k])continue;const p=f.t/f.life;if(p>=1)continue;const x=f.x-camX,y=f.y-camY,al=1-p;
    switch(f.k){
    case'spark2':case'ember':case'feather':{ctx.fillStyle=`rgba(${f.c},${al})`;const s2=f.s||1.5;ctx.fillRect(x|0,y|0,Math.ceil(s2),Math.ceil(s2*(f.k==='feather'?2:1)));break}
    case'trail':ctx.fillStyle=`rgba(${f.c},${.7*al})`;ctx.fillRect((x|0)-1,(y|0)-1,2,2);break;
    case'puff':ctx.fillStyle=`rgba(200,185,230,${.45*al})`;for(let i=0;i<5;i++){const a=i*1.2566;ctx.fillRect((x+Math.cos(a)*(6+p*10)-3)|0,(y+Math.sin(a)*(4+p*6)-3)|0,6+p*4|0,5+p*3|0)}break;
    case'rain2':ctx.strokeStyle=`rgba(${f.c},${al})`;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+4,y-14);ctx.stroke();break;
    case'shard':{const c=Math.cos(f.a),s2=Math.sin(f.a);ctx.fillStyle=`rgba(${f.c},${al})`;ctx.beginPath();ctx.moveTo(x+c*6,y+s2*6);ctx.lineTo(x-c*3+s2*2.5,y-s2*3-c*2.5);ctx.lineTo(x-c*3-s2*2.5,y-s2*3+c*2.5);ctx.fill();break}
    case'speed':ctx.strokeStyle=`rgba(255,255,255,${.6*al})`;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-Math.cos(f.a)*(10+p*20),y-Math.sin(f.a)*(10+p*20));ctx.lineTo(x-Math.cos(f.a)*(26+p*30),y-Math.sin(f.a)*(26+p*30));ctx.stroke();break;
    case'confetti':ctx.fillStyle=f.c;ctx.globalAlpha=al;ctx.fillRect((x|0)-2,(y|0)-1,(Math.sin(f.t*8+f.s)>0?4:2),2);ctx.globalAlpha=1;break;
    case'after':{const im=P.moving?PS.walk:PS.stand;if(im){const F=PS.F||64;ctx.globalAlpha=.35*al;ctx.drawImage(im,0,(P.row*F)%(im.height||F),F,F,Math.round(P.x-F/2-camX+f.ox),Math.round(P.y-(F-2)-camY),F,F);ctx.globalAlpha=1}break}}}
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
  for(const f of list){if(!ADD[f.k])continue;const p=f.t/f.life;if(p>=1)continue;let x=f.x-camX,y=f.y-camY;if(f.follow){x=P.x-camX;y=P.y-24-camY}const al=1-p;
    switch(f.k){
    case'arc2':for(let j=0;j<3;j++){ctx.strokeStyle=`rgba(${f.c},${al*(1-j*.3)})`;ctx.lineWidth=5-j*1.5;ctx.beginPath();ctx.arc(x-Math.cos(f.a)*6,y-Math.sin(f.a)*6,f.r+j*3+p*6,f.a-1.3+p*.6,f.a+1.1+p*.6);ctx.stroke()}break;
    case'xcut':{ctx.strokeStyle=`rgba(${f.c},${al})`;ctx.lineWidth=2.5;const L=14+p*6;ctx.beginPath();ctx.moveTo(x-L,y+L*.8);ctx.lineTo(x+L,y-L*.8);ctx.moveTo(x-L,y-L*.8);ctx.lineTo(x+L,y+L*.8);ctx.stroke();break}
    case'ring2':ctx.strokeStyle=`rgba(${f.c},${.9*al})`;ctx.lineWidth=3*al+1;ctx.beginPath();ctx.ellipse(x,y,f.r*(.35+p*.65),f.r*(.35+p*.65)*.55,0,0,6.283);ctx.stroke();break;
    case'star2':{const s2=(f.s||2)*(1+p*.6);ctx.fillStyle=`rgba(${f.c},${al})`;ctx.beginPath();for(let i=0;i<8;i++){const a=i*.7854,rr=i%2?s2*.35:s2*2;ctx.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}ctx.fill();break}
    case'shield2':ctx.strokeStyle=`rgba(${f.c},${.7*al})`;ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,20+Math.sin(tm*8)*1.5,28,0,0,6.283);ctx.stroke();ctx.fillStyle=`rgba(${f.c},${.12*al})`;ctx.fill();break;
    case'bolt2':{let sd=f.seed;const r2=()=>(sd=(sd*9301+49297)%233280)/233280;const X2=f.x2-camX,Y2=f.y2-camY;for(const [w,c] of [[5,`rgba(140,180,255,${.5*al})`],[2,`rgba(255,255,255,${al})`]]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x,y);sd=f.seed;for(let i=1;i<=7;i++){const q=i/7;ctx.lineTo(x+(X2-x)*q+(i<7?(r2()-.5)*16:0),y+(Y2-y)*q+(i<7?(r2()-.5)*10:0))}ctx.stroke()}break}
    case'rays':for(let i=0;i<10;i++){const a=i*.6283+tm*.6;ctx.fillStyle=`rgba(255,240,180,${.14*Math.sin(p*3.14)})`;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a-.08)*160,y+Math.sin(a-.08)*160);ctx.lineTo(x+Math.cos(a+.08)*160,y+Math.sin(a+.08)*160);ctx.fill()}break}}
  ctx.restore()}
// popping damage numbers: pop in, settle, float with ease-out, dark outline; crits big and golden
function drawNumbers(){for(const x of TXT){if(x.dx===undefined){x.dx=(Math.random()-.5)*14;x.dy=-10*TXT.filter(o=>o!==x&&o.dy!==undefined&&o.t<.35&&Math.abs(o.x-x.x)<24&&Math.abs(o.y-x.y)<24).length}const p=Math.min(1,x.t/1.1),crit=x.s===t('crit'),big=x.big||crit,miss=x.s==='MISS';
  const pop=x.t<.1?.55+x.t/.1*.75:Math.max(1,1.3-(x.t-.1)*2.2),rise=24*(1-Math.pow(1-p,2)),size=Math.round((big?15:(/^[+-]?\d/.test(x.s)?11:9))*pop*(isKid()?.85:1));
  ctx.save();ctx.font=`${miss?'italic ':''}bold ${size}px system-ui,sans-serif`;ctx.textAlign='center';ctx.globalAlpha=p>.7?1-(p-.7)/.3:1;const X=Math.round(x.x-camX+x.dx),Y=Math.round(x.y-camY-rise+(x.dy||0));
  ctx.lineWidth=3;ctx.strokeStyle='rgba(20,12,34,.95)';ctx.strokeText(x.s,X,Y);
  if(big&&!miss){const g=ctx.createLinearGradient(0,Y-size,0,Y);g.addColorStop(0,'#fff6c8');g.addColorStop(1,x.c||'#ffb13b');ctx.fillStyle=g}else ctx.fillStyle=x.c;ctx.fillText(x.s,X,Y);ctx.restore()}}
// chapter complete / guardian calmed: rays + confetti around the player
function celebrate(){fx({k:'rays',x:P.x,y:P.y-30,life:2.4});const cols=['#ffd23f','#ff7aa8','#7fd8ff','#a8f07a','#c9a0ff'];for(let i=0;i<fxN(70);i++)fx({k:'confetti',x:P.x+(Math.random()-.5)*60,y:P.y-60,vx:(Math.random()-.5)*220,vy:-120-Math.random()*160,life:1.6+Math.random()*.8,c:cols[i%5],s:Math.random()*6})}


function cardSub(m){try{const C=CAVE_CFG[m.id]||{};if(C.land)return (LANG==='en'?'Chapter ':'บทที่ ')+C.land+' · '+t(C.theme+'N');if(/^cave[123]$/.test(m.id))return (LANG==='en'?'Chapter ':'บทที่ ')+'2 · '+t('caveN');if(/^dream/.test(m.id))return t('dreamN')}catch(e){}return t('town')}
