// ================= v0.36 · life skills, kid tools, family gift box =================
// Kids have no combat stats. They grow through 5 life skills (Stardew style) and 5 tools.
const LIFE=[['fish','ตกปลา','Fishing','🎣'],['dig','ขุด','Digging','⛏️'],['farm','ปลูกผัก','Farming','🌱'],['cook','ทำอาหาร','Cooking','🍳'],['know','ความรู้','Knowledge','📚']];
const LIFE_PERK={fish:{3:['ปลาหายากขึ้นเล็กน้อย','Rare fish a bit more often'],5:['ได้ปลา 2 ตัวบางครั้ง','Sometimes catch 2 fish'],7:['ปลากินเบ็ดเร็วขึ้น','Fish bite sooner'],10:['ปลาในตำนานโผล่บ่อยขึ้น','Legendary fish appear more']},
  dig:{3:['เจออัญมณีบ่อยขึ้น','More gems'],5:['เจอฟอสซิลบ่อยขึ้น','More fossils'],7:['ขุดได้เหรียญเพิ่ม','Extra coins when digging'],10:['จุดขุดพิเศษวันละ 1 จุด','A bonus dig spot every day']},
  farm:{3:['ผักโตเร็วขึ้น','Crops grow faster'],5:['ผักดาวโดยไม่ใช้ปุ๋ยบางครั้ง','Sometimes a star crop without fertiliser'],7:['เก็บผักได้ +1','Harvest +1'],10:['ผักสายรุ้ง (ขายแพง)','Rainbow crops']},
  cook:{3:['ของกินอยู่ได้นานขึ้น','Food buffs last longer'],5:['ทำอาหารได้ 2 จานบางครั้ง','Sometimes cook 2 dishes'],7:['ของกินอยู่ได้นานขึ้นอีก','Buffs last even longer'],10:['เชฟแห่งหมู่บ้าน','Village chef']},
  know:{3:['ปุ่มตัวช่วย 💡 ตัดคำตอบผิด 1 ข้อ (วันละ 3)','💡 hint removes 1 wrong answer (3 a day)'],5:['ได้เหรียญเพิ่มเมื่อตอบถูก','More coins for right answers'],7:['คอมโบได้เหรียญ ×2','Combo coins ×2'],10:['นักปราชญ์น้อย','Little sage']}};
const LIFE_NEED=lv=>Math.round(20*Math.pow(lv,1.55));
function fixLife(){if(!S)return;S.life=S.life||{};for(const [k] of LIFE)S.life[k]=S.life[k]||{lv:1,xp:0};S.tools=S.tools||{};for(const [k] of TOOLS)S.tools[k]=S.tools[k]||1}
function lifeLv(k){if(!S)return 1;fixLife();return S.life[k].lv}
function lifeName(k){const d=LIFE.find(x=>x[0]===k);return d?(LANG==='en'?d[2]:d[1]):k}
function lifeXp(k,n){if(!S)return;fixLife();const L=S.life[k];if(L.lv>=10)return;L.xp+=Math.max(1,Math.round(n));let up=0;while(L.lv<10&&L.xp>=LIFE_NEED(L.lv)){L.xp-=LIFE_NEED(L.lv);L.lv++;up=1}
  if(up){const d=LIFE.find(x=>x[0]===k),pk=(LIFE_PERK[k]||{})[L.lv];sfx('lvl');say(`${d[3]} ${lifeName(k)} Lv${L.lv}!`+(pk?' · '+(LANG==='en'?pk[1]:pk[0]):''));for(let i=0;i<20;i++)FX.push({k:'star',x:P.x,y:P.y-40,vx:(rnd()-.5)*90,vy:-40-rnd()*60,t:0,life:1});if(L.lv===10)bump&&bump('life10');save()}}
// ---- tools (upgrade with coins; every level helps the matching life activity) ----
const TOOLS=[['brush','ไม้ปัดฝุ่นแสง','Light brush','🪶'],['lantern','ตะเกียง','Lantern','🏮'],['glass','แว่นขยาย','Magnifier','🔍'],['shovel','พลั่ว','Shovel','⛏️'],['rod','คันเบ็ด','Fishing rod','🎣']];
const TOOL_COST=[0,60,160,360,720];
const TOOL_FX={brush:['ปัดฝุ่นมอนเร็วขึ้น','Dust monsters faster'],lantern:['แสงในถ้ำกว้างขึ้น','Wider light in caves'],glass:['เข็มทิศชี้นานขึ้น','Compass lasts longer'],shovel:['ช่องทองตอนขุดกว้างขึ้น','Wider gold zone when digging'],rod:['ช่วงแตะตอนปลากินเบ็ดนานขึ้น','Longer time to tap when a fish bites']};
function tool(k){if(!S)return 1;fixLife();return S.tools[k]||1}
// numbers used by the hooks (all measured in tests)
const fishBiteMul=()=>1+.06*(lifeLv('fish')-1)+.08*(tool('rod')-1);
const fishWaitMul=()=>lifeLv('fish')>=7?.7:1;
const digMul=()=>1+.05*(lifeLv('dig')-1)+.08*(tool('shovel')-1);
const farmMul=()=>Math.max(.6,1-.04*(lifeLv('farm')-1));
const cookMul=()=>1+.05*(lifeLv('cook')-1)+(lifeLv('cook')>=7?.25:0);
const brushMul=()=>1+.15*(tool('brush')-1);
// ---- family gift box: kept outside any one player's save so everyone on this device shares it ----
const GIFT={get(){const d=Store.all();return d.gift||[]},put(a){const d=Store.all();d.gift=a.slice(-40);Store.put(d)},add(item,from){const a=this.get();a.push({item,from:from||'',t:Date.now()});this.put(a)}};
function giftFromKid(item){GIFT.add(item,S.name);S.good=(S.good||0)+1;say('🎁 '+t('giftKept'));sfx('pick')}
// hooks ---------------------------------------------------------------------------
{const _pick=pickUp;pickUp=function(d){if(isKid()&&d&&d.k==='item'){giftFromKid(d.item);return}return _pick(d)}}
{const _cf=catchFish;catchFish=function(){const f=FISH[FISHING.fish]||[0];lifeXp('fish',8+f[0]*4);const r=_cf.apply(this,arguments);if(lifeLv('fish')>=5&&Math.random()<.15){S.fishBag=S.fishBag||[];S.fishBag.push(FISHING.fish);setTimeout(()=>say('🐟🐟 '+t('twoFish')),900)}return r}}
{const _dd=doDig;doDig=function(d){const was=DIG;const r=_dd.apply(this,arguments);if(!was&&DIG)lifeXp('dig',8);return r}}
{const _dh=digHit;digHit=function(){const r=_dh.apply(this,arguments);if(lifeLv('dig')>=7&&S){S.coins+=2+lifeLv('dig');}return r}}
{const _ck=cookDish;cookDish=function(id){const ok=_ck.apply(this,arguments);if(ok){lifeXp('cook',12);if(lifeLv('cook')>=5&&Math.random()<.2){const h=HOME.get();h.dishes[id]=(h.dishes[id]||0)+1;HOME.put(h);setTimeout(()=>say('🍽️ '+t('twoDish')),700)}}return ok}}
{const _qr=qResult;qResult=function(q,firstOk){const r=_qr.apply(this,arguments);lifeXp('know',firstOk?10:3);if(firstOk&&lifeLv('know')>=5&&S)S.coins+=Math.floor(lifeLv('know')/2);return r}}
// harvest xp: wrap plotAct and detect a crop that disappeared from the plot
{const _pa=plotAct;plotAct=function(p){const before=(HOME.get().plots||{})[p.i];const r=_pa.apply(this,arguments);const after=(HOME.get().plots||{})[p.i];if(before&&before.st==='ripe'&&!after){lifeXp('farm',12);const h=HOME.get();if(lifeLv('farm')>=7){h.pantry[before.crop]=(h.pantry[before.crop]||0)+1;HOME.put(h)}}return r}}
// knowledge hint: remove one wrong answer (kids with Knowledge 3+, 3 times a day)
function hintBtn(q){if(!S||lifeLv('know')<3||!q)return;const day=new Date().toDateString();if(S.hintDay!==day){S.hintDay=day;S.hintN=0}const box=$('qSay');if(!box)return;const b=document.createElement('button');b.id='qHint';b.textContent='💡 '+t('hint')+' ('+(3-S.hintN)+')';b.style.marginLeft='6px';if(S.hintN>=3)b.disabled=true;
  b.onclick=()=>{if(S.hintN>=3)return;const wrong=[...document.querySelectorAll('.ch button')].filter(x=>+x.dataset.i!==q.answer&&!x.disabled);if(!wrong.length)return;const w=wrong[Math.floor(Math.random()*wrong.length)];w.disabled=true;w.style.opacity=.35;S.hintN++;b.textContent='💡 '+t('hint')+' ('+(3-S.hintN)+')';if(S.hintN>=3)b.disabled=true;sfx('pick')};box.after(b)}
// one-time: gear that a kid carries (not what they hold) moves to the family box
function kidGearMigrate(){if(!S||!isKid())return;S.inv=S.inv||[];
  // repair saves hit by the v0.36 bug (equipped weapon was moved out): give the starter brush-sword back
  if(!S.inv[S.eq]||S.inv[S.eq].slot){S.inv.unshift(mkItem('sw',0));S.eq=0;if(typeof S.eqA==='number')S.eqA++;if(typeof S.eqC==='number')S.eqC++;save()}
  if(S.giftMig2)return;S.giftMig2=1;const keepIdx=[S.eq,S.eqA,S.eqC].filter(i=>typeof i==='number'&&S.inv[i]);const keep=keepIdx.map(i=>S.inv[i]);
  const move=S.inv.filter(i=>!keep.includes(i));if(move.length){move.forEach(i=>GIFT.add(i,S.name));S.inv=keep;const pos=it=>S.inv.indexOf(it);
    const w=S.inv.find(i=>!i.slot),a=S.inv.find(i=>i.slot==='armor'),c=S.inv.find(i=>i.slot==='acc');S.eq=w?pos(w):0;if(S.eqA!=null)S.eqA=a?pos(a):null;if(S.eqC!=null)S.eqC=c?pos(c):null;save()}}
// ---- kid bag: life skills, tools, collections, gift box ----
function lifeBar(k){const L=S.life[k],need=LIFE_NEED(L.lv),pc=L.lv>=10?100:Math.round(L.xp/need*100),d=LIFE.find(x=>x[0]===k);const nxt=Object.keys(LIFE_PERK[k]||{}).map(Number).find(v=>v>L.lv);const pk=nxt?(LIFE_PERK[k][nxt]):null;
  return `<div class="pn" style="margin:0;padding:6px 8px"><b>${d[3]} ${lifeName(k)} Lv${L.lv}</b><div style="height:8px;background:#2a2340;border-radius:4px;margin:4px 0"><div style="height:8px;width:${pc}%;background:#ffd23f;border-radius:4px"></div></div><small>${L.lv>=10?t('maxLv'):(pk?`Lv${nxt}: ${LANG==='en'?pk[1]:pk[0]}`:'')}</small></div>`}
function openKidBag(){fixLife();kidGearMigrate();const g=GIFT.get().filter(x=>x.from===S.name).length;
  const tl=TOOLS.map(([k,th,en,ic])=>{const lv=tool(k),cost=TOOL_COST[lv]||0;return `<div class="pn" style="margin:0;padding:6px 8px;display:flex;align-items:center;gap:8px"><span style="font-size:22px">${ic}</span><div style="flex:1"><b>${LANG==='en'?en:th} Lv${lv}</b><br><small>${LANG==='en'?TOOL_FX[k][1]:TOOL_FX[k][0]}</small></div>${lv>=5?'<small>MAX</small>':`<button data-tool="${k}">⬆️ ${cost}🪙</button>`}</div>`}).join('');
  modal(`<h2>🎒 ${t('kidBag')}</h2><h3>${t('lifeSk')}</h3><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px">${LIFE.map(([k])=>lifeBar(k)).join('')}</div><h3>${t('tools')}</h3><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px">${tl}</div><p class="note">🎁 ${t('giftGiven')}: ${g} · 🪙 ${S.coins}</p><p><button id="kbOther">📦 ${t('otherItems')}</button></p>`);
  document.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{const k=b.dataset.tool,lv=tool(k),c=TOOL_COST[lv];if(S.coins<c){say(t('noCoin'));sfx('wrong');return}S.coins-=c;S.tools[k]=lv+1;sfx('lvl');say('✨ '+(LANG==='en'?TOOLS.find(x=>x[0]===k)[2]:TOOLS.find(x=>x[0]===k)[1])+' Lv'+(lv+1));save();hud();openKidBag()});
  $('kbOther').onclick=()=>{closeModal();_openBag()}}
// adults: gift box button inside the bag
function openGiftBox(){const a=GIFT.get();modal(`<h2>🎁 ${t('giftBox')}</h2>${a.length?a.map((g,i)=>`<div class="it" style="display:flex;gap:6px;align-items:center;width:100%"><span style="flex:1">${itemLine?itemLine(g.item):g.item.name||'?'} <small>· ${t('from')} ${g.from||'?'}</small></span><button data-gi="${i}">${t('take')}</button></div>`).join(''):`<p class="note">${t('giftEmpty')}</p>`}`);
  document.querySelectorAll('[data-gi]').forEach(b=>b.onclick=()=>{const a2=GIFT.get(),g=a2.splice(+b.dataset.gi,1)[0];if(!g)return;GIFT.put(a2);S.inv=S.inv||[];S.inv.push(g.item);sfx('coin');say('🎁 '+t('thanksKid')+' '+(g.from||''));save();openGiftBox()})}
const _openBag=openBag;openBag=function(){if(isKid())return openKidBag();_openBag.apply(this,arguments);const n=GIFT.get().length;const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!document.getElementById('gbBtn')){const b=document.createElement('button');b.id='gbBtn';b.textContent='🎁 '+t('giftBox')+(n?' ('+n+')':'');b.style.marginLeft='8px';b.onclick=openGiftBox;h.after(b)}};

// ================= controls: number keys, dash (light-foot), meditation, gamepad =================
const PADK={prev:[]};let DASH={t:0,cd:0,vx:0,vy:0};const lastMove={x:0,y:1};
function doDash(){if(!S||PAUSE||P.dead||DASH.cd>0||P.sit)return;const d=Math.hypot(lastMove.x,lastMove.y)||1;DASH={t:.2,cd:isKid()?1.8:2.6,vx:lastMove.x/d*460,vy:lastMove.y/d*460};P.path=null;sfx('shoot');for(let i=0;i<10;i++)FX.push({k:'spark',x:P.x,y:P.y-6,vx:(rnd()-.5)*60,vy:-10-rnd()*30,t:0,life:.5})}
function toggleSit(){if(!S||isKid()||P.dead||PAUSE)return;if(P.sit){P.sit=0;return}const near=MONS.some(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<110);if(near){say(t('sitNo'));return}P.sit=1;P.path=null;say('🧘 '+t('sitOn'))}
addEventListener('keydown',e=>{if(!S||PAUSE||DLG)return;const k=e.key;if(k==='1')useSkill();else if(k==='2')useJob((S.slots||[])[0]);else if(k==='3')useJob((S.slots||[])[1]);else if(k==='4')usePotion();else if(k==='Shift')doDash();else if(k==='q'||k==='Q')toggleSit();else if(k==='f'||k==='F'){if(typeof fishNear==='function'&&fishNear())fishAct()}else if(k==='t'||k==='T'){if(typeof openAuto==='function')openAuto()}});
function padPoll(){const gp=(navigator.getGamepads?[...navigator.getGamepads()]:[]).find(g=>g&&g.connected);if(!gp){if(JOY.id==='pad'){JOY.id=null;JOY.x=JOY.y=0}return}
  const ax=gp.axes[0]||0,ay=gp.axes[1]||0;if(Math.hypot(ax,ay)>.25){JOY.id='pad';JOY.x=ax;JOY.y=ay}else if(JOY.id==='pad'){JOY.id=null;JOY.x=JOY.y=0}
  const b=gp.buttons.map(x=>x&&x.pressed),hit=i=>b[i]&&!PADK.prev[i];
  if(hit(0)){if(DIG&&!DIG.done)digHit();else if(DLG)nextLine();else if(typeof fishNear==='function'&&fishNear())fishAct();else if(!PAUSE)autoAct()}
  if(!PAUSE){if(hit(1))useSkill();if(hit(2))useJob((S.slots||[])[0]);if(hit(3))useJob((S.slots||[])[1]);if(hit(4))usePotion();if(hit(5))doDash();if(hit(6))toggleSit()}
  if(hit(9))openSettings();if(hit(8))openBag();if(hit(1)&&PAUSE&&!DLG)closeModal();FISHING.hold=!!b[0]&&FISHING.st==='reel';PADK.prev=b}
{const _up=update;update=function(dt){padPoll();
  // remember facing for the dash; moving or getting hit stands you up from meditation
  let mx=0,my=0;if(keys.ArrowLeft||keys.a)mx--;if(keys.ArrowRight||keys.d)mx++;if(keys.ArrowUp||keys.w)my--;if(keys.ArrowDown||keys.s)my++;if(JOY.id!==null&&Math.hypot(JOY.x,JOY.y)>.2){mx=JOY.x;my=JOY.y}
  if(mx||my){lastMove.x=mx;lastMove.y=my;if(P.sit){P.sit=0}}else if(P.path&&P.path.length){const q=P.path[0];const dx=q[0]-P.x,dy=q[1]-P.y;if(Math.hypot(dx,dy)>2){lastMove.x=dx;lastMove.y=dy}if(P.sit)P.sit=0}
  if(DASH.cd>0)DASH.cd-=dt;
  if(DASH.t>0&&!PAUSE){DASH.t-=dt;for(let s=0;s<4;s++){const nx=P.x+DASH.vx*dt/4,ny=P.y+DASH.vy*dt/4;if(!blockedAt(M,nx,P.y))P.x=nx;if(!blockedAt(M,P.x,ny))P.y=ny}if(Math.random()<.6)FX.push({k:'spark',x:P.x,y:P.y-4,vx:0,vy:-10,t:0,life:.35})}
  if(P.sit&&S&&!isKid()){const fire=M.fire&&Math.hypot(M.fire.x-P.x,M.fire.y-P.y)<90?2:1;P.sitT=(P.sitT||0)+dt;if(P.sitT>.5){P.sitT=0;S.hp=Math.min(hpMax(),S.hp+Math.ceil(hpMax()*.03*fire));hud()}if(Math.random()<.08)FX.push({k:'spark',x:P.x+(rnd()-.5)*20,y:P.y-20,vx:0,vy:-25,t:0,life:.8})}
  return _up.apply(this,arguments)}}
{const _hp=hurtPlayer;hurtPlayer=function(n){if(P.sit)P.sit=0;if(DASH.t>0&&!isKid())return;return _hp.apply(this,arguments)}}
function addCtlButtons(){const sk=$('bSk');if(!sk||$('bDash'))return;const mk=(id,ic,lab,fn)=>{const b=sk.cloneNode(true);b.id=id;b.innerHTML=`${ic}<small>${lab}</small>`;b.onclick=fn;sk.parentNode.insertBefore(b,sk);return b};mk('bDash','💨',t('dash'),doDash);mk('bSit','🧘',t('sit'),toggleSit)}
function ctlVis(){const d=$('bDash'),s=$('bSit');if(!d)return;s.style.display=S&&!isKid()?'':'none';d.style.display=S&&!kidUI()?'':'none'}

// ================= fishing: the sea (beach) and the waterfall, each with its own fish =================
// new fish appended to FISH: [difficulty, min cm, max cm, hours, price, exp, colour]
const FISH_BASE=FISH.length;
FISH.push([0,10,18,null,6,5,'#6ab0e0'],[1,8,14,null,9,7,'#ff8a3d'],[1,20,40,[5,10],14,10,'#8fd0c8'],[2,30,70,null,22,16,'#c05a7a'],[2,15,25,[19,23],26,18,'#ffe066'],[4,80,150,[23,3],140,90,'#5ad8ff'],
  [0,8,15,null,5,4,'#b8c8a0'],[1,20,35,[5,9],12,9,'#e8a8c8'],[2,40,80,null,24,18,'#f0a040'],[2,10,18,'light',28,20,'#c0f0ff'],[3,25,45,[16,19],40,30,'#a0e080'],[4,50,90,[4,6],120,80,'#ffe8a0']);
const FLOC={lake:[0,1,2,3,4,5,6,7,8,9,10,11],beach:[FISH_BASE,FISH_BASE+1,FISH_BASE+2,FISH_BASE+3,FISH_BASE+4,FISH_BASE+5],falls:[FISH_BASE+6,FISH_BASE+7,FISH_BASE+8,FISH_BASE+9,FISH_BASE+10,FISH_BASE+11]};
const FLOCW=[5,4,3,2,1.2,.15];
function fishWeights(){const id=M&&M.id,pool=FLOC[id]||FLOC.lake;let base=id==='lake'||!FLOC[id]?fwNow().filter(([i])=>pool.includes(i)):pool.map((i,k)=>[i,FLOCW[k]]);
  if(isRainy()&&FLOC[id]&&id!=='lake')base=base.map(([i,w])=>[i,FISH[i][0]>=2?w*1.8:w]);
  const lv=lifeLv('fish');return base.map(([i,w])=>[i,w*(FISH[i][0]>=2&&lv>=3?1.4:1)*(FISH[i][0]>=4&&lv>=10?3:1)])}
function rollFish(){const h=new Date().getHours(),pool=fishWeights().filter(([i])=>hourOk(h,FISH[i][3]));const tot=pool.reduce((a,[,w])=>a+w,0);let r=Math.random()*tot;for(const [i,w] of pool){if((r-=w)<=0)return i}return pool.length?pool[0][0]:0}
function buildBeach(){SEED=61;const m=newMap('beach','town',34,22,61);m.nameKey='beach';m.theme='beach';
  for(let y=0;y<m.h+1;y++)for(let x=-1;x<m.w+1;x++){const shore=13+Math.round(1.6*Math.sin(x*.42)+.8*Math.sin(x*1.1));if(y>=shore||(x>=27&&y>=8+Math.round(Math.sin(y*.7))))m.WATER.add(key(x,y))}
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(!m.WATER.has(key(x,y)))m.PATH.add(key(x,y))};
  for(let x=0;x<27;x++){const shore=13+Math.round(1.6*Math.sin(x*.42)+.8*Math.sin(x*1.1));pr(x,shore-3,x,shore-1)}pr(0,7,6,8);
  m.WATER.forEach(k=>m.SOLID.add(k));
  const px=15,top=13+Math.round(1.6*Math.sin(px*.42)+.8*Math.sin(px*1.1));for(let y=top-1;y<=top+4;y++)for(const x of [px-1,px])m.SOLID.delete(key(x,y));m.decks.push({img:'pier',x:px*T,y:(top-1)*T+8,oy:0});
  m.fishSpot={x:px*T-16,y:(top+3)*T+10,wx:px*T-16,wy:(top+5)*T+8};
  [['palm',3,4],['palm',9,3],['palm',20,4],['palm',24,6],['bananaB',12,5],['frangi',17,6],['palm',2,10],['bananaB',22,9],['roundA',6,2],['pink',14,2]].forEach(a=>addTree(m,...a));
  addDeco(m,'rocks',26,10,0);addDeco(m,'boulder',25,12,1);addDeco(m,'grass',8,8,0);addDeco(m,'flowers',18,8,0);addProp(m,'lamp',13,9);
  addNpc(m,'mom',19,10,2);
  m.exits.push({id:'w',x:14,y:7.5*T,to:'lake',toExit:'e',label:'lake'});m.spawnDefault=[2*T,7.5*T];return m}
function buildFalls(){SEED=67;const m=newMap('falls','town',34,22,67);m.nameKey='falls';m.falls={x0:15*T,x1:19*T,y0:0,y1:8*T};
  for(let x=-1;x<=m.w;x++)for(let y=-1;y<=5+Math.round(Math.sin(x*.6));y++)if(x<15||x>18)m.CLIFF.add(key(x,y));
  for(let y=-1;y<=8;y++)for(let x=15;x<=18;x++)m.WATER.add(key(x,y));
  for(let y=0;y<m.h+1;y++)for(let x=0;x<m.w;x++){const dx=(x-16.5)/6.5,dy=(y-11.5)/3.6;if(dx*dx+dy*dy<1)m.WATER.add(key(x,y))}
  for(let y=14;y<m.h+1;y++){const c=16+Math.round(1.3*Math.sin(y*.5));m.WATER.add(key(c,y));m.WATER.add(key(c+1,y))}
  m.CLIFF.forEach(k=>m.SOLID.add(k));m.WATER.forEach(k=>m.SOLID.add(k));
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(!m.WATER.has(key(x,y))&&!m.CLIFF.has(key(x,y)))m.PATH.add(key(x,y))};pr(0,11,9,12);pr(9,9,10,14);
  const br=[];for(const y of [17,18])for(let x=0;x<m.w;x++)if(m.WATER.has(key(x,y))){m.SOLID.delete(key(x,y));br.push(x)}m.decks.push({img:'bridgeRope',x:(Math.min(...br)+Math.max(...br)+1)/2*T,y:18*T,oy:61});
  m.fishSpot={x:9.5*T,y:11.5*T,wx:11.5*T,wy:11.5*T};
  [['pine',2,8],['pineTwin',4,15],['pine2',1,18],['pineThick',7,19],['pine',12,19],['pineYoung',23,16],['pine',26,9],['pineThick',29,12],['pine2',31,17],['roundA',22,20],['pineBird',28,7],['pink',6,7]].forEach(a=>addTree(m,...a));
  addDeco(m,'mossRock',11,8,0);addDeco(m,'fern',22,8,0);addDeco(m,'boulder',24,12,1);addDeco(m,'flowers',5,13,0);addDeco(m,'berry',27,19,1);addDeco(m,'log',20,14,1);
  m.exits.push({id:'w',x:14,y:11.5*T,to:'mountain',toExit:'e',label:'mountain'});m.spawnDefault=[2*T,11.5*T];return m}
MAPS.beach=buildBeach;MAPS.falls=buildFalls;
// waterfall + surf animation drawn over the ground
function drawWater2(tm){if(M.falls){const f=M.falls;ctx.save();for(let i=0;i<34;i++){const x=f.x0+((i*37)%(f.x1-f.x0)),y=((i*53+tm*260)%(f.y1-f.y0+40))-20;if(x-camX<-10||x-camX>VW+10)continue;ctx.fillStyle=i%3?'rgba(255,255,255,.55)':'rgba(190,235,255,.7)';ctx.fillRect(Math.round(x-camX),Math.round(y-camY),2,10)}
    ctx.fillStyle='rgba(255,255,255,.5)';for(let i=0;i<14;i++){const a=i/14*Math.PI*2+tm*1.4,r=18+6*Math.sin(tm*3+i);ctx.beginPath();ctx.arc(Math.round((f.x0+f.x1)/2+Math.cos(a)*r*1.6-camX),Math.round(f.y1+10+Math.sin(a)*r*.5-camY),3,0,7);ctx.fill()}ctx.restore()}
  if(M.id==='beach'){ctx.save();ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=2;for(let x=0;x<27;x++){const shore=13+Math.round(1.6*Math.sin(x*.42)+.8*Math.sin(x*1.1)),o=Math.sin(tm*1.6+x*.6)*3;ctx.beginPath();ctx.moveTo(x*T-camX,shore*T+4+o-camY);ctx.lineTo(x*T+T-camX,shore*T+4+Math.sin(tm*1.6+(x+1)*.6)*3-camY);ctx.stroke()}ctx.restore()}}

{const _hud=hud;hud=function(){const r=_hud.apply(this,arguments);try{addCtlButtons();ctlVis()}catch(e){}return r}}

// ================= adults: detailed stats, qi (ปราณ), promotions, meditation regen, limited auto, goodness =================
// Qi: permanent passive points (1 per level from Lv10). Tiers unlock with promotions. Free reset until Lv30.
const QI=[['combo',1,20,'โจมตีต่อเนื่อง','Double strike','ตีปกติมีโอกาสตีซ้ำ +1%/แต้ม','Normal hits may strike twice +1%/pt'],['cdmg',1,20,'แรงคริ','Crit power','แรงคริ +2%/แต้ม','Crit damage +2%/pt'],['hp',1,20,'กายแกร่ง','Tough body','เลือดสูงสุด +1%/แต้ม','Max HP +1%/pt'],
  ['acc',2,20,'ตาเหยี่ยว','Hawk eye','ความแม่นยำ +2/แต้ม','Accuracy +2/pt'],['eva',2,20,'เงาพริ้ว','Drifting shadow','หลบหลีก +0.5%/แต้ม','Evade +0.5%/pt'],['regen',2,20,'ปราณไหล','Flowing qi','ฟื้นเลือด +5%/แต้ม','Regen +5%/pt'],
  ['cdr',3,15,'ใจแน่วแน่','Steady mind','คูลดาวน์ท่า −1%/แต้ม','Skill cooldown −1%/pt'],['boss',3,15,'ใจสิงห์','Lion heart','ตีบอสแรงขึ้น +1.5%/แต้ม','Damage to bosses +1.5%/pt']];
function qi(k){if(!S||isKid()||!S.qi)return 0;const d=QI.find(x=>x[0]===k);if(!d||(S.tier||1)<d[1]||!S.job)return 0;return S.qi[k]||0}
const qiTotal=()=>S?Math.max(0,S.lv-9):0,qiSpent=()=>S&&S.qi?Object.values(S.qi).reduce((a,b)=>a+b,0):0;
// promotions: tier 1 = job chosen at Lv10 · tier 2 Lv30 · tier 3 Lv50, each with a quest from the wizard
const TIER_NAME={sword:['นักดาบ','อัศวินแสง','จอมดาบรุ่งอรุณ','Swordsman','Knight of Light','Dawn Blade Master'],archer:['นักธนู','พรานเหยี่ยว','จอมธนูดาวตก','Archer','Hawk Ranger','Shooting Star Archer'],mage:['นักเวท','ผู้ใช้เวทคริสตัล','ปราชญ์แห่งแสง','Mage','Crystal Caster','Sage of Light'],hunter:['นักล่าสมบัติ','นักสำรวจเงา','ตำนานนักล่าสมบัติ','Treasure Hunter','Shadow Explorer','Legendary Hunter']};
const TIER_Q={2:{lv:30,kills:60,chap:3},3:{lv:50,kills:120,chap:5}};
const tierBonus=()=>S&&!isKid()?[0,0,.08,.15][S.tier||1]:0;
function tierName(){const n=TIER_NAME[S.job];if(!n)return'';const i=(S.tier||1)-1;return LANG==='en'?n[3+i]:n[i]}
// numbers
const accVal=()=>12+ST('dex')*1.2+S.lv*.6+qi('acc')*2;
const monEva=mo=>6+((M&&M.mul)||1)*4+(mo.boss?6:0);
const hitCh=mo=>isKid()?1:Math.max(.65,Math.min(1,.88+(accVal()-monEva(mo))*.01));
const critMul=()=>(S.job==='hunter'?1.65:1.5)+qi('cdmg')*.02+((gear().cdmg||0)/100);
const regenPS=()=>isKid()?0:Math.max(1,hpMax()*.01)*(1+qi('regen')*.05);
// hooks into the existing formulas
{const _hm=hpMax;hpMax=function(){return Math.round(_hm()*(1+qi('hp')*.01)*(1+tierBonus()))}}
{const _ap=atkPow;atkPow=function(){return Math.round(_ap.apply(this,arguments)*(1+tierBonus()))}}
{const _fc=fleeCh;fleeCh=function(){return Math.min(.65,_fc()+qi('eva')*.005)}}
{const _cd=cdrMul;cdrMul=function(){return Math.max(.45,_cd()-qi('cdr')*.01)}}
let lastHurt=0,S_combo=0;{const _h2=hurtPlayer;hurtPlayer=function(n){lastHurt=performance.now();return _h2.apply(this,arguments)}}
{const _mh=monHit;monHit=function(mo,dmg,src,type){const was=!!(mo&&mo.happy);if(src!=='net'&&mo&&!mo.happy&&!isKid()){if(Math.random()>hitCh(mo)){TXT.push({x:mo.x,y:mo.y-(mo.h||20)-12,s:'MISS',c:'#c8c8d8',t:0});return}
    if(mo.boss)dmg=Math.round(dmg*(1+qi('boss')*.015));if(Math.random()<qi('combo')*.01){dmg*=2;TXT.push({x:mo.x+10,y:mo.y-(mo.h||20)-26,s:'×2',c:'#ffd23f',t:0})}}
  const r=_mh.call(this,mo,dmg,src,type);if(mo&&!was&&mo.happy&&src!=='net'&&S&&!isKid()&&!mo.boss){S.tq=S.tq||{};S.tq.kills=(S.tq.kills||0)+1;goodTick()}return r}}
// crit power: replace the fixed crit multiplier
function goodTick(){if(!Net||!Net.online)return;const kid=Object.values(Net.others||{}).some(o=>o.p&&o.p.a&&o.p.m===Net.mapKey?.());if(kid){S.goodN=(S.goodN||0)+1;if(S.goodN%5===0){S.good=(S.good||0)+1;if([20,60,150].includes(S.good))say('💛 '+t('goodTitle')+' '+goodTitle())}}}
function goodTitle(){const g=S.good||0;return g>=150?t('good3'):g>=60?t('good2'):g>=20?t('good1'):''}
// regen out of combat (adults)
{const _up2=update;update=function(dt){const r=_up2.apply(this,arguments);if(S&&!isKid()&&!P.dead&&!PAUSE&&S.hp<hpMax()&&performance.now()-lastHurt>4000&&!MONS.some(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<150)){P.rgT=(P.rgT||0)+dt;if(P.rgT>=1){P.rgT=0;S.hp=Math.min(hpMax(),S.hp+Math.round(regenPS()));hud()}}autoTick(dt);return r}}
// ---- Qi panel ----
function openQi(){if(isKid())return;if(!S.job){say(t('jobNeed'));return}S.qi=S.qi||{};const left=qiTotal()-qiSpent();
  const rows=QI.map(([k,tier,max,th,en,dth,den])=>{const lock=(S.tier||1)<tier,v=S.qi[k]||0;return `<div class="pn" style="margin:4px 0;opacity:${lock?.45:1}"><b>${LANG==='en'?en:th}</b> <small>${v}/${max}</small><br><small>${LANG==='en'?den:dth}${lock?' · 🔒 '+t('tierNeed')+' '+tier:''}</small><div style="float:right;margin-top:-26px">${lock?'':`<button data-qi="${k}" data-n="1" ${left<1||v>=max?'disabled':''}>+1</button><button data-qi="${k}" data-n="5" ${left<1||v>=max?'disabled':''}>+5</button>`}</div></div>`}).join('');
  const cost=S.lv<30?0:S.lv*50;modal(`<h2>☯️ ${t('qiT')}</h2><p class="note">${t('qiLeft')}: <b>${left}</b> · ${t('qiHow')}</p>${rows}<p><button id="qiReset">🔄 ${t('qiReset')} ${cost?cost+'🪙':t('free')}</button></p>`);
  document.querySelectorAll('[data-qi]').forEach(b=>b.onclick=()=>{const k=b.dataset.qi,max=QI.find(x=>x[0]===k)[2];const n=Math.min(+b.dataset.n,qiTotal()-qiSpent(),max-(S.qi[k]||0));if(n<=0)return;S.qi[k]=(S.qi[k]||0)+n;sfx('pick');save();hud();openQi()});
  $('qiReset').onclick=()=>{if(S.coins<cost){say(t('noCoin'));return}S.coins-=cost;S.qi={};sfx('lvl');save();hud();openQi()}}
// ---- promotion panel (added to the wizard's job screen) ----
function promoHtml(){if(!S.job)return'';const tr=S.tier||1;if(tr>=3)return `<div class="pn"><b>👑 ${tierName()}</b> · ${t('tierMax')}</div>`;const q=TIER_Q[tr+1],k=(S.tq&&S.tq.kills)||0,st=S.tq&&S.tq.on===tr+1;
  const okLv=S.lv>=q.lv,okCh=(S.chap||2)>=q.chap,okK=st&&k>=q.kills;return `<div class="pn"><b>⭐ ${t('promo')} ${tr+1}: ${(LANG==='en'?TIER_NAME[S.job][3+tr]:TIER_NAME[S.job][tr])}</b><br><small>${okLv?'✅':'⬜'} Lv${q.lv} · ${okCh?'✅':'⬜'} ${t('chapN')} ${q.chap} · ${st?(okK?'✅':'⬜')+` ${t('calmN')} ${Math.min(k,q.kills)}/${q.kills}`:'⬜ '+t('calmN')+' '+q.kills}</small><br>${!st?`<button id="tqStart" ${okLv?'':'disabled'}>${t('tqStart')}</button>`:`<button id="tqDone" ${okLv&&okCh&&okK?'':'disabled'}>${t('tqDone')}</button>`}</div>`}
{const _oj=openJobs;openJobs=function(){const r=_oj.apply(this,arguments);if(S&&S.lv>=10&&S.job){const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h){const d=document.createElement('div');d.innerHTML=promoHtml()+`<p><button id="qiOpen">☯️ ${t('qiT')}</button></p>`;h.after(d);
    const st=$('tqStart');if(st)st.onclick=()=>{S.tq={on:(S.tier||1)+1,kills:0};save();sfx('pick');say('📜 '+t('tqGo'));openJobs()};const dn=$('tqDone');if(dn)dn.onclick=()=>{S.tier=(S.tier||1)+1;S.tq=null;S.hp=hpMax();sfx('lvl');save();hud();say('👑 '+tierName()+'!');for(let i=0;i<50;i++)FX.push({k:'star',x:P.x,y:P.y-40,vx:(rnd()-.5)*120,vy:-60-rnd()*80,t:0,life:1.3});openJobs()};$('qiOpen').onclick=openQi}}return r}}
// ---- detailed stats (adults) appended to the stats screen ----
{const _os=openStats;openStats=function(){const r=_os.apply(this,arguments);if(S&&!isKid()){const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('stDetail')){const d=document.createElement('div');d.id='stDetail';d.className='pn';
    const red=Math.round((1-50/(50+defVal()))*100),row=(a,b)=>`<div class="row2" style="justify-content:space-between"><span>${a}</span><b>${b}</b></div>`;
    d.innerHTML=`<b>📐 ${t('detail')}</b>${tierName()?` · 👑 ${tierName()}`:''}${goodTitle()?` · 💛 ${goodTitle()}`:''}`+row(t('dAtk'),atkPow())+row(t('dAcc'),Math.round(accVal()))+row(t('dCrit'),Math.round(critCh()*100)+'%')+row(t('dCdmg'),Math.round(critMul()*100)+'%')+row(t('dEva'),Math.round(fleeCh()*100)+'%')+row(t('dRed'),red+'%')+row(t('dRegen'),Math.round(regenPS())+'/s')+row(t('dAspd'),Math.round(aspdMul()*100)+'%')+row('💛 '+t('good'),S.good||0)+`<p><button id="qiOpen2">☯️ ${t('qiT')}</button></p>`;
    h.after(d);$('qiOpen2').onclick=openQi}}return r}}
// ---- limited auto (adults): only on floors you have already cleared, never bosses, never quizzes ----
const AUTO={on:false,t:0,cfg:null};
function autoCfg(){S.auto=S.auto||{pot:35,sit:45,stand:90,lvl:6};return S.auto}
function mapCleared(){if(!M||M.kind!=='cave')return false;S.cleared=S.cleared||{};if(S.cleared[M.id])return true;const all=M.crystals&&M.crystals.length&&M.crystals.every(c=>c.awake);if(all){S.cleared[M.id]=1;return true}return false}
function openAuto(){if(isKid())return;const c=autoCfg(),ok=mapCleared();
  const sl=(id,v,a,b,lab)=>`<div class="row2" style="margin:6px 0"><span style="width:150px">${lab}</span><input type="range" id="${id}" min="${a}" max="${b}" value="${v}" style="flex:1"><b id="${id}v" style="width:40px;text-align:right">${v}</b></div>`;
  modal(`<h2>🤖 ${t('autoT')}</h2><p class="note">${ok?t('autoOk'):t('autoNo')}</p><div class="pn">✅ ${t('autoR1')}<br>✅ ${t('autoR2')}<br>✅ ${t('autoR3')}</div>${sl('aPot',c.pot,0,80,t('aPot')+' %')}${sl('aSit',c.sit,0,90,t('aSit')+' %')}${sl('aStand',c.stand,50,100,t('aStand')+' %')}<p><button id="aGo" ${ok?'':'disabled'}>${AUTO.on?'⏹️ '+t('autoStop'):'▶️ '+t('autoStart')}</button></p>`);
  ['aPot','aSit','aStand'].forEach(id=>$(id).oninput=e=>{$(id+'v').textContent=e.target.value;const k={aPot:'pot',aSit:'sit',aStand:'stand'}[id];c[k]=+e.target.value;save()});
  $('aGo').onclick=()=>{AUTO.on=!AUTO.on;closeModal();say(AUTO.on?'🤖 '+t('autoStart'):'⏹️ '+t('autoStop'))}}
function autoTick(dt){if(!AUTO.on||!S)return;if(isKid()||!mapCleared()){AUTO.on=false;return}if(PAUSE||DLG||P.dead)return;AUTO.t-=dt;if(AUTO.t>0)return;AUTO.t=.4;const c=autoCfg(),hp=S.hp/hpMax()*100;
  if(hp<=c.pot&&(S.potions||0)>0){usePotion();return}
  const near=MONS.filter(o=>!o.happy&&!o.boss).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y));
  if(P.sit){if(hp>=c.stand)P.sit=0;return}
  if(hp<=c.sit&&!(near[0]&&Math.hypot(near[0].x-P.x,near[0].y-P.y)<110)){toggleSit();return}
  if(P.target&&!P.target.happy)return;const mo=near[0];if(mo)attackTarget(mo)}
{const _ac=addCtlButtons;addCtlButtons=function(){_ac();const sk=$('bSk');if(!sk||$('bAuto'))return;const b=sk.cloneNode(true);b.id='bAuto';b.innerHTML=`🤖<small>${t('autoBtn')}</small>`;b.onclick=openAuto;sk.parentNode.insertBefore(b,sk)}}
{const _cv=ctlVis;ctlVis=function(){_cv();const a=$('bAuto');if(a)a.style.display=S&&!isKid()&&S.lv>=10?'':'none';if(a)a.style.outline=AUTO.on?'2px solid #7fffa0':''}}
{const _gm=goMap;goMap=function(){AUTO.on=false;if(P)P.sit=0;return _gm.apply(this,arguments)}}

// ================= story: 6 lands and an ending =================
// Chapter 1 village + crystal cave · 2 stone guardian (cave 3) · 3 glowing mushroom forest · 4 pyramid desert · 5 underground lake · 6 sky castle → ending
const LANDS={3:['forest','fire','mushking',2.8],4:['desert','storm','sphinx',3.6],5:['ulake','ice','turtle',4.4],6:['sky','storm','mist',5.2]};
for(const [ch,[th,el,boss,mul]] of Object.entries(LANDS)){const n=+ch,a=th+'1',b=th+'2',sd=7000+n*100;
  CAVE_CFG[a]={gw:4,gh:3,branch:2,seed:sd+1,crystals:5,digs:4,mons:[['slime',4+n],['mushbug',3+Math.floor(n/2)],['bat',2+Math.floor(n/2)]],next:b,up:th==='ulake'?'lake':'plaza',upExit:th==='ulake'?'cave':'x',mul,theme:th,land:n,floor:1};
  CAVE_CFG[b]={gw:4,gh:3,branch:1,seed:sd+37,crystals:3,digs:3,mons:[['mushbug',4+Math.floor(n/2)],['slime',3+Math.floor(n/2)]],boss:true,bossEl:el,up:a,upExit:'down',mul:mul+.4+(n===6?.6:0),theme:th,land:n,floor:2,bossName:boss};
  MAPS[a]=()=>buildCave(a);MAPS[b]=()=>buildCave(b)}
const THEME={forest:{f:[[30,42,22],[48,70,34],[70,98,46],[98,128,62],[132,160,86]],w:[[10,30,26],[18,48,40],[28,68,54],[44,92,70]],tint:'hue-rotate(70deg) saturate(1.1)',bright:0},
  desert:{f:[[112,82,44],[160,120,62],[196,154,88],[222,190,120],[242,220,158]],w:[[70,40,24],[106,60,34],[140,84,46],[176,112,64]],tint:'sepia(.55) saturate(1.3) hue-rotate(-12deg)',bright:1},
  ulake:{f:[[36,50,74],[50,72,104],[70,96,138],[90,122,166],[122,154,192]],w:[[12,20,40],[20,34,62],[28,48,88],[40,66,116]],tint:'hue-rotate(185deg) saturate(1.1)',bright:0},
  sky:{f:[[150,140,170],[182,172,200],[210,202,224],[232,226,240],[246,242,250]],w:[[96,84,140],[128,114,176],[160,146,206],[196,186,232]],tint:'brightness(1.2) saturate(.8)',bright:1},
  beach:{f:[[184,152,88],[208,176,112],[224,200,136],[238,220,170],[248,236,200]],sandOnly:1}};
function themeGround(m){const th=THEME[m.theme];if(!th||!m.ground)return;const c=m.ground,g=c.getContext('2d'),d=g.getImageData(0,0,c.width,c.height),p=d.data;
  const pick=(ramp,l,lo,hi)=>ramp[Math.max(0,Math.min(ramp.length-1,Math.floor((l-lo)/(hi-lo+1e-6)*ramp.length)))];
  // the ground uses a small palette, so each distinct colour is classified once (cache) instead of per pixel
  const cache=new Map(),NONE=-1;
  for(let i=0;i<p.length;i+=4){if(p[i+3]<10)continue;const key=(p[i]<<16)|(p[i+1]<<8)|p[i+2];let v=cache.get(key);
    if(v===undefined){const [h,s,l]=hslOf(p[i]/255,p[i+1]/255,p[i+2]/255),cc=(Math.max(p[i],p[i+1],p[i+2])-Math.min(p[i],p[i+1],p[i+2]))/255;let c2=null;
      if(th.sandOnly){if(h>=12&&h<=50&&cc>.1&&l>.12&&l<.75)c2=pick(th.f,l,.12,.75)}
      else if(h>=220&&h<=320&&cc>.03)c2=pick(th.w,l,.03,.55);else if(h>=5&&h<=60&&cc>.05)c2=pick(th.f,l,.05,.7);else if(cc<.06&&l<.25)c2=pick(th.w,l,0,.25);
      v=c2?(c2[0]<<16)|(c2[1]<<8)|c2[2]:NONE;cache.set(key,v)}
    if(v!==NONE){p[i]=v>>16;p[i+1]=(v>>8)&255;p[i+2]=v&255}}g.putImageData(d,0,0);if(th.bright)m.bright=1}
{const _gm2=getMap;getMap=function(id){const had=!!CACHE[id];const m=_gm2.apply(this,arguments);if(!had&&m&&!m._themed){const C=CAVE_CFG[id]||{};if(C.theme)m.theme=C.theme;if(m.theme){themeGround(m);m._themed=1}if(C.land){m.land=C.land;m.floor=C.floor;m.bossName=C.bossName||null}}return m}}
// monster colours per land: tinted once per sprite and cached (a ctx.filter on every frame cost 44 fps in t66)
const TINT={forest:{h:70,s:1.1,l:1},desert:{h:0,s:1.2,l:1.05,to:36,mix:.6},ulake:{h:185,s:1.1,l:1},sky:{h:0,s:.8,l:1.2}},TCACHE={};
function tintCanvas(src,tp){const c=document.createElement('canvas');c.width=src.width;c.height=src.height;const g=c.getContext('2d');g.drawImage(src,0,0);const d=g.getImageData(0,0,c.width,c.height),p=d.data;
  for(let i=0;i<p.length;i+=4){if(p[i+3]<8)continue;let [h,s,l]=hslOf(p[i]/255,p[i+1]/255,p[i+2]/255);h=(h+tp.h+360)%360;if(tp.to!==undefined){let dh=((tp.to-h+540)%360)-180;h=(h+dh*tp.mix+360)%360}s=Math.min(1,s*tp.s);l=Math.min(1,l*tp.l);const [r,g2,b]=rgbOf(h,Math.min(1,s),l);p[i]=Math.round(r*255);p[i+1]=Math.round(g2*255);p[i+2]=Math.round(b*255)}g.putImageData(d,0,0);return c}
function tintedArt(key,theme){const tp=TINT[theme];if(!tp||!MON_ART[key])return null;const ck=theme+'|'+key;if(!TCACHE[ck])TCACHE[ck]=MON_ART[key].map(fr=>tintCanvas(fr,tp));return TCACHE[ck]}
{const _dm=drawMon;drawMon=function(mo,tm){const th=M&&M.theme;if(!th||!TINT[th])return _dm.apply(this,arguments);const key=mo.kind+(mo.happy?1:0),art=tintedArt(key,th);if(!art)return _dm.apply(this,arguments);const orig=MON_ART[key];MON_ART[key]=art;try{return _dm.apply(this,arguments)}finally{MON_ART[key]=orig}}}
// scenes (speakers: leah · peb · the four land guardians)
const LAND_BOSS={mushking:1,sphinx:1,turtle:1,mist:1};
Object.assign(SCENES,{L3in:[['leah','s3a'],['peb','s3b']],L3boss:[['mushking','s3c'],['leah','s3d']],L3win:[['mushking','s3e'],['mushking','s3f'],['leah','s3g']],
  L4in:[['leah','s4a'],['peb','s4b']],L4boss:[['sphinx','s4c'],['leah','s4d']],L4win:[['sphinx','s4e'],['sphinx','s4f'],['peb','s4g']],
  L5in:[['leah','s5a'],['peb','s5b']],L5boss:[['turtle','s5c'],['leah','s5d']],L5win:[['turtle','s5e'],['turtle','s5f'],['leah','s5g']],
  L6in:[['leah','s6a'],['peb','s6b']],L6boss:[['mist','s6c'],['leah','s6d']],L6win:[['mist','s6e'],['leah','s6f'],['mist','s6g']],
  ending:[['peb','e1'],['leah','e2'],['guardian','e3'],['leah','e4']]});
{const _sl=showLine;showLine=function(){const [who]=DLG.lines[DLG.i];if(LAND_BOSS[who]){DLG.lines[DLG.i]=DLG.lines[DLG.i];const r=_sl.apply(this,arguments);const c=$('dlgP'),g=c.getContext('2d');const a=MON_ART.golem1&&MON_ART.golem1[0];if(a){g.clearRect(0,0,64,64);const th=THEME[{mushking:'forest',sphinx:'desert',turtle:'ulake',mist:'sky'}[who]];if(th&&th.tint)g.filter=th.tint;g.drawImage(a,4,6,56,56);g.filter='none'}return r}return _sl.apply(this,arguments)}}
function chap(){return S?(S.chap||(S.boss?3:1)):1}
function setChap(n){if(!S)return;S.chap=Math.max(chap(),n);TX.th.town='เมืองพาเพลิน · บทที่ '+Math.min(6,S.chap);TX.en.town='Paphloen Town · Chapter '+Math.min(6,S.chap);save()}
{const _bw=bossWin;bossWin=function(){const r=_bw.apply(this,arguments);setChap(3);setTimeout(()=>{try{celebrate()}catch(e){}},1700);setTimeout(()=>say('🌀 '+t('landOpen')+' '+t('forest1')),9000);return r}}
// entering land floors: scenes; lake's coral cave opens at chapter 5
{const _gm3=goMap;goMap=function(){const r=_gm3.apply(this,arguments);try{if(S)setChap(chap());if(S&&M&&/^cave[123]$/.test(M.id)&&chap()<2)setChap(2);if(M&&M.id==='lake'){const e=M.exits.find(x=>x.id==='cave');if(e&&chap()>=5){e.locked=0;e.to='ulake1';e.toExit='up';e.label='ulake1'}}
  if(M&&M.land){const L=M.land;setTimeout(()=>{if(!M||M.land!==L||DLG)return;playScene(M.floor===1?'L'+L+'in':'L'+L+'boss');if(M.floor===2&&M.boss)say('⚠️ '+t('n_'+M.bossName))},900)}}catch(e){}return r}}
// a land guardian calmed (works for co-op too: checked every frame)
{const _up3=update;update=function(dt){const r=_up3.apply(this,arguments);if(S&&M&&M.land&&M.floor===2&&M.boss&&M.boss.happy&&!M.landDone){M.landDone=1;const L=M.land;setChap(L+1);bump('land'+L);
    LIGHT=1;for(let i=0;i<70;i++)FX.push({k:'star',x:M.boss.x+(rnd()-.5)*70,y:M.boss.y-40+(rnd()-.5)*50,vx:(rnd()-.5)*90,vy:-40-rnd()*70,t:0,life:1.5});
    S.landWon=S.landWon||{};const first=!S.landWon[L];S.landWon[L]=1;save();setTimeout(()=>{if(!first){say('🌟 '+t('n_'+M.bossName)+' · '+t('againWin'));return}playScene('L'+L+'win',()=>{celebrate();if(L===6)startEnding();else{showCard(t('chDone')+' '+L,t('landOpen')+' '+t(LANDS[L+1][0]+'1'));sfx('lvl')}})},1700)}return r}}
// ending + credits
function startEnding(){S.seen=S.seen||{};delete S.seen.ending;S.ended=1;bump('ending');save();playScene('ending',showCredits)}
function showCredits(){const st=`🗺️ ${t('crLands')}: 6/6 · 💎 ${typeof totalCrystals==='function'?totalCrystals():0} · 🐟 ${Object.keys(S.fish||{}).length} · 🧹 ${CNT('help')} · ⭐ Lv${S.lv}`;
  modal(`<div style="text-align:center"><h2>🌈 ${t('crTitle')}</h2><div id="crRoll" style="height:190px;overflow:hidden;position:relative"><div id="crIn" style="position:absolute;width:100%;top:190px;line-height:1.9">
    <p><b>🏮 Lantern Academy</b></p><p class="note">L · A — for Leah</p><p>${t('crStory')}</p><p>🧒 ${t('crKids')}</p><p>👨‍👩‍👧 ${t('crFam')}</p><p>🎨 PixelLab · 🤖 Claude</p><p>💛 ${t('crThanks')}</p><p>${st}</p></div></div>
    <p class="note">${t('crAfter')}</p><button id="crOk">✨ ${t('crCont')}</button></div>`);
  let y=190;const iv=setInterval(()=>{const el=$('crIn');if(!el){clearInterval(iv);return}y-=1;el.style.top=y+'px';if(y<-el.offsetHeight)y=190},30);$('crOk').onclick=()=>{clearInterval(iv);closeModal();showCard(t('crTitle'),t('crAfter'))};sfx('lvl')}
// travel: lands appear in the warp menu once unlocked
{const _ow=openWarp;openWarp=function(){const r=_ow.apply(this,arguments);const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(!h||!S)return r;const ch=chap(),rows=[];
  for(const [n,[th]] of Object.entries(LANDS)){const ok=ch>=+n;rows.push(`<button class="it" data-land="${th}1" ${ok?'':'disabled'} style="width:100%">${ok?'🌀':'🔒'} ${t(th+'1')}${ok?'':' · '+t('chapN')+' '+n}</button>`)}
  rows.push(`<button class="it" data-land="beach" style="width:100%">🎣 ${t('beach')}</button>`,`<button class="it" data-land="falls" style="width:100%">🎣 ${t('falls')}</button>`);
  const d=document.createElement('div');d.innerHTML=`<h3>🌀 ${t('landsT')}</h3><div class="grid">${rows.join('')}</div>`;const grid=h.parentNode.querySelector('.grid');(grid||h).after(d);
  d.querySelectorAll('[data-land]').forEach(b=>b.onclick=()=>{if(b.disabled)return;closeModal();goMap(b.dataset.land,'up')});return r}}

// ---- goal line after the cave guardian: point to the next land (the old text said "other caves soon") ----
{const _ug=updateGoal;updateGoal=function(){const r=_ug.apply(this,arguments);try{if(!S||!M||!S.boss)return r;const ch=chap(),el=$('goal');if(!el)return r;let g=null;
  if(M.land){const f=floorStats();if(isKid())g=f.aw<f.n?t('goalKid')+' '+f.aw+'/'+f.n:(M.floor===2?(M.boss&&!M.boss.happy?t('goalHelp')+' '+t('n_'+M.bossName):t('floorDone')):t('goalDown'));else g=M.floor===2&&M.boss&&!M.boss.happy?t('goalHelp')+' '+t('n_'+M.bossName):(f.mon?t('goalAdult')+' · '+t('goalDown'):t('goalDown'))}
  else if(M.kind!=='cave'||M.id==='cave3'){g=ch>=7?t('goalEnd'):t('goalLand')+' '+t(LANDS[Math.min(6,Math.max(3,ch))][0]+'1')}
  if(g)el.textContent=(g.trim().startsWith('🎯')?'':'🎯 ')+g}catch(e){}return r}}
// adults also level life skills (fishing, digging…) — show them in the detailed stats
{const _os2=openStats;openStats=function(){const r=_os2.apply(this,arguments);try{if(S&&!isKid()&&$('stDetail')&&!$('stLife')){fixLife();const d=document.createElement('div');d.id='stLife';d.className='pn';d.innerHTML=`<b>🌱 ${t('lifeSk')}</b> `+LIFE.map(([k,,,ic])=>`${ic} ${S.life[k].lv}`).join(' · ');$('stDetail').after(d)}}catch(e){}return r}}

// ================= fish: freshwater / saltwater, where to catch, and what fish are for =================
// 0-11 pond/lake · 12-17 sea (beach) · 18-23 waterfall. Uses: cooking (some dishes need a kind) · selling at Grandma Nuan · collection (fish book) · the princess's requests
const fishType=i=>i>=FISH_BASE&&i<FISH_BASE+6?'salt':'fresh';
const fishPlace=i=>i<FISH_BASE?'lake':i<FISH_BASE+6?'beach':'falls';
const isFishK=k=>k==='fish'||k==='sfish'||k==='ffish';
function fishCount(k){const b=S.fishBag||[];return k==='fish'?b.length:b.filter(i=>fishType(i)===(k==='sfish'?'salt':'fresh')).length}
function fishTake(k,n){S.fishBag=S.fishBag||[];for(let c=0;c<n;c++){const j=k==='fish'?0:S.fishBag.findIndex(i=>fishType(i)===(k==='sfish'?'salt':'fresh'));if(j>=0)S.fishBag.splice(j,1)}}
Object.assign(RECIPES,{tomyum:{need:{sfish:1,tom:1},buff:{atkP:15}},congee:{need:{ffish:2},buff:{hpP:18}}});
function fishHourText(i){const h=FISH[i][3];if(!h)return t('fhAny');if(h==='light')return t('fhLight');return `${h[0]}:00–${h[1]}:00`}
const fishPrice=i=>Math.max(1,Math.round(FISH[i][4]*.8));
// fish book: kind + place + time for fish you have caught, and the uses at the top
{const _fb=openFishBook;openFishBook=function(){const r=_fb.apply(this,arguments);try{const got=S.fish||{};const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('fbUse')){const u=document.createElement('p');u.id='fbUse';u.className='note';u.innerHTML=`🍳 ${t('fuCook')} · 🪙 ${t('fuSell')} · 👑 ${t('fuReq')} · 📖 ${t('fuBook')}`;h.after(u)}
  document.querySelectorAll('[data-f]').forEach(sp=>{const i=+sp.dataset.f,box=sp.parentNode.querySelector('.note');if(!box)return;const kind=fishType(i)==='salt'?'🌊 '+t('salt'):'🏞️ '+t('fresh');box.innerHTML=(got[i]?box.innerHTML+'<br>':'')+`${kind} · ${t(fishPlace(i))}`+(got[i]?` · 🕒 ${fishHourText(i)} · ${fishPrice(i)}🪙`:'')})}catch(e){}return r}}
// kitchen: count freshwater/saltwater separately
{const _ok=openKitchen;openKitchen=function(){const r=_ok.apply(this,arguments);try{const n=document.querySelector('#modal .note,.modal .note');if(n)n.innerHTML=n.innerHTML.replace(/🐟 \d+/,`🏞️ ${fishCount('ffish')} · 🌊 ${fishCount('sfish')}`);
  document.querySelectorAll('[data-ck]').forEach(b=>{const r2=RECIPES[b.dataset.ck],h=HOME.get();const ok=Object.entries(r2.need).every(([k,n])=>isFishK(k)?fishCount(k)>=n:(h.pantry[k]||0)>=n);b.disabled=!ok;const note=b.querySelector('.note');if(note)note.textContent=t('need')+' '+Object.entries(r2.need).map(([k,n])=>(k==='fish'?t('anyFish'):k==='sfish'?t('seaFish'):k==='ffish'?t('freshFish'):t('cr_'+k))+' ×'+n).join(' + ')})}catch(e){}return r}}
// selling fish at Grandma Nuan's shop (a real use for the price every fish already had)
function openFishSell(){const b=S.fishBag||[],cnt={};b.forEach(i=>cnt[i]=(cnt[i]||0)+1);const rows=Object.entries(cnt).map(([i,n])=>`<div class="it" style="display:flex;gap:6px;align-items:center;width:100%"><span style="flex:1">${fishType(+i)==='salt'?'🌊':'🏞️'} ${t('f'+i)} ×${n} · ${fishPrice(+i)}🪙</span><button data-sell="${i}">${t('sell1')}</button><button data-sellall="${i}">${t('sellAll')}</button></div>`).join('');
  modal(`<h2>🐟 ${t('sellFish')}</h2><p class="note">${t('sellTip')}</p>${rows||`<p class="note">${t('noFish')}</p>`}`);
  const sell=(i,all)=>{let n=0;S.fishBag=S.fishBag.filter(x=>{if(x===+i&&(all||n<1)){n++;return false}return true});const got=n*fishPrice(+i);S.coins+=got;sfx('coin');say('🪙 +'+got);save();hud();openFishSell()};
  document.querySelectorAll('[data-sell]').forEach(x=>x.onclick=()=>sell(x.dataset.sell,false));document.querySelectorAll('[data-sellall]').forEach(x=>x.onclick=()=>sell(x.dataset.sellall,true))}
{const _sh=openShop;openShop=function(){const r=_sh.apply(this,arguments);try{const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('fsBtn')){const b=document.createElement('button');b.id='fsBtn';b.textContent='🐟 '+t('sellFish')+' ('+(S.fishBag||[]).length+')';b.style.marginLeft='8px';b.onclick=openFishSell;h.after(b)}}catch(e){}return r}}

// ================= kids can finish the story too: 3 "guardian crystals" in every boss room =================
// The boss only fights grown-ups. A kid (alone or with the family) wakes the 3 crystals around the guardian with questions; when all 3 are awake the guardian calms down.
{const _bc=buildCave;buildCave=function(id){const m=_bc.apply(this,arguments);try{const C=CAVE_CFG[id];if(C&&C.boss&&m.bossRoom){const R=m.bossRoom;const spots=[[R.x+1,R.y+1],[R.x+R.w-2,R.y+1],[R.x+Math.floor(R.w/2),R.y+R.h-1]];let k=0;
    for(const [x,y] of spots){const kk=key(x,y);if(!m.FLOOR.has(kk)||m.SOLID.has(kk))continue;if(m.crystals.some(c=>Math.hypot(c.tx-x,c.ty-y)<2))continue;m.crystals.push({id:id+'-k'+(k++),tx:x,ty:y,x:x*T+16,y:y*T+22,awake:false,kidOnly:1})}}}catch(e){}return m}}
MAPS.cave3=()=>buildCave('cave3');for(const [ch,[th]] of Object.entries(LANDS)){const b=th+'2';MAPS[b]=()=>buildCave(b)}
{const _oq=openQuiz;openQuiz=function(c){if(c&&c.kidOnly&&!isKid()){say('💎 '+t('kidCrystal'));return}return _oq.apply(this,arguments)}}
function kidCrystals(){return (M&&M.crystals||[]).filter(c=>c.kidOnly)}
{const _up4=update;update=function(dt){const r=_up4.apply(this,arguments);try{if(M&&M.boss&&!M.boss.happy&&M.bossRoom){const kc=kidCrystals();if(kc.length&&kc.every(c=>c.awake)){const b=M.boss;if(Net&&Net.coop&&Net.coop()&&!Net.isHost()){try{Net.hit(b.idx,b.hp+9999,'sw')}catch(e){}}b.happy=1;b.gone=1.6;b.hitByMe=1;sfx('kill');say('✨ '+t('bossCalmed'));LIGHT=1;
    for(let i=0;i<50;i++)FX.push({k:'star',x:b.x+(rnd()-.5)*70,y:b.y-40+(rnd()-.5)*50,vx:(rnd()-.5)*90,vy:-40-rnd()*70,t:0,life:1.4});
    if(M.id==='cave3'&&!S.boss){S.boss=true;S.pts=(S.pts||0)+10;save();bossWin()}}}}catch(e){}return r}}
// goal line for kids on a boss floor
{const _ug2=updateGoal;updateGoal=function(){const r=_ug2.apply(this,arguments);try{if(S&&isKid()&&M&&M.boss&&!M.boss.happy){const kc=kidCrystals();if(kc.length){const aw=kc.filter(c=>c.awake).length;const el=$('goal');if(el&&inRoom(P.x,P.y,M.bossRoom))el.textContent='🎯 '+t('goalKidBoss')+' '+aw+'/'+kc.length}}}catch(e){}return r}}
{const _gt=guideTarget;guideTarget=function(){const r=_gt.apply(this,arguments);try{if(S&&isKid()&&M&&M.boss&&!M.boss.happy){const c=kidCrystals().filter(c=>!c.awake).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y))[0];const others=(M.crystals||[]).filter(c=>!c.kidOnly&&!c.awake);if(c&&!others.length)return{x:c.x,y:c.y}}}catch(e){}return r}}

// ================= combat feel: hit sparks, weapon arcs, crits with hit-stop, skill bursts, popping damage numbers =================
// Everything is drawn with code (no new image files). Kids get soft sparkle/dust versions; eco mode halves the particles.
let HITSTOP=0;const FXCAP=320;
const fxN=n=>Math.max(1,Math.round(n*(S&&S.eco?.5:1)));
function fx(o){if(FX.length>=FXCAP)return;FX.push(Object.assign({t:0,life:.4},o))}
function burst(x,y,n,col,sp,life,k){for(let i=0;i<fxN(n);i++){const a=Math.random()*6.283,v=sp*(.4+Math.random()*.8);fx({k:k||'spark2',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-20,life:life*(.7+Math.random()*.5),c:col,s:1+Math.random()*1.6})}}
const WCOL={sw:'255,236,170',dag:'235,245,255',bow:'170,255,190',staff:'210,170,255'};
function hitFx(mo,dmg,type,crit){if(!mo)return;const x=mo.x,y=mo.y-(mo.h||20)*.6,a=Math.atan2(mo.y-P.y,mo.x-P.x);
  if(isKid()){burst(x,y,8,'255,220,250',60,.5,'star2');fx({k:'puff',x,y,life:.45});return}
  const c=WCOL[type]||WCOL.sw;
  if(type==='sw'||!type)fx({k:'arc2',x,y,a,life:.22,c,r:crit?26:20});
  else if(type==='dag'){fx({k:'xcut',x,y,a,life:.18,c});}
  else if(type==='staff')fx({k:'ring2',x,y,life:.3,c,r:crit?30:22});
  else if(type==='bow')fx({k:'star2',x,y,life:.25,c,s:3});
  burst(x,y,crit?16:7,c,crit?150:90,.35);
  mo.kb={x:Math.cos(a),y:Math.sin(a),t:.12};
  if(crit){fx({k:'star2',x,y,life:.35,c:'255,190,90',s:6});fx({k:'ring2',x,y,life:.35,c:'255,200,120',r:36});HITSTOP=Math.max(HITSTOP,.06);SHAKE=Math.max(SHAKE||0,.08)}}
// hook: every successful hit (MISS returns before) gets the new effects; crit is known from the text the game just pushed
{const _mh3=monHit;monHit=function(mo,dmg,src,type){const n0=TXT.length,was=!!(mo&&mo.happy);const r=_mh3.apply(this,arguments);try{if(mo&&!was&&src!=='net'){const added=TXT.slice(n0);const miss=added.some(x=>x.s==='MISS');if(!miss){const crit=TXT.slice(Math.max(0,n0-3)).some(x=>x.s===t('crit')&&x.t<.05);hitFx(mo,dmg,type||(weapon()&&weapon().type),crit)}
  if(mo.happy){burst(mo.x,mo.y-16,isKid()?14:10,isKid()?'255,240,200':'255,255,255',110,.6,'star2');fx({k:'ring2',x:mo.x,y:mo.y-10,life:.4,c:'255,255,230',r:28})}}}catch(e){}return r}}
// skills: big readable bursts
const SKFX={bash:p=>{fx({k:'star2',x:p.x,y:p.y,life:.4,c:'255,210,120',s:9});fx({k:'ring2',x:p.x,y:p.y,life:.4,c:'255,200,120',r:48});burst(p.x,p.y,18,'255,220,150',170,.45);SHAKE=Math.max(SHAKE||0,.15)},
  guard:p=>fx({k:'shield2',x:P.x,y:P.y-24,life:1.2,c:'150,210,255',follow:1}),
  provoke:p=>{for(let i=0;i<3;i++)fx({k:'ring2',x:P.x,y:P.y-10,life:.5+i*.15,c:'255,110,110',r:30+i*22})},
  shower:p=>{for(let i=0;i<fxN(26);i++)fx({k:'rain2',x:p.x+(Math.random()-.5)*150,y:p.y-150-Math.random()*60,vx:-40,vy:520,life:.34+Math.random()*.2,c:'190,255,200'})},
  evade:p=>{for(let i=0;i<5;i++)fx({k:'after',x:P.x,y:P.y,life:.25+i*.07,ox:(Math.random()-.5)*16})},
  hawk:p=>burst(P.x,P.y-30,16,'230,230,200',120,.6,'feather'),
  fire:p=>{fx({k:'ring2',x:p.x,y:p.y,life:.45,c:'255,140,60',r:54});burst(p.x,p.y,24,'255,150,60',150,.6,'ember');fx({k:'star2',x:p.x,y:p.y,life:.3,c:'255,220,140',s:8});SHAKE=Math.max(SHAKE||0,.12)},
  ice:p=>{for(let i=0;i<fxN(12);i++){const a=i/12*6.283;fx({k:'shard',x:p.x,y:p.y,vx:Math.cos(a)*140,vy:Math.sin(a)*90,life:.5,a,c:'170,235,255'})}fx({k:'ring2',x:p.x,y:p.y,life:.5,c:'180,240,255',r:46})},
  bolt:p=>{const ts=MONS.filter(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<220).slice(0,4);let a={x:P.x,y:P.y-30};for(const o of ts){fx({k:'bolt2',x:a.x,y:a.y,x2:o.x,y2:o.y-16,life:.28,seed:Math.random()*99});a={x:o.x,y:o.y-16}}if(!ts.length)fx({k:'bolt2',x:P.x,y:P.y-160,x2:P.x,y2:P.y-20,life:.25,seed:3});SHAKE=Math.max(SHAKE||0,.1)},
  steal:p=>burst(p.x,p.y,12,'255,220,90',100,.6,'star2'),dash:p=>{for(let i=0;i<8;i++)fx({k:'speed',x:P.x,y:P.y-20+(Math.random()-.5)*30,life:.3,a:Math.atan2(lastMove.y,lastMove.x)})}};
function nearestTarget(){return MONS.filter(o=>!o.happy).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y))[0]}
{const _uj=useJob;useJob=function(k){const before=JCD[k]||0;const r=_uj.apply(this,arguments);try{if((JCD[k]||0)!==before&&SKFX[k]){const mo=P.target&&!P.target.happy?P.target:nearestTarget();SKFX[k](mo&&Math.hypot(mo.x-P.x,mo.y-P.y)<260?{x:mo.x,y:mo.y-14}:{x:P.x,y:P.y-14})}}catch(e){}return r}}
{const _us=useSkill;useSkill=function(){const before=P.skCd||0;const r=_us.apply(this,arguments);try{if((P.skCd||0)>before&&!isKid()){const c=WCOL[weapon().type]||WCOL.sw;for(let i=0;i<3;i++)fx({k:'ring2',x:P.x,y:P.y-12,life:.35+i*.12,c,r:40+i*30});burst(P.x,P.y-14,22,c,190,.5);SHAKE=Math.max(SHAKE||0,.12)}}catch(e){}return r}}
// hit-stop + arrow trails + knockback decay
{const _up5=update;update=function(dt){if(HITSTOP>0){HITSTOP-=dt;dt*=.12}try{for(const s of SHOTS)if(s.from==='p'&&Math.random()<.7)fx({k:'trail',x:s.x,y:s.y,life:.22,c:WCOL[s.k]||'255,255,255'});for(const m of MONS)if(m.kb&&m.kb.t>0)m.kb.t-=dt}catch(e){}return _up5.call(this,dt)}}
// monsters squash when hit and get pushed back a little
{const _dm2=drawMon;drawMon=function(m,tm){const k=m.flash>0?Math.min(1,m.flash/.15):0,kb=m.kb&&m.kb.t>0?m.kb.t/.12:0;if(!k&&!kb)return _dm2.apply(this,arguments);
  const mx=m.x-camX,my=m.y-camY;ctx.save();ctx.translate(mx+(kb?m.kb.x*5*kb:0),my+(kb?m.kb.y*3*kb:0));ctx.scale(1+.14*k,1-.12*k);ctx.translate(-mx,-my);const r=_dm2.apply(this,arguments);ctx.restore();return r}}
// drawn in two batches (normal, then additive light) so there is no save/restore per particle — measured in t65
const ADD={arc2:1,xcut:1,ring2:1,star2:1,shield2:1,bolt2:1,rays:1};
function drawVFX2(tm){const list=FX;if(!list.length)return;
  for(const f of list){if(ADD[f.k])continue;const p=f.t/f.life;if(p>=1)continue;const x=f.x-camX,y=f.y-camY,al=1-p;
    switch(f.k){
    case'spark2':case'ember':case'feather':{ctx.fillStyle=`rgba(${f.c},${al})`;const s2=f.s||1.5;ctx.fillRect(x|0,y|0,Math.ceil(s2),Math.ceil(s2*(f.k==='feather'?2:1)));break}
    case'trail':ctx.fillStyle=`rgba(${f.c},${.7*al})`;ctx.fillRect((x|0)-1,(y|0)-1,2,2);break;
    case'puff':ctx.fillStyle=`rgba(200,185,230,${.45*al})`;for(let i=0;i<5;i++){const a=i*1.2566;ctx.fillRect((x+Math.cos(a)*(6+p*10)-3)|0,(y+Math.sin(a)*(4+p*6)-3)|0,6+p*4|0,5+p*3|0)}break;
    case'rain2':ctx.strokeStyle=`rgba(${f.c},${al})`;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+4,y-14);ctx.stroke();break;
    case'shard':{const c=Math.cos(f.a),s2=Math.sin(f.a);ctx.fillStyle=`rgba(${f.c},${al})`;ctx.beginPath();ctx.moveTo(x+c*6,y+s2*6);ctx.lineTo(x-c*3+s2*2.5,y-s2*3-c*2.5);ctx.lineTo(x-c*3-s2*2.5,y-s2*3+c*2.5);ctx.fill();break}
    case'speed':ctx.strokeStyle=`rgba(255,255,255,${.6*al})`;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-Math.cos(f.a)*(10+p*20),y-Math.sin(f.a)*(10+p*20));ctx.lineTo(x-Math.cos(f.a)*(26+p*30),y-Math.sin(f.a)*(26+p*30));ctx.stroke();break;
    case'confetti':ctx.fillStyle=f.c;ctx.globalAlpha=al;ctx.fillRect((x|0)-2,(y|0)-1,(Math.sin(f.t*8+f.s)>0?4:2),2);ctx.globalAlpha=1;break;
    case'after':{const im=P.moving?PS.walk:PS.stand;if(im){const F=PS.F||64;ctx.globalAlpha=.35*al;ctx.drawImage(im,0,(P.row*F)%(im.height||F),F,F,Math.round(P.x-F/2-camX+f.ox),Math.round(P.y-(F-2)-camY),F,F);ctx.globalAlpha=1}break}}}
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.lineCap='round';
  for(const f of list){if(!ADD[f.k])continue;const p=f.t/f.life;if(p>=1)continue;let x=f.x-camX,y=f.y-camY;if(f.follow){x=P.x-camX;y=P.y-24-camY}const al=1-p;
    switch(f.k){
    case'arc2':for(let j=0;j<3;j++){ctx.strokeStyle=`rgba(${f.c},${al*(1-j*.3)})`;ctx.lineWidth=5-j*1.5;ctx.beginPath();ctx.arc(x-Math.cos(f.a)*6,y-Math.sin(f.a)*6,f.r+j*3+p*6,f.a-1.3+p*.6,f.a+1.1+p*.6);ctx.stroke()}break;
    case'xcut':{ctx.strokeStyle=`rgba(${f.c},${al})`;ctx.lineWidth=2.5;const L=14+p*6;ctx.beginPath();ctx.moveTo(x-L,y+L*.8);ctx.lineTo(x+L,y-L*.8);ctx.moveTo(x-L,y-L*.8);ctx.lineTo(x+L,y+L*.8);ctx.stroke();break}
    case'ring2':ctx.strokeStyle=`rgba(${f.c},${.9*al})`;ctx.lineWidth=3*al+1;ctx.beginPath();ctx.ellipse(x,y,f.r*(.35+p*.65),f.r*(.35+p*.65)*.55,0,0,6.283);ctx.stroke();break;
    case'star2':{const s2=(f.s||2)*(1+p*.6);ctx.fillStyle=`rgba(${f.c},${al})`;ctx.beginPath();for(let i=0;i<8;i++){const a=i*.7854,rr=i%2?s2*.35:s2*2;ctx.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}ctx.fill();break}
    case'shield2':ctx.strokeStyle=`rgba(${f.c},${.7*al})`;ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,20+Math.sin(tm*8)*1.5,28,0,0,6.283);ctx.stroke();ctx.fillStyle=`rgba(${f.c},${.12*al})`;ctx.fill();break;
    case'bolt2':{let sd=f.seed;const r2=()=>(sd=(sd*9301+49297)%233280)/233280;const X2=f.x2-camX,Y2=f.y2-camY;for(const [w,c] of [[5,`rgba(140,180,255,${.5*al})`],[2,`rgba(255,255,255,${al})`]]){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x,y);sd=f.seed;for(let i=1;i<=7;i++){const q=i/7;ctx.lineTo(x+(X2-x)*q+(i<7?(r2()-.5)*16:0),y+(Y2-y)*q+(i<7?(r2()-.5)*10:0))}ctx.stroke()}break}
    case'rays':for(let i=0;i<10;i++){const a=i*.6283+tm*.6;ctx.fillStyle=`rgba(255,240,180,${.14*Math.sin(p*3.14)})`;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.cos(a-.08)*160,y+Math.sin(a-.08)*160);ctx.lineTo(x+Math.cos(a+.08)*160,y+Math.sin(a+.08)*160);ctx.fill()}break}}
  ctx.restore()}
// popping damage numbers: pop in, settle, float with ease-out, dark outline; crits big and golden
function drawNumbers(){for(const x of TXT){if(x.dx===undefined){x.dx=(Math.random()-.5)*14;x.dy=-10*TXT.filter(o=>o!==x&&o.dy!==undefined&&o.t<.35&&Math.abs(o.x-x.x)<24&&Math.abs(o.y-x.y)<24).length}const p=Math.min(1,x.t/1.1),crit=x.s===t('crit'),big=x.big||crit,miss=x.s==='MISS';
  const pop=x.t<.1?.55+x.t/.1*.75:Math.max(1,1.3-(x.t-.1)*2.2),rise=24*(1-Math.pow(1-p,2)),size=Math.round((big?15:(/^[+-]?\d/.test(x.s)?11:9))*pop*(isKid()?.85:1));
  ctx.save();ctx.font=`${miss?'italic ':''}bold ${size}px system-ui,sans-serif`;ctx.textAlign='center';ctx.globalAlpha=p>.7?1-(p-.7)/.3:1;const X=Math.round(x.x-camX+x.dx),Y=Math.round(x.y-camY-rise+(x.dy||0));
  ctx.lineWidth=3;ctx.strokeStyle='rgba(20,12,34,.95)';ctx.strokeText(x.s,X,Y);
  if(big&&!miss){const g=ctx.createLinearGradient(0,Y-size,0,Y);g.addColorStop(0,'#fff6c8');g.addColorStop(1,x.c||'#ffb13b');ctx.fillStyle=g}else ctx.fillStyle=x.c;ctx.fillText(x.s,X,Y);ctx.restore()}}
// chapter complete / guardian calmed: rays + confetti around the player
function celebrate(){fx({k:'rays',x:P.x,y:P.y-30,life:2.4});const cols=['#ffd23f','#ff7aa8','#7fd8ff','#a8f07a','#c9a0ff'];for(let i=0;i<fxN(70);i++)fx({k:'confetti',x:P.x+(Math.random()-.5)*60,y:P.y-60,vx:(Math.random()-.5)*220,vy:-120-Math.random()*160,life:1.6+Math.random()*.8,c:cols[i%5],s:Math.random()*6})}


function cardSub(m){try{if(m.id==='trial')return t('trSub');const C=CAVE_CFG[m.id]||{};if(C.land)return (LANG==='en'?'Chapter ':'บทที่ ')+C.land+' · '+t(C.theme+'N');if(/^cave[123]$/.test(m.id))return (LANG==='en'?'Chapter ':'บทที่ ')+'2 · '+t('caveN');if(/^dream/.test(m.id))return t('dreamN')}catch(e){}return t('town')}

// ================= PWA: install button, iOS instructions, update notice =================
let INSTALL_EVT=null;addEventListener('beforeinstallprompt',e=>{e.preventDefault();INSTALL_EVT=e});
const isStandalone=()=>matchMedia('(display-mode: standalone)').matches||matchMedia('(display-mode: fullscreen)').matches||navigator.standalone===true;
const isIOS=()=>/iphone|ipad|ipod/i.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
function installGame(){if(isStandalone()){say('✅ '+t('installed'));return}if(INSTALL_EVT){INSTALL_EVT.prompt();INSTALL_EVT.userChoice.then(c=>{if(c&&c.outcome==='accepted')say('🏮 '+t('installOk'));INSTALL_EVT=null});return}
  modal(`<h2>📲 ${t('installT')}</h2><div class="pn">${isIOS()?t('installIOS'):t('installOther')}</div>`)}
{const _st=openSettings;openSettings=function(){const r=_st.apply(this,arguments);try{const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('instBtn')&&!isStandalone()){const b=document.createElement('button');b.id='instBtn';b.textContent='📲 '+t('installT');b.style.marginLeft='8px';b.onclick=installGame;h.after(b)}}catch(e){}return r}}
if('serviceWorker' in navigator&&location.protocol.startsWith('http')){let reloaded=false;navigator.serviceWorker.addEventListener('controllerchange',()=>{if(reloaded)return;reloaded=true;try{say('✨ '+t('updated'))}catch(e){}});
  navigator.serviceWorker.getRegistration&&navigator.serviceWorker.getRegistration().then(reg=>{if(reg)setInterval(()=>reg.update().catch(()=>{}),30*60000)}).catch(()=>{})}

// ================= start screen: key art + logo + "tap to start" (falls back to the old flow if the pictures are missing) =================
const assetURL=f=>(window.EMBED_ASSETS&&window.EMBED_ASSETS[f])||f;
function showTitle(next){try{if(typeof plumAll==='function')plumAll();if(navigator.webdriver&&!/title=1/.test(location.search))return next(); // automated test runs skip the start screen
  const el=document.createElement('div');el.id='title';
  el.style.cssText='position:fixed;inset:0;z-index:60;display:flex;flex-direction:column;align-items:center;justify-content:space-between;background:#140d24 center/cover no-repeat;cursor:pointer;opacity:0;transition:opacity .6s';
  const art=new Image(),logo=new Image();let ok=0,fail=0,shown=false;
  const go=()=>{if(shown)return;shown=true;el.style.backgroundImage=`linear-gradient(to bottom,rgba(20,13,36,.15),rgba(20,13,36,0) 40%,rgba(20,13,36,.55)),url("${art.src}")`;
    el.style.backgroundPosition='40% 35%';
    // the art has the girls on the left and the academy on the right: logo sits in the calm sky, button right of the girls
    el.innerHTML=`<img src="${logo.src}" alt="Lantern Academy" style="position:absolute;top:3vh;left:59%;transform:translateX(-50%);width:min(33vw,440px);max-height:40vh;object-fit:contain;filter:drop-shadow(0 6px 14px rgba(0,0,0,.6));animation:laFloat 3.2s ease-in-out infinite">
      <div style="position:absolute;bottom:5vh;left:66%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:10px"><button id="tGo" style="font-size:clamp(16px,2.6vw,24px);padding:.6em 1.8em;border-radius:999px;border:2px solid #ffd98a;background:linear-gradient(#ffcf6b,#e89a2c);color:#3a1d05;font-weight:800;box-shadow:0 0 24px rgba(255,200,110,.7);animation:laPulse 1.6s ease-in-out infinite">▶ ${t('tapStart')}</button>
      <span style="color:#ffe7b0;font-size:12px;text-shadow:0 1px 3px #000">${t('titleSub')}</span></div>`;
    document.body.append(el);requestAnimationFrame(()=>el.style.opacity=1);
    const start=e=>{e&&e.stopPropagation();el.style.opacity=0;setTimeout(()=>el.remove(),600);try{sfx('lvl')}catch(e2){}next()};el.onclick=start};
  const done=()=>{if(ok===2)go();else if(ok+fail===2){next()}};
  art.onload=logo.onload=()=>{ok++;done()};art.onerror=logo.onerror=()=>{fail++;done()};art.src=assetURL('title-art.jpg');logo.src=assetURL('logo.png');
  setTimeout(()=>{if(!shown&&ok+fail<2){fail=2;next()}},6000)}catch(e){next()}}
(()=>{const st=document.createElement('style');st.textContent='@keyframes laFloat{0%,100%{transform:translate(-50%,0)}50%{transform:translate(-50%,-8px)}}@keyframes laPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}';document.head.append(st)})();

// ================= Family Quest: "Lantern Trial" (MapleStory party quest + Goemon 4 boss mini-game ideas) =================
// 3 phases in the Academy hall. Every phase can be finished alone (kid or grown-up); with family it is faster and pays more.
// 1 questions wake 3 trial crystals · 2 two light plates must glow at the same time (each glows 12 s) · 3 guard the Great Lantern for 40 s
CAVE_CFG.trial={gw:2,gh:2,branch:0,seed:9001,crystals:0,digs:0,mons:[],up:'plaza',upExit:'x',mul:1,theme:'sky',trial:1};MAPS.trial=()=>buildCave('trial');
let TRIAL=null;
{const _cp=Net.coop.bind(Net);Net.coop=function(){return M&&M.id==='trial'?false:_cp()}} // private instance for now
function freeTilesFrom(tx,ty,maxD){const seen=new Map([[tx+','+ty,0]]),q=[[tx,ty]];while(q.length){const [x,y]=q.shift(),d=seen.get(x+','+y);if(d>=maxD)continue;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const k=(x+dx)+','+(y+dy);if(seen.has(k)||(M.kind==='cave'&&M.FLOOR?!M.FLOOR.has(k):(x+dx<1||y+dy<1||x+dx>=M.w-1||y+dy>=M.h-1||(M.WATER&&M.WATER.has(k))))||M.SOLID.has(k))continue;seen.set(k,d+1);q.push([x+dx,y+dy])}}return [...seen].map(([k,d])=>{const [x,y]=k.split(',').map(Number);return{x,y,d}})}
function trialSetup(){const sx=Math.floor(P.x/T),sy=Math.floor(P.y/T),tiles=freeTilesFrom(sx,sy,9);const px=t=>({x:t.x*T+16,y:t.y*T+20});
  const ring=(d0,d1)=>tiles.filter(t=>t.d>=d0&&t.d<=d1);const far=(list,from,n)=>{const out=[];for(const t of list.sort(()=>Math.random()-.5)){if(out.every(o=>Math.hypot(o.x-t.x,o.y-t.y)>=3)&&(!from||from.every(o=>Math.hypot(o.x-t.x,o.y-t.y)>=2)))out.push(t);if(out.length>=n)break}return out};
  const lt=(ring(3,4)[0])||tiles[1],lan=px(lt);const cr=far(ring(2,4).filter(t=>!(t.x===lt.x&&t.y===lt.y)),[lt],3);
  const pl=far(ring(5,7),[lt,...cr],2);let spawns=ring(7,9);if(spawns.length<3)spawns=ring(5,9);
  M.crystals=cr.map((t,i)=>({id:'trial-c'+i,tx:t.x,ty:t.y,x:t.x*T+16,y:t.y*T+22,awake:false,trial:1}));
  TRIAL={phase:1,t:0,lantern:{x:lan.x,y:lan.y,hp:100},plates:pl.map(t=>({...px(t),glow:0})),spawns:spawns.map(px),spawnT:0,left:40,shineCd:0,start:performance.now(),helpers:0,fails:0};
  MONS=[];say('🏮 '+t('tr1'));sfx('warp')}
function trialMonster(){const s=TRIAL.spawns[Math.floor(Math.random()*TRIAL.spawns.length)];if(!s)return;const kinds=['slime','bat','mushbug'];const mul=Math.max(1,(S.lv||1)/8);const m=mkMon(kinds[Math.floor(Math.random()*3)],s.x,s.y,mul);m.spd=0;m.trial=1;m.idx=MONS.length;MONS.push(m)}
function trialWin(){const secs=Math.round((performance.now()-TRIAL.start)/1000),day=new Date().toDateString(),first=S.trialDay!==day,fam=TRIAL.helpers>0;
  let coins=isKid()?60:40+S.lv*4;if(first)coins*=2;if(fam)coins=Math.round(coins*1.5);S.coins+=coins;S.gems=(S.gems||0)+1;S.trialDay=day;S.trialN=(S.trialN||0)+1;const best=!S.trialBest||secs<S.trialBest;if(best)S.trialBest=secs;lifeXp('know',20);if(fam)S.good=(S.good||0)+2;bump('trial');
  MONS.forEach(m=>{if(!m.happy){m.happy=1;m.gone=1.2}});TRIAL.phase=4;celebrate();save();hud();sfx('lvl');
  showCard('🏮 '+t('trWin'),`⏱ ${secs}s${best?' · '+t('trBest'):''} · 🪙 +${coins}${first?' · '+t('trFirst'):''}${fam?' · 👨‍👩‍👧 ×1.5':''}`)}
{const _up6=update;update=function(dt){const r=_up6.apply(this,arguments);try{if(!TRIAL||!M||M.id!=='trial'||PAUSE)return r;const T2=TRIAL;T2.t+=dt;if(T2.shineCd>0)T2.shineCd-=dt;
  if(Net&&Net.online&&Net.inMap&&Net.inMap().length)T2.helpers=Math.max(T2.helpers,Net.inMap().length);
  if(T2.phase===1&&M.crystals.length&&M.crystals.every(c=>c.awake)){T2.phase=2;sfx('warp');say('✨ '+t('tr2'))}
  else if(T2.phase===2){for(const p of T2.plates){if(p.glow>0)p.glow-=dt;if(Math.hypot(P.x-p.x,P.y-p.y)<20||Object.values(Net.others||{}).some(o=>o.p&&Math.hypot(o.p.x-p.x,o.p.y-p.y)<20)){if(p.glow<=0)sfx('pick');p.glow=12}}
    if(T2.plates.length&&T2.plates.every(p=>p.glow>0)){T2.phase=3;T2.left=40;sfx('warp');say('🛡️ '+t('tr3'))}}
  else if(T2.phase===3){T2.left-=dt;T2.spawnT-=dt;const alive=MONS.filter(m=>m.trial&&!m.happy);if(T2.spawnT<=0&&alive.length<(isKid()?6:8)){trialMonster();T2.spawnT=isKid()?3.2:2.2}
    const L=T2.lantern;for(const m of alive){const dx=L.x-m.x,dy=L.y-m.y,d=Math.hypot(dx,dy);if(d>22){const v=(m.fly?46:36)*(isKid()?.8:1)*dt;m.x+=dx/d*v;m.y+=dy/d*v}else L.hp-=(isKid()?4:6)*dt}
    if(L.hp<=0){T2.fails++;MONS.forEach(m=>{if(m.trial&&!m.happy){m.happy=1;m.gone=.8}});L.hp=100;T2.left=40;T2.spawnT=3;say('💡 '+t('trFail'));sfx('wrong')}
    else if(T2.left<=0)trialWin()}}catch(e){}return r}}
// shine: the attack/space button next to the Great Lantern (kids calm the monsters, grown-ups push them back)
function trialShine(){const T2=TRIAL,L=T2.lantern;if(T2.shineCd>0){say(t('skWait')+' '+Math.ceil(T2.shineCd)+'s');return true}T2.shineCd=isKid()?4:5;sfx('lvl');
  for(let i=0;i<3;i++)fx({k:'ring2',x:L.x,y:L.y-16,life:.4+i*.12,c:'255,230,150',r:60+i*40});burst(L.x,L.y-20,20,'255,240,190',160,.6,'star2');
  for(const m of MONS){if(m.happy||!m.trial)continue;const dx=m.x-L.x,dy=m.y-L.y,d=Math.hypot(dx,dy)||1;if(d<(isKid()?150:130)){if(isKid()){m.happy=1;m.gone=1.2;burst(m.x,m.y-12,8,'255,220,250',60,.5,'star2')}else{m.x+=dx/d*50;m.y+=dy/d*50}}}return true}
{const _aa=autoAct;autoAct=function(){if(TRIAL&&M&&M.id==='trial'&&TRIAL.phase===3&&Math.hypot(P.x-TRIAL.lantern.x,P.y-TRIAL.lantern.y)<80&&(isKid()||!MONS.some(o=>!o.happy&&Math.hypot(o.x-P.x,o.y-P.y)<60))){trialShine();return}return _aa.apply(this,arguments)}}
{const _gm4=goMap;goMap=function(id){const prev=M&&M.id;const r=_gm4.apply(this,arguments);try{if(M&&M.id==='trial'){if(prev==='trial'&&TRIAL){MONS=MONS.filter(m=>m.trial);return r}TRIAL=null;setTimeout(()=>{if(M&&M.id==='trial')trialSetup()},400)}else TRIAL=null}catch(e){}return r}}
// drawing: plates on the ground, the Great Lantern, and a small status bar
{const _dw=drawWater2;drawWater2=function(tm){_dw.apply(this,arguments);if(!TRIAL||!M||M.id!=='trial')return;if(TRIAL.phase===2||TRIAL.phase===3)for(const p of TRIAL.plates){const x=p.x-camX,y=p.y-camY,on=p.glow>0;ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=on?'rgba(255,230,140,.95)':'rgba(170,200,255,.6)';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,15,8,0,0,6.283);ctx.stroke();ctx.beginPath();ctx.ellipse(x,y,9+Math.sin(tm*4)*1.5,4.5,0,0,6.283);ctx.stroke();if(on){ctx.fillStyle=`rgba(255,220,120,${.25+.1*Math.sin(tm*8)})`;ctx.fill()}ctx.restore()}}}
{const _dv=drawVFX2;drawVFX2=function(tm){_dv.apply(this,arguments);if(!TRIAL||!M||M.id!=='trial'||TRIAL.phase>=4&&!TRIAL.lantern)return;const L=TRIAL.lantern,x=L.x-camX,y=L.y-camY;
  ctx.save();ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(x,y-22,2,x,y-22,46);g.addColorStop(0,'rgba(255,220,120,.55)');g.addColorStop(1,'rgba(255,200,100,0)');ctx.fillStyle=g;ctx.fillRect(x-50,y-72,100,100);ctx.restore();
  ctx.fillStyle='#3a2410';ctx.fillRect(x-11,y-42,22,4);ctx.fillRect(x-12,y-6,24,5);ctx.fillStyle='#f0b848';ctx.fillRect(x-10,y-41,20,3);ctx.fillRect(x-11,y-5,22,3);ctx.fillStyle='#3a2410';ctx.fillRect(x-10,y-38,20,32);
  ctx.fillStyle=`rgb(255,${220+Math.round(20*Math.sin(tm*5))},140)`;ctx.fillRect(x-8,y-37,16,30);ctx.fillStyle='#7fe0ff';ctx.beginPath();ctx.moveTo(x,y-32);ctx.lineTo(x+5,y-22);ctx.lineTo(x,y-12);ctx.lineTo(x-5,y-22);ctx.fill();ctx.strokeStyle='#3a2410';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y-48,4,0,6.283);ctx.stroke();
  if(TRIAL.phase===3){ctx.fillStyle='#120b22';ctx.fillRect(x-17,y+2,34,5);ctx.fillStyle=L.hp>40?'#ffd23f':'#ff6b6b';ctx.fillRect(x-16,y+3,Math.round(32*L.hp/100),3)}
  const w=Math.min(240,VW-140),bx=Math.round(VW/2-w/2);const txt=TRIAL.phase===1?t('tr1s')+' '+M.crystals.filter(c=>c.awake).length+'/'+M.crystals.length:TRIAL.phase===2?t('tr2s')+' '+TRIAL.plates.filter(p=>p.glow>0).length+'/'+TRIAL.plates.length:TRIAL.phase===3?t('tr3s')+' '+Math.max(0,Math.ceil(TRIAL.left))+'s':t('trWin');
  label(VW/2,26,'🏮 '+t('trName')+' · '+txt,'#ffd98a');if(TRIAL.phase<4){ctx.fillStyle='#120b22';ctx.fillRect(bx-1,30,w+2,6);ctx.fillStyle='#ffd98a';ctx.fillRect(bx,31,Math.round(w*(TRIAL.phase-1+(TRIAL.phase===3?1-Math.max(0,TRIAL.left)/40:0))/3),4)}}}
// goal line + entry from the map menu (after the Crystal Cave is reached)
{const _ug3=updateGoal;updateGoal=function(){const r=_ug3.apply(this,arguments);try{if(TRIAL&&M&&M.id==='trial'){const el=$('goal');if(el)el.textContent='🎯 '+(TRIAL.phase===1?t('tr1'):TRIAL.phase===2?t('tr2'):TRIAL.phase===3?t('tr3'):t('trAgain'))}}catch(e){}return r}}
{const _ow2=openWarp;openWarp=function(){const r=_ow2.apply(this,arguments);try{const grid=[...document.querySelectorAll('[data-land]')].pop();if(grid&&!document.querySelector('[data-land="trial"]')){const ok=chap()>=2;const b=document.createElement('button');b.className='it';b.dataset.land='trial';b.style.width='100%';b.disabled=!ok;b.textContent=(ok?'🏮 ':'🔒 ')+t('trName')+(S.trialBest?' · ⏱ '+S.trialBest+'s':'');b.onclick=()=>{if(b.disabled)return;closeModal();goMap('trial','up')};grid.parentNode.prepend(b)}}catch(e){}return r}}

// ---- fixes found in the v0.39 review ----
// trial crystals are practice: they pay like a crystal but are not saved as cave progress (they raised the cave light and the wake count)
{const _wc=wakeCrystal;wakeCrystal=function(c){const r=_wc.apply(this,arguments);try{if(c&&c.trial&&S&&S.crystals&&S.crystals.trial){delete S.crystals.trial;if(typeof setLight==='function')setLight();save()}}catch(e){}return r}}
// the trial is a challenge: no auto there
{const _mc=mapCleared;mapCleared=function(){if(M&&M.id==='trial')return false;return _mc.apply(this,arguments)}}
if(S===undefined||S===null){} // (saves are repaired on load below)
function repairTrialLeak(){try{if(S&&S.crystals&&S.crystals.trial){delete S.crystals.trial;save()}}catch(e){}}
{const _sg=startGame;startGame=function(){const r=_sg.apply(this,arguments);repairTrialLeak();return r}}

// ================= land events (Goemon-style surprises): something to chase on land floors =================
// forest: fireflies drift · desert: a golden scarab runs away · underground lake: glowing fish hop out of the water · sky: cloud balloons float up
const LEV={forest:{n:10,k:'fly',ic:'✨',t:40},desert:{n:1,k:'scarab',ic:'🪲',t:35},ulake:{n:6,k:'fish',ic:'🐟',t:40},sky:{n:8,k:'balloon',ic:'🎈',t:40}};
let LEVT=null;
function levFree(x,y){return !blockedAt(M,x,y)&&(M.kind!=='cave'||!M.FLOOR||M.FLOOR.has(Math.floor(x/T)+','+Math.floor(y/T)))}
function levStart(){const th=M.theme,cfg=LEV[th];if(!cfg)return;const tiles=freeTilesFrom(Math.floor(P.x/T),Math.floor(P.y/T),16).filter(t=>t.d>=(cfg.k==='scarab'?9:5));if(tiles.length<cfg.n)return;
  const pick=()=>tiles[Math.floor(Math.random()*tiles.length)];const items=[];for(let i=0;i<cfg.n;i++){const tl=pick();items.push({x:tl.x*T+16,y:tl.y*T+16,vx:0,vy:0,ph:Math.random()*6,got:0,hop:0})}
  LEVT={th,cfg,items,left:cfg.t,got:0,done:0};say(cfg.ic+' '+t('lev_'+th));sfx('warp')}
function levEnd(win){const e=LEVT;e.done=1;const n=e.got;let coins=n*(isKid()?6:4)+(win?20:0);S.coins+=coins;
  if(e.th==='ulake'&&n){S.fishBag=S.fishBag||[];for(let i=0;i<Math.min(3,n);i++)S.fishBag.push([0,2,4,9][Math.floor(Math.random()*4)]);lifeXp('fish',6*n)}else lifeXp('dig',3*n);
  if(win){celebrate();bump('levWin')}say((win?'🎉 ':'⏱ ')+t(win?'levWin':'levEnd')+' · '+e.cfg.ic+' '+n+'/'+e.items.length+' · 🪙 +'+coins);sfx(win?'lvl':'coin');save();hud();setTimeout(()=>{if(LEVT===e)LEVT=null},2500)}
{const _up7=update;update=function(dt){const r=_up7.apply(this,arguments);try{const e=LEVT;if(!e||e.done||!M||M.theme!==e.th||PAUSE)return r;e.left-=dt;
  for(const it of e.items){if(it.got)continue;it.ph+=dt;let nx=it.x,ny=it.y;const dx=it.x-P.x,dy=it.y-P.y,d=Math.hypot(dx,dy);
    if(e.cfg.k==='fly'){nx+=Math.cos(it.ph*1.3)*38*dt;ny+=Math.sin(it.ph*1.7)*30*dt;if(d<60){nx+=dx/(d||1)*30*dt;ny+=dy/(d||1)*30*dt}}
    else if(e.cfg.k==='scarab'){it.run=(it.run||0)+dt;const tired=(it.run%2.4)>1.6;if(d<170&&!tired){const sp=(isKid()?96:118)*dt;nx+=dx/(d||1)*sp;ny+=dy/(d||1)*sp;if(!levFree(nx,ny)){nx=it.x+(Math.random()-.5)*40*dt*10;ny=it.y+(Math.random()-.5)*40*dt*10}}}
    else if(e.cfg.k==='fish'){it.hop=Math.max(0,Math.sin(it.ph*1.6))*18}
    else if(e.cfg.k==='balloon'){ny-=16*dt;nx+=Math.sin(it.ph*1.4)*26*dt;if(!levFree(it.x,it.y-20)){ny+=40*dt}}
    if(levFree(nx,ny)){it.x=nx;it.y=ny}
    if(Math.hypot(it.x-P.x,it.y-P.y)<(e.cfg.k==='scarab'?20:22)&&(e.cfg.k!=='fish'||it.hop>10)){it.got=1;e.got++;sfx('pick');burst(it.x,it.y-10,10,'255,236,150',90,.5,'star2')}}
  if(e.got>=e.items.length)levEnd(true);else if(e.left<=0)levEnd(false)}catch(err){}return r}}
{const _dv2=drawVFX2;drawVFX2=function(tm){_dv2.apply(this,arguments);const e=LEVT;if(!e||!M||M.theme!==e.th)return;
  for(const it of e.items){if(it.got)continue;const x=it.x-camX,y=it.y-camY;
    if(e.cfg.k==='fly'){ctx.save();ctx.globalCompositeOperation='lighter';const g=ctx.createRadialGradient(x,y,0,x,y,10);g.addColorStop(0,'rgba(255,250,170,.95)');g.addColorStop(1,'rgba(255,230,90,0)');ctx.fillStyle=g;ctx.globalAlpha=.6+.4*Math.sin(it.ph*6);ctx.fillRect(x-10,y-10,20,20);ctx.restore()}
    else if(e.cfg.k==='scarab'){ctx.fillStyle='#3a2410';ctx.beginPath();ctx.ellipse(x,y,8,6,0,0,6.283);ctx.fill();ctx.fillStyle='#ffcc33';ctx.beginPath();ctx.ellipse(x,y-1,7,5,0,0,6.283);ctx.fill();ctx.fillStyle='#fff3b0';ctx.fillRect(x-3,y-4,2,2);ctx.strokeStyle='#3a2410';ctx.lineWidth=1;for(const s2 of [-1,1])for(const k of [-3,0,3]){ctx.beginPath();ctx.moveTo(x+s2*6,y+k);ctx.lineTo(x+s2*(9+Math.sin(it.ph*20+k)),y+k+1);ctx.stroke()}
      ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,220,90,.25)';ctx.beginPath();ctx.arc(x,y,12,0,6.283);ctx.fill();ctx.restore();if(((it.run||0)%2.4)>1.6){ctx.fillStyle='#bfe8ff';ctx.fillRect(x+8,y-12,2,3);ctx.fillRect(x+11,y-9,2,3)}}
    else if(e.cfg.k==='fish'){const yy=y-it.hop;ctx.fillStyle='rgba(120,220,255,.35)';ctx.beginPath();ctx.ellipse(x,y+4,10,3,0,0,6.283);ctx.fill();ctx.fillStyle='#8ff0ff';ctx.beginPath();ctx.ellipse(x,yy,7,4,Math.sin(it.ph*2.2)*.6,0,6.283);ctx.fill();ctx.fillStyle='#ffffff';ctx.fillRect(x+3,yy-2,1,1)}
    else if(e.cfg.k==='balloon'){ctx.strokeStyle='rgba(255,255,255,.7)';ctx.beginPath();ctx.moveTo(x,y+8);ctx.lineTo(x+Math.sin(it.ph*2)*2,y+18);ctx.stroke();ctx.fillStyle='#ffffff';ctx.beginPath();ctx.arc(x-4,y,6,0,6.283);ctx.arc(x+4,y,6,0,6.283);ctx.arc(x,y-4,7,0,6.283);ctx.fill();ctx.fillStyle='rgba(180,210,255,.6)';ctx.beginPath();ctx.arc(x+3,y+2,4,0,6.283);ctx.fill()}}
  if(!e.done){label(VW/2,M.boss&&M.boss.active?46:26,e.cfg.ic+' '+t('lev_'+e.th)+' · '+e.got+'/'+e.items.length+' · '+Math.max(0,Math.ceil(e.left))+'s','#bff0ff')}}}
// start: first visit of the day to a land floor always has one, otherwise 40%
{const _gm5=goMap;goMap=function(){const r=_gm5.apply(this,arguments);try{LEVT=null;if(M&&M.land&&LEV[M.theme]){const day=new Date().toDateString();S.levDay=S.levDay||{};const k=M.id+'|'+day,first=!S.levDay[k];if(first||Math.random()<.4){S.levDay={[k]:1,...(first?{}:S.levDay)};setTimeout(()=>{if(M&&M.land&&!DLG&&!PAUSE)levStart();else setTimeout(()=>{if(M&&M.land)levStart()},2500)},1600)}}}catch(e){}return r}}

// ================= field abilities (Goemon 3 idea): each kind of player can do something the others cannot =================
// kid: crawl into small holes · any grown-up: lift big rocks · sword: break cracked stone · archer: ring the high bell · mage: read old runes · hunter: sees hidden tracks
// A few appear on every cave/land floor each day. If you are the wrong kind, the message says who in the family can do it.
const FA_T={hole:{who:'kid',ic:'🕳️'},rock:{who:'adult',ic:'🪨'},crack:{who:'sword',ic:'🧱'},bell:{who:'archer',ic:'🔔'},rune:{who:'mage',ic:'🔮'},trace:{who:'hunter',ic:'👣'}};
function faCan(k){const w=FA_T[k].who;if(w==='kid')return isKid();if(w==='adult')return !isKid();return !isKid()&&S.job===w}
function faSeed(str){let h=2166136261;for(const c of str){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return()=>((h=Math.imul(h^(h>>>15),2246822507)^Math.imul(h^(h>>>13),3266489909))>>>0)/4294967296}
function faSetup(){M.fa=[];if(!M||M.kind!=='cave'||M.id==='trial'||/^dream/.test(M.id)||!M.FLOOR)return;const day=new Date().toDateString(),rnd2=faSeed(M.id+'|'+day);S.faDone=S.faDone&&S.faDone.day===day?S.faDone:{day,ids:[]};
  const sx=Math.floor((M.spawnDefault||[P.x])[0]/T),sy=Math.floor((M.spawnDefault||[0,P.y])[1]/T);const tiles=freeTilesFrom(sx,sy,40).filter(t=>t.d>=6&&!(M.crystals||[]).some(c=>Math.abs(c.tx-t.x)+Math.abs(c.ty-t.y)<2)&&!(M.digs||[]).some(d=>Math.abs(Math.floor(d.x/T)-t.x)+Math.abs(Math.floor(d.y/T)-t.y)<2));
  if(tiles.length<10)return;const wallN=t=>!M.FLOOR.has(t.x+','+(t.y-1))||M.SOLID.has(t.x+','+(t.y-1));
  const jobs=['crack','bell','rune','trace'];const kinds=['hole','rock',jobs[Math.floor(rnd2()*4)]];if(rnd2()<.5)kinds.push(jobs[Math.floor(rnd2()*4)]);
  const used=[];for(const [i,k] of kinds.entries()){const pool=tiles.filter(t=>(k==='hole'?wallN(t):!wallN(t))&&used.every(u=>Math.abs(u.x-t.x)+Math.abs(u.y-t.y)>=6));if(!pool.length)continue;const t=pool[Math.floor(rnd2()*pool.length)];used.push(t);
    const id=M.id+'-fa'+i;M.fa.push({id,k,tx:t.x,ty:t.y,x:t.x*T+16,y:t.y*T+(k==='hole'?6:20),done:S.faDone.ids.includes(id),ph:rnd2()*6})}}
function faAct(o){if(o.done){say(FA_T[o.k].ic+' '+t('faDone'));return}if(o.k==='trace'&&!faCan('trace'))return;
  if(!faCan(o.k)){say(FA_T[o.k].ic+' '+t('faNo_'+o.k));sfx('wrong');return}
  o.done=1;S.faDone.ids.push(o.id);let coins=10+Math.round((isKid()?5:S.lv)*1.2);const extra=[];
  if(o.k==='hole'){S.gems=(S.gems||0)+1;extra.push('💎 +1');lifeXp('dig',12)}
  else if(o.k==='rock'){S.potions=(S.potions||0)+1;extra.push('🧪 +1');SHAKE=Math.max(SHAKE||0,.15)}
  else if(o.k==='crack'){coins+=10;SHAKE=Math.max(SHAKE||0,.2);burst(o.x,o.y-16,20,'200,190,170',140,.6)}
  else if(o.k==='bell'){let n=0;for(const m of MONS)if(!m.happy&&!m.boss&&Math.hypot(m.x-o.x,m.y-o.y)<260){m.happy=1;m.gone=1.2;n++}extra.push('🔔 '+t('faCalm')+' '+n);fx({k:'ring2',x:o.x,y:o.y-30,life:.8,c:'255,230,140',r:120})}
  else if(o.k==='rune'){gainExp(30+S.lv*3);extra.push('✨ EXP')}
  else if(o.k==='trace'){coins+=25;extra.push('🗝️')}
  S.coins+=coins;burst(o.x,o.y-14,16,'255,236,150',120,.6,'star2');sfx('lvl');say(FA_T[o.k].ic+' '+t('faOk_'+o.k)+' · 🪙 +'+coins+(extra.length?' · '+extra.join(' · '):''));save();hud()}
// taps on the objects (checked before the normal world tap) and walking up to them
addEventListener('pointerdown',e=>{try{if(!S||!M||!M.fa||!M.fa.length||PAUSE||e.target!==cv)return;const dpr=devicePixelRatio||1,wx=e.clientX*dpr/SC+camX,wy=e.clientY*dpr/SC+camY;
  const o=M.fa.find(f=>(f.k!=='trace'||faCan('trace'))&&Math.abs(f.x-wx)<18&&wy>f.y-34&&wy<f.y+10);if(!o)return;e.stopPropagation();e.preventDefault();
  if(Math.hypot(P.x-o.x,P.y-o.y)<40){faAct(o);return}const p=findPath(M,P.x,P.y,o.x,o.y+(o.k==='hole'?26:14));if(p){P.path=p;P.target=null;P.faGo=o}}catch(err){}},true);
{const _up8=update;update=function(dt){const r=_up8.apply(this,arguments);try{if(P.faGo){const o=P.faGo;if(!M.fa||!M.fa.includes(o))P.faGo=null;else if(Math.hypot(P.x-o.x,P.y-o.y)<40){P.faGo=null;faAct(o)}else if(!P.path||!P.path.length)P.faGo=null}if(M&&M.fa)for(const f of M.fa)f.ph+=dt}catch(e){}return r}}
{const _aa2=autoAct;autoAct=function(){try{if(M&&M.fa){const o=M.fa.filter(f=>!f.done&&(f.k!=='trace'||faCan('trace'))).find(f=>Math.hypot(P.x-f.x,P.y-f.y)<40);if(o&&!MONS.some(m=>!m.happy&&Math.hypot(m.x-P.x,m.y-P.y)<70)){faAct(o);return}}}catch(e){}return _aa2.apply(this,arguments)}}
{const _gm6=goMap;goMap=function(){const r=_gm6.apply(this,arguments);try{P.faGo=null;faSetup()}catch(e){}return r}}
// drawing (ground layer): all code-drawn so no new files are needed
{const _dw2=drawWater2;drawWater2=function(tm){_dw2.apply(this,arguments);if(!M||!M.fa)return;for(const o of M.fa){const x=Math.round(o.x-camX),y=Math.round(o.y-camY);if(x<-40||y<-60||x>VW+40||y>VH+40)continue;const near=Math.hypot(P.x-o.x,P.y-o.y)<70;
  switch(o.k){
  case'hole':ctx.fillStyle='#2a1a12';ctx.beginPath();ctx.ellipse(x,y+2,11,9,0,Math.PI,0);ctx.lineTo(x+11,y+8);ctx.lineTo(x-11,y+8);ctx.fill();ctx.fillStyle=o.done?'#1a120c':'#0b0710';ctx.beginPath();ctx.ellipse(x,y+3,8,7,0,Math.PI,0);ctx.lineTo(x+8,y+8);ctx.lineTo(x-8,y+8);ctx.fill();if(!o.done){ctx.fillStyle=`rgba(255,230,140,${.5+.5*Math.sin(o.ph*4)})`;ctx.fillRect(x-1,y+1,2,2)}break;
  case'rock':if(o.done){ctx.fillStyle='#6f6a74';ctx.fillRect(x-10,y-2,5,3);ctx.fillRect(x+4,y,4,3);ctx.fillStyle='#1a1410';ctx.beginPath();ctx.ellipse(x,y,9,4,0,0,6.283);ctx.fill();break}
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.beginPath();ctx.ellipse(x,y+2,15,5,0,0,6.283);ctx.fill();ctx.fillStyle='#5d5866';ctx.beginPath();ctx.ellipse(x,y-9,15,12,0,0,6.283);ctx.fill();ctx.fillStyle='#8a8494';ctx.beginPath();ctx.ellipse(x-4,y-13,9,6,0,0,6.283);ctx.fill();ctx.strokeStyle='#3e3a46';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x+2,y-18);ctx.lineTo(x+5,y-10);ctx.lineTo(x+2,y-4);ctx.stroke();break;
  case'crack':if(o.done){ctx.fillStyle='#7c7468';for(const [a,b] of [[-8,0],[3,1],[8,-2],[-2,3]])ctx.fillRect(x+a,y+b,4,3);break}ctx.fillStyle='#7c7468';ctx.fillRect(x-10,y-26,20,26);ctx.fillStyle='#958c80';ctx.fillRect(x-10,y-26,20,4);ctx.strokeStyle='#2d2620';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x-2,y-24);ctx.lineTo(x+3,y-16);ctx.lineTo(x-3,y-10);ctx.lineTo(x+2,y-2);ctx.stroke();ctx.strokeStyle=`rgba(255,200,120,${.3+.3*Math.sin(o.ph*3)})`;ctx.stroke();break;
  case'bell':{ctx.fillStyle='#5a3a20';ctx.fillRect(x-1,y-40,3,40);ctx.fillRect(x-1,y-40,12,3);const sw=o.done?0:Math.sin(o.ph*2)*.25;ctx.save();ctx.translate(x+10,y-37);ctx.rotate(sw);ctx.fillStyle=o.done?'#8a7a50':'#f0c040';ctx.beginPath();ctx.moveTo(-5,10);ctx.quadraticCurveTo(-5,0,0,0);ctx.quadraticCurveTo(5,0,5,10);ctx.closePath();ctx.fill();ctx.fillStyle='#fff1b0';ctx.fillRect(-3,2,1,5);ctx.restore();break}
  case'rune':if(o.done)break;ctx.save();if(!M.bright)ctx.globalCompositeOperation='lighter';ctx.strokeStyle=M.bright?`rgba(110,50,190,${.7+.2*Math.sin(o.ph*2)})`:`rgba(190,140,255,${.5+.3*Math.sin(o.ph*2)})`;ctx.lineWidth=M.bright?2:1.5;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(x,y,15,7,0,0,6.283);ctx.stroke();ctx.beginPath();for(let i=0;i<5;i++){const a=i/5*6.283+o.ph*.5;ctx.moveTo(x+Math.cos(a)*9,y+Math.sin(a)*4);ctx.lineTo(x+Math.cos(a+2.5)*9,y+Math.sin(a+2.5)*4)}ctx.stroke();ctx.restore();break;
  case'trace':if(o.done||!faCan('trace'))break;ctx.fillStyle=`rgba(255,220,120,${.35+.25*Math.sin(o.ph*3)})`;for(let i=0;i<4;i++){ctx.fillRect(x-30+i*8,y+((i%2)?2:-2),3,2)}ctx.fillStyle='#6b4a2a';ctx.beginPath();ctx.ellipse(x+6,y,7,4,0,0,6.283);ctx.fill();ctx.fillStyle=`rgba(255,240,170,${.6+.4*Math.sin(o.ph*5)})`;ctx.fillRect(x+5,y-3,2,2);break}
  if(near&&!o.done&&(o.k!=='trace'||faCan('trace'))){label(x,y-(o.k==='bell'?46:o.k==='crack'?32:o.k==='rock'?26:14),FA_T[o.k].ic+' '+t('fa_'+o.k)+(faCan(o.k)?'':' · '+t('faWho_'+FA_T[o.k].who)),faCan(o.k)?'#ffe7a0':'#c8c0d8')}}}}

// ================= Academy class ranks (RO "Basic Skill" idea): features open one class at a time =================
// Every player is a student starting in class 1. Each class unlocks 1–3 things with a short scene from the wizard teacher.
// Progress is per player. Places opened by a class can still be visited together online (RO style: nobody is walled off from friends).
const RANK_FEAT={compass:2,market:2,dig:2,home:3,book:3,fish:4,lake:4,dash:4,warp:5,cave2:5,tools:5,wheel:5,pets:6,emote:6,visit:6,cave3:6,trial:7,gift:7,lands:8,events:8,fa:8,auto:8,beach:9,falls:9,sell:9,dream:10};
const RANK_PLACE={market:'market',home:'home',room:'home',lake:'lake',cave2:'cave2',cave3:'cave3',trial:'trial',beach:'beach',falls:'falls'};
const cave1Need=()=>(CAVE_CFG.cave1&&CAVE_CFG.cave1.crystals)||8;
const RANK_REQ={2:{k:()=>[totalCrystals(),3],a:()=>[Math.max(totalCrystals()>=1?1:0,S.lv>=3?1:0),1]},
  3:{k:()=>[((S.crystals||{}).cave1||[]).length,cave1Need()],a:()=>[S.lv>=5||((S.crystals||{}).cave1||[]).length>=cave1Need()?1:0,1]},
  4:{k:()=>[S.planted?1:0,1],a:()=>[S.planted?1:0,1]},
  5:{k:()=>[S.fishCaught||0,2],a:()=>[S.fishCaught||0,1]},
  6:{k:()=>[((S.crystals||{}).cave2||[]).length,3],a:()=>[S.lv>=12||((S.crystals||{}).cave2||[]).length>=3?1:0,1]},
  7:{k:()=>[S.boss?1:0,1],a:()=>[S.boss?1:0,1]},
  8:{k:()=>[S.trialN?1:0,1],a:()=>[S.trialN?1:0,1]},
  9:{k:()=>[chap()>=4?1:0,1],a:()=>[chap()>=4?1:0,1]},
  10:{k:()=>[chap()>=5?1:0,1],a:()=>[chap()>=5?1:0,1]}};
const TEST_ALL=()=>navigator.webdriver&&!/rank=1/.test(location.search); // automated regression runs keep everything open
function rank(){if(!S)return 1;if(TEST_ALL())return 10;return S.rank||1}
function rHas(f){return rank()>=(RANK_FEAT[f]||1)}
function rankProg(n){const r=RANK_REQ[n];if(!r||!S)return[1,1];try{return(isKid()?r.k:r.a)()}catch(e){return[0,1]}}
function rankMigrate(){if(!S||S.rank)return;let r=1;S.fishCaught=S.fishCaught||Object.keys(S.fish||{}).length;try{const h=HOME.get();if(Object.keys(h.plots||{}).length||Object.values(h.pantry||{}).some(v=>v>0))S.planted=1}catch(e){}
  for(let n=2;n<=10;n++){const [a,b]=rankProg(n);if(a>=b)r=n;else break}
  if(S.boss)r=Math.max(r,7);if(S.trialN)r=Math.max(r,8);if(chap()>=4)r=Math.max(r,9);if(chap()>=5)r=10;if(S.lv>=20&&!isKid())r=Math.max(r,6);S.rank=r;save()}
// the scenes: the wizard (dad NPC) announces each class
for(let n=2;n<=10;n++)SCENES['rank'+n]=[['dad','rkUp'+n],['dad','rkGet'+n]];
let RANK_T=0;
function rankUp(){const n=(S.rank||1)+1;if(n>10)return;S.rank=n;save();hud();S.seen=S.seen||{};delete S.seen['rank'+n];
  playScene('rank'+n,()=>{celebrate();sfx('lvl');rankGlow(n);say('🎓 '+t('rkNow')+' '+n)})}
function rankGlow(n){const ids={2:['bCmp'],3:['bBook'],4:['bDash'],5:['bMap','bWheel'],6:['bPets','bEmo','bVisit'],8:['bAuto']}[n]||[];ids.forEach(id=>{const b=$(id);if(b){b.classList.add('laNew');setTimeout(()=>b.classList.remove('laNew'),12000)}})}
{const _up9=update;update=function(dt){const r=_up9.apply(this,arguments);try{if(S&&!PAUSE&&!DLG&&!TEST_ALL()){RANK_T-=dt;if(RANK_T<=0){RANK_T=1;rankMigrate();const n=(S.rank||1)+1;if(n<=10){const [a,b]=rankProg(n);if(a>=b)rankUp()}}}}catch(e){}return r}}
// hide what is not open yet (never un-hides something the game hid for other reasons)
const RANK_BTN={bCmp:'compass',bBook:'book',bDash:'dash',bMap:'warp',bWheel:'wheel',bPets:'pets',bEmo:'emote',bVisit:'visit',bAuto:'auto'};
{const _hud2=hud;hud=function(){const r=_hud2.apply(this,arguments);try{if(S)for(const [id,f] of Object.entries(RANK_BTN)){const b=$(id);if(b&&!rHas(f))b.style.display='none';else if(b&&b.dataset.rk!=='1'){if(b.style.display==='none'&&id!=='bSit'&&id!=='bAuto'&&id!=='bDash')b.style.display='';b.dataset.rk='1'}}}catch(e){}return r}}
// places
function placeRank(id){if(RANK_PLACE[id])return RANK_FEAT[RANK_PLACE[id]];if(/^(forest|desert|ulake|sky)\d/.test(id))return RANK_FEAT.lands;if(/^dream/.test(id))return RANK_FEAT.dream;return 1}
function withFamily(){return Net&&Net.online&&Net.others&&Object.keys(Net.others).length>0}
{const _ue=useExit;useExit=function(e){try{if(e&&e.to&&!e.locked){const need=placeRank(e.to);if(rank()<need&&!withFamily()){say('🎓 '+t('rkNeed')+' '+need+' · '+t('rkAsk'));sfx('wrong');return}}}catch(err){}return _ue.apply(this,arguments)}}
// actions
{const _fa=fishAct;fishAct=function(){if(!rHas('fish')){say('🎣 '+t('rkNeed')+' '+RANK_FEAT.fish);return}return _fa.apply(this,arguments)}}
{const _dd2=doDig;doDig=function(d){if(!rHas('dig')){say('⛏️ '+t('rkNeed')+' '+RANK_FEAT.dig);return}return _dd2.apply(this,arguments)}}
{const _cf2=catchFish;catchFish=function(){const r=_cf2.apply(this,arguments);S.fishCaught=(S.fishCaught||0)+1;return r}}
{const _pa2=plotAct;plotAct=function(p){const r=_pa2.apply(this,arguments);try{if(Object.keys(HOME.get().plots||{}).length)S.planted=1}catch(e){}return r}}
{const _fs=faSetup;faSetup=function(){_fs.apply(this,arguments);if(!rHas('fa'))M.fa=[]}}
{const _ls=levStart;levStart=function(){if(!rHas('events'))return;return _ls.apply(this,arguments)}}
{const _ob=openBag;openBag=function(){const r=_ob.apply(this,arguments);try{if(!rHas('gift')){const g=$('gbBtn');if(g)g.remove()}if(!rHas('tools'))document.querySelectorAll('[data-tool]').forEach(b=>{if(['brush','lantern','glass','shovel','rod'].includes(b.dataset.tool))b.disabled=true});addRankBtn()}catch(e){}return r}}
{const _os3=openStats;openStats=function(){const r=_os3.apply(this,arguments);try{addRankBtn()}catch(e){}return r}}
{const _sh2=openShop;openShop=function(){const r=_sh2.apply(this,arguments);try{if(!rHas('sell')){const b=$('fsBtn');if(b)b.remove()}}catch(e){}return r}}
{const _ow3=openWarp;openWarp=function(){const r=_ow3.apply(this,arguments);try{document.querySelectorAll('[data-land]').forEach(b=>{const id=b.dataset.land,need=id==='trial'?RANK_FEAT.trial:(id==='beach'||id==='falls')?RANK_FEAT[id]:RANK_FEAT.lands;if(rank()<need&&!withFamily()){b.disabled=true;b.textContent='🎓 '+t('rkNeed')+' '+need+' · '+b.textContent.replace(/^\S+\s/,'')}})}catch(e){}return r}}
// the class panel: done classes, the next task with progress, and "???" for what is further ahead
function rankTask(n){return t('rkTask'+n+(isKid()?'k':'a'))}
function openRank(){const cur=rank(),n=cur+1;const rows=[];for(let i=1;i<=10;i++){const done=i<=cur,next=i===n;const [a,b]=next?rankProg(i):[0,0];
    rows.push(`<div class="pn" style="margin:3px 0;opacity:${done||next?1:.55}"><b>${done?'✅':next?'🎯':'🔒'} ${t('rkClass')} ${i}</b> · ${done||next?t('rkGet'+i+'s'):'???'}${next?`<br><small>${rankTask(i)} (${Math.min(a,b)}/${b})</small>`:''}</div>`)}
  modal(`<h2>🎓 ${t('rkTitle')} · ${t('rkClass')} ${cur}</h2><p class="note">${t('rkHow')}</p>${rows.join('')}`)}
function addRankBtn(){const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(!h||$('rkBtn'))return;const b=document.createElement('button');b.id='rkBtn';b.textContent='🎓 '+t('rkClass')+' '+rank();b.style.marginLeft='8px';b.onclick=openRank;h.after(b)}
// goal line in town: the next class task
{const _ug4=updateGoal;updateGoal=function(){const r=_ug4.apply(this,arguments);try{if(S&&M&&M.kind!=='cave'&&!TEST_ALL()&&rank()<10){const n=rank()+1,[a,b]=rankProg(n);const el=$('goal');if(el&&a<b)el.textContent='🎓 '+t('rkClass')+' '+n+': '+rankTask(n)+(b>1?' '+a+'/'+b:'')}}catch(e){}return r}}
addEventListener('click',e=>{try{if(e.target&&e.target.id==='goal'&&S)openRank()}catch(err){}});
(()=>{const st=document.createElement('style');st.textContent='@keyframes laGlow{0%,100%{box-shadow:0 0 0 0 rgba(255,215,110,.0)}50%{box-shadow:0 0 16px 6px rgba(255,215,110,.9)}}.laNew{animation:laGlow 1.2s ease-in-out infinite}#goal{cursor:pointer}';document.head.append(st)})();

// ================= mystery: "the secret of the Grey Mist" (Octopath diary · Pokémon silhouettes · Stardew bundles · Trickster map pieces) =================
// Lore: the First Lamplighter lit the Great Lantern of the Academy. Two sparks were born from its flame: bright Peb, and a quiet grey spark that sat behind the lantern
// where no light reached. Nobody noticed it; it grew lonely and became the Grey Mist. When the lantern dimmed, Peb forgot everything. The Academy sealed the Room of the First Lantern.
const DIARY=[['cave1',5],['cave2',5],['cave3',6],['lake',5],['forest1',8],['desert1',8],['ulake1',8],['sky1',8],['dream5',10],['beach',9]];
function diaryHave(){return (S&&S.diary)||[]}
function diarySpawn(){if(!M||!S||!rHas('warp'))return;const i=DIARY.findIndex(([id,need])=>id===M.id);if(i<0||diaryHave().includes(i)||rank()<DIARY[i][1])return;
  const sx=Math.floor((M.spawnDefault||[P.x])[0]/T),sy=Math.floor((M.spawnDefault||[0,P.y])[1]/T),rnd2=faSeed('diary'+M.id);const tl=freeTilesFrom(sx,sy,18).filter(t=>t.d>=8&&t.d<=16);if(!tl.length)return;const t0=tl[Math.floor(rnd2()*tl.length)];M.page={i,x:t0.x*T+16,y:t0.y*T+18,ph:0}}
function diaryRead(i,fresh){const pages=diaryHave().slice().sort((a,b)=>a-b);const shown=fresh!=null?[fresh]:pages;
  modal(`<h2>📓 ${t('dyTitle')} · ${pages.length}/${DIARY.length}</h2>${shown.map(p=>`<div class="pn" style="margin:6px 0;font-style:italic;background:#2a2238"><small>${t('dyPage')} ${p+1}</small><br>“${t('dy'+(p+1))}”</div>`).join('')}${fresh!=null?`<p><button id="dyAll">📓 ${t('dyAll')}</button></p>`:mysteryNotes()}`);const b=$('dyAll');if(b)b.onclick=()=>diaryRead()}
function mysteryNotes(){const sh=S.shadowSeen||0,mf=Object.keys(S.mapFrag||{}).length,rm=Object.keys(S.rooms||{}).length;return `<h3>🔎 ${t('dyClues')}</h3><div class="pn">👁️ ${t('dyShadow')} ${sh}/3${sh>=3?' · '+t('dyShadowDone'):''}<br>🗺️ ${t('dyMap')} ${mf}/4<br>🚪 ${t('dyRooms')} ${rm}/4</div>`}
{const _up10=update;update=function(dt){const r=_up10.apply(this,arguments);try{if(M&&M.page&&S&&!PAUSE){const p=M.page;p.ph+=dt;if(Math.hypot(P.x-p.x,P.y-p.y)<24){S.diary=diaryHave().concat(p.i);M.page=null;save();sfx('lvl');burst(p.x,p.y-16,18,'255,240,200',100,.6,'star2');diaryRead(null,p.i)}}}catch(e){}return r}}
{const _gm7=goMap;goMap=function(){const r=_gm7.apply(this,arguments);try{M.page=null;diarySpawn();M.door=null;doorSpawn();SHADOW=null}catch(e){}return r}}
// the grey shadow: seen for a moment at dusk or night in town (class 3+); catch it 3 times
let SHADOW=null,SHT=12;
{const _up11=update;update=function(dt){const r=_up11.apply(this,arguments);try{if(!S||!M||PAUSE||M.kind!=='town'||rank()<3||(S.shadowSeen||0)>=3)return r;const ph=typeof dayPhase==='function'?dayPhase():'day';
  if(SHADOW){SHADOW.t-=dt;SHADOW.x+=Math.cos(SHADOW.a)*14*dt;SHADOW.y+=Math.sin(SHADOW.a)*10*dt;if(Math.hypot(P.x-SHADOW.x,P.y-SHADOW.y)<30){S.shadowSeen=(S.shadowSeen||0)+1;save();sfx('warp');say('👁️ '+t('shSeen'+S.shadowSeen));SHADOW=null}else if(SHADOW.t<=0){SHADOW=null;say('👁️ '+t('shGone'))}}
  else if(ph==='night'||ph==='dusk'){SHT-=dt;if(SHT<=0){SHT=25+Math.random()*20;const tl=freeTilesFrom(Math.floor(P.x/T),Math.floor(P.y/T),8).filter(q=>q.d>=4);if(tl.length){const q=tl[Math.floor(Math.random()*tl.length)];SHADOW={x:q.x*T+16,y:q.y*T+16,t:6,a:Math.random()*6.28};say('👁️ '+t('shHint'))}}}}catch(e){}return r}}
// the sealed door of the Academy in the plaza: visible from class 3, opens at class 7 with 4 "rooms" (bundles)
const ROOMS=[['water','🌊',()=>fishCount('ffish')>=2&&fishCount('sfish')>=1,()=>{fishTake('ffish',2);fishTake('sfish',1)}],['earth','🌱',()=>{const p=HOME.get().pantry||{};return Object.values(p).filter(v=>v>0).length>=3},()=>{const h=HOME.get();let n=0;for(const k of Object.keys(h.pantry)){if(n<3&&h.pantry[k]>0){h.pantry[k]--;n++}}HOME.put(h)}],['stone','💎',()=>(S.gems||0)>=5,()=>{S.gems-=5}],['light','🏮',()=>(S.trialN||0)>=3&&totalCrystals()>=30,()=>{}]];
function doorSpawn(){if(!M||M.id!=='plaza'||rank()<3)return;const sp=M.spawnDefault||[18*T,12*T],sx=Math.floor(sp[0]/T),sy=Math.floor(sp[1]/T);const tl=freeTilesFrom(sx,sy,12).filter(q=>q.d>=5&&q.d<=9);const rnd2=faSeed('door');if(!tl.length)return;const q=tl[Math.floor(rnd2()*tl.length)];M.door={x:q.x*T+16,y:q.y*T+20}}
function openRooms(){if(rank()<7){say('🚪 '+t('drLocked'));return}S.rooms=S.rooms||{};const rows=ROOMS.map(([k,ic,ok])=>{const done=S.rooms[k];return `<div class="pn" style="margin:4px 0"><b>${ic} ${t('rm_'+k)}</b>${done?' ✅':''}<br><small>${done?'“'+t('mu_'+k)+'”':t('rn_'+k)}</small>${done?'':`<div><button data-room="${k}" ${ok()?'':'disabled'}>${t('rmGive')}</button></div>`}</div>`}).join('');
  modal(`<h2>🚪 ${t('drTitle')} · ${Object.keys(S.rooms).length}/4</h2><p class="note">${t('drHow')}</p>${rows}`);
  document.querySelectorAll('[data-room]').forEach(b=>b.onclick=()=>{const R=ROOMS.find(x=>x[0]===b.dataset.room);if(!R||!R[2]())return;R[3]();S.rooms[R[0]]=1;S.coins+=120;save();hud();celebrate();sfx('lvl');say('🚪 '+t('rmDone')+' · 🪙 +120');openRooms()})}
// map pieces from digging in the lands (class 8+)
{const _dd3=doDig;doDig=function(d){const had=!!DIG;const r=_dd3.apply(this,arguments);try{if(!had&&DIG&&M&&M.land&&rank()>=8){S.mapFrag=S.mapFrag||{};if(!S.mapFrag[M.land]&&Math.random()<.35){S.mapFrag[M.land]=1;save();setTimeout(()=>{say('🗺️ '+t('mfGot')+' '+Object.keys(S.mapFrag).length+'/4');sfx('lvl')},900)}}}catch(e){}return r}}
// taps / attack button on the door
{const _aa3=autoAct;autoAct=function(){try{if(M&&M.door&&Math.hypot(P.x-M.door.x,P.y-M.door.y)<44){openRooms();return}}catch(e){}return _aa3.apply(this,arguments)}}
addEventListener('pointerdown',e=>{try{if(!S||!M||!M.door||PAUSE||e.target!==cv)return;const dpr=devicePixelRatio||1,wx=e.clientX*dpr/SC+camX,wy=e.clientY*dpr/SC+camY;if(Math.abs(M.door.x-wx)<20&&wy>M.door.y-44&&wy<M.door.y+6){e.stopPropagation();if(Math.hypot(P.x-M.door.x,P.y-M.door.y)<46)openRooms();else{const p=findPath(M,P.x,P.y,M.door.x,M.door.y+16);if(p){P.path=p;P.target=null;setTimeout(function chk(){if(Math.hypot(P.x-M.door.x,P.y-M.door.y)<46)openRooms();else if(P.path&&P.path.length)setTimeout(chk,300)},300)}}}}catch(err){}},true);
// drawing: floating diary page, the sealed door, the shadow
{const _dv3=drawVFX2;drawVFX2=function(tm){_dv3.apply(this,arguments);try{if(M&&M.page){const p=M.page,x=p.x-camX,y=p.y-camY-6-Math.sin(p.ph*2)*3;ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,230,160,.35)';ctx.beginPath();ctx.arc(x,y,12,0,6.283);ctx.fill();ctx.restore();ctx.save();ctx.translate(x,y);ctx.rotate(Math.sin(p.ph)*.15);ctx.fillStyle='#f3e6c4';ctx.fillRect(-6,-8,12,15);ctx.fillStyle='#b99a64';for(let i=0;i<4;i++)ctx.fillRect(-4,-5+i*3,8,1);ctx.restore()}
  if(M&&M.door){const x=M.door.x-camX,y=M.door.y-camY,open=rank()>=7;ctx.fillStyle='#4a3f5c';ctx.fillRect(x-16,y-40,32,40);ctx.fillStyle='#6b5d82';ctx.beginPath();ctx.arc(x,y-40,16,Math.PI,0);ctx.fill();ctx.fillStyle=open?'#2a1f3a':'#1d1628';ctx.fillRect(x-10,y-32,20,32);ctx.beginPath();ctx.arc(x,y-32,10,Math.PI,0);ctx.fill();
    ctx.fillStyle='#e8b04a';ctx.fillRect(x-2,y-26,4,7);ctx.fillRect(x-3,y-27,6,2);ctx.fillStyle='#7fe0ff';ctx.fillRect(x-1,y-24,2,3);if(open){ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(255,210,120,${.2+.15*Math.sin(tm*3)})`;ctx.fillRect(x-10,y-32,20,32);ctx.restore()}
    if(Math.hypot(P.x-M.door.x,P.y-M.door.y)<80)label(x,y-60,'🚪 '+t('drName')+(open?'':' · 🔒'),'#e8dcff')}
  if(SHADOW){const x=SHADOW.x-camX,y=SHADOW.y-camY,a=Math.min(1,SHADOW.t/1.5)*.8;ctx.fillStyle=`rgba(150,150,170,${a*.6})`;for(let i=0;i<5;i++){ctx.beginPath();ctx.arc(x+Math.sin(tm*3+i)*5,y-10-i*3+Math.cos(tm*2+i)*2,6-i*.6,0,6.283);ctx.fill()}ctx.fillStyle=`rgba(255,255,255,${a})`;ctx.fillRect(x-3,y-18,2,2);ctx.fillRect(x+1,y-18,2,2)}}catch(e){}}}
// diary button (class 5+) in the bag and stats
{const _ob2=openBag;openBag=function(){const r=_ob2.apply(this,arguments);try{addDiaryBtn()}catch(e){}return r}}
{const _os4=openStats;openStats=function(){const r=_os4.apply(this,arguments);try{addDiaryBtn()}catch(e){}return r}}
function addDiaryBtn(){if(rank()<3||$('dyBtn'))return;const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(!h)return;const b=document.createElement('button');b.id='dyBtn';b.textContent='📓 '+diaryHave().length+'/'+DIARY.length;b.style.marginLeft='8px';b.onclick=()=>diaryRead();h.after(b)}
// class 11 teaser: appears after the ending, needs every clue
{const _or=openRank;openRank=function(){const r=_or.apply(this,arguments);try{if(S&&S.ended){const all=diaryHave().length>=DIARY.length&&Object.keys(S.mapFrag||{}).length>=4&&Object.keys(S.rooms||{}).length>=4;const d=document.createElement('div');d.className='pn';d.style.cssText='margin:3px 0;border-color:#b48cff';d.innerHTML=`<b>✨ ${t('rkClass')} 11 · ???</b><br><small>${all?t('rk11ready'):t('rk11hint')}</small>`;const last=[...document.querySelectorAll('#modal .pn,.modal .pn')].pop();last&&last.after(d)}}catch(e){}return r}}

// ================= art direction in code: 60 identity · 30 LA family · 10 signal (ART_DIRECTION.md v2) =================
// --- music: every zone has its own scale/instrument (60), and every track carries the 4-note "lantern" motif (30) ---
Object.assign(SCALES,{forest:{root:62,sc:[0,2,4,7,9],bpm:84,wave:'triangle',pad:[0,7,14]},desert:{root:57,sc:[0,1,4,5,7,8,10],bpm:96,wave:'sawtooth',pad:[0,7]},
  ulake:{root:55,sc:[0,2,4,6,7,9,11],bpm:66,wave:'sine',pad:[0,4,11]},sky:{root:67,sc:[0,2,4,7,9],bpm:100,wave:'sine',pad:[0,4,7,12]},beach:{root:65,sc:[0,2,4,5,7,9],bpm:104,wave:'triangle',pad:[0,4,7]},
  falls:{root:62,sc:[0,2,3,5,7,9,10],bpm:88,wave:'triangle',pad:[0,3,7]},trial:{root:60,sc:[0,2,4,5,7,9,11],bpm:118,wave:'square',pad:[0,4,7]}});
Object.assign(MELODY,{forest:[0,2,4,null,3,null,2,1,0,null,4,3,2,null,1,null],desert:[0,1,0,4,3,null,1,0,2,1,2,4,3,1,0,null],ulake:[0,null,null,4,null,2,null,null,1,null,null,5,null,3,null,null],
  sky:[4,3,4,2,3,1,2,0,4,3,4,5,4,2,1,null],beach:[0,2,4,2,5,4,2,null,1,3,5,3,4,2,0,null],falls:[0,2,3,null,4,3,2,null,0,2,5,4,3,null,1,null],trial:[0,0,4,4,5,5,4,null,3,3,2,2,1,1,0,null]});
const LA_MOTIF=[4,2,3,0]; // the lantern theme: plays softly as a bell every 32 steps in every track
{const _sm=setMusic;setMusic=function(mode){let m=mode;try{if(M){if(M.id==='trial')m='trial';else if(mode==='cave'&&M.theme&&SCALES[M.theme])m=M.theme;else if(mode==='town'&&SCALES[M.id])m=M.id}}catch(e){}return _sm.call(this,m)}}
{const _bt=bgmTick;bgmTick=function(){const before=BGM.step,t0=BGM.next;const r=_bt.apply(this,arguments);try{const s=SCALES[BGM.mode];if(!s||!AC)return r;const beat=60/s.bpm/2;
  for(let st=before;st<BGM.step;st++){const k=st%32;if(k>=24&&k<32&&k%2===0){const i=(k-24)/2,deg=LA_MOTIF[i],n=s.root+24+s.sc[deg%s.sc.length];tone(midi(n),t0+(st-before)*beat,beat*2.4,'sine',.014)}}}catch(e){}return r}}
// --- monsters: the grey mist dust clings to every monster that is not calmed yet (the LA story, on every creature) ---
{const _dm3=drawMon;drawMon=function(m,tm){const r=_dm3.apply(this,arguments);try{if(m.happy||m.gone)return r;const x=m.x-camX,y=m.y-camY,h=m.h||22,w=(m.w||24)*.5;m.dust=m.dust||[0,1,2,3].map(i=>[Math.random()*2-1,Math.random(),2.5+Math.random()*2,Math.random()*6]);
  ctx.save();ctx.globalAlpha=.55;ctx.fillStyle='#8f8ca6';for(const [dx,dy,rr,ph] of m.dust){ctx.beginPath();ctx.arc(x+dx*w,y-h*(.25+dy*.6)+Math.sin(tm*2+ph),rr*(m.boss?2.2:1),0,6.283);ctx.fill()}
  if(Math.random()<.03)FX.push({k:'spark2',x:m.x+(Math.random()-.5)*w*2,y:m.y-h*.6,vx:(Math.random()-.5)*10,vy:-12,t:0,life:.9,c:'160,158,185',s:1.5});ctx.restore()}catch(e){}return r}}
// --- signals: a soft pulse under things you can use (gold), knowledge (cyan) and mystery clues (silver) near you ---
const SIGC={gold:'255,200,87',cyan:'127,224,255',silver:'185,183,207'};
function sigRing(x,y,c,tm,r0){const p=(tm*1.2)%1;ctx.strokeStyle=`rgba(${c},${.55*(1-p)})`;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(x,y,(r0||12)+p*8,((r0||12)+p*8)*.45,0,0,6.283);ctx.stroke()}
{const _dw3=drawWater2;drawWater2=function(tm){_dw3.apply(this,arguments);try{if(!M||!S||PAUSE)return;const near=o=>Math.hypot(o.x-P.x,o.y-P.y)<240;const X=o=>o.x-camX,Y=o=>o.y-camY;
  for(const c of M.chests||[])if(!c.open&&near(c))sigRing(X(c),Y(c)+4,SIGC.gold,tm,14);
  for(const d of M.digs||[])if(!d.done&&near(d)&&rHas('dig'))sigRing(X(d),Y(d)+2,SIGC.gold,tm,11);
  if(M.fishSpot&&near(M.fishSpot)&&rHas('fish'))sigRing(M.fishSpot.x-camX,M.fishSpot.y-camY+6,SIGC.gold,tm,13);
  for(const n of M.npcs||[])if(REQMARK&&REQMARK[n.npc]&&REQMARK[n.npc]!=='done'&&near(n))sigRing(X(n),Y(n)+2,SIGC.gold,tm,13);
  for(const c of M.crystals||[])if(!c.awake&&near(c))sigRing(X(c),Y(c)+2,SIGC.cyan,tm+.5,12);
  if(M.page&&near(M.page))sigRing(X(M.page),Y(M.page)+4,SIGC.silver,tm,12);if(M.door&&near(M.door))sigRing(X(M.door),Y(M.door)+2,SIGC.silver,tm,18)}catch(e){}}}

// ================= critique fixes (ART_DIRECTION §7) =================
// 1) plum outlines: the outer dark outline of every sprite becomes LA plum (#3A1E3F) once at load; tiles are left alone
const PLUM=[58,30,63],NO_PLUM=new Set(['ground','cliff','water','cobble','cave','house','laLogo','titleArt']);const PLUMMED=new Set();
function plumCanvas(src){const w=src.width,h=src.height;if(!w||!h||w*h>1400000)return src;const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.drawImage(src,0,0);const d=g.getImageData(0,0,w,h),p=d.data;const A=i=>p[i+3];let n=0;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(A(i)<128)continue;const lum=(p[i]*.3+p[i+1]*.59+p[i+2]*.11)/255;if(lum>.2)continue;
    const edge=(x===0||A(i-4)<40)||(x===w-1||A(i+4)<40)||(y===0||A(i-w*4)<40)||(y===h-1||A(i+w*4)<40);if(!edge)continue;p[i]=PLUM[0];p[i+1]=PLUM[1];p[i+2]=PLUM[2];n++}
  g.putImageData(d,0,0);c._plum=n;return c}
function plumAll(){try{for(const k of Object.keys(IMG)){if(PLUMMED.has(k)||NO_PLUM.has(k)||/^tiles|wang/i.test(k))continue;const im=IMG[k];if(!im||!(im.width||im.naturalWidth))continue;IMG[k]=plumCanvas(im);PLUMMED.add(k)}
  for(const k of Object.keys(MON_ART||{})){if(PLUMMED.has('m:'+k))continue;MON_ART[k]=MON_ART[k].map(fr=>plumCanvas(fr));PLUMMED.add('m:'+k)}}catch(e){}}
{const _li=loadImages;loadImages=function(){return _li.apply(this,arguments).then(r=>{plumAll();return r})}}
{const _sg2=startGame;startGame=function(){plumAll();return _sg2.apply(this,arguments)}}
// 2) decorative crystals keep the zone's own colour; only quiz crystals are cyan (the 10% "knowledge" signal)
const DECO_HUE={cave:275,forest:325,desert:38,ulake:8,sky:258,dream:285};const DECO_KEYS=['dCyan','dShards'];const DTINT={};
function decoAtlas(theme){const hue=DECO_HUE[theme]??275,key='dprops_'+theme;if(IMG[key])return key;const src=IMG.dprops;if(!src)return 'dprops';const c=document.createElement('canvas');c.width=src.width;c.height=src.height;const g=c.getContext('2d');g.drawImage(src,0,0);
  for(const dk of DECO_KEYS){const r=DR[dk];if(!r)continue;const d=g.getImageData(r[0],r[1],64,64),p=d.data;for(let i=0;i<p.length;i+=4){if(p[i+3]<10)continue;let [h,s,l]=hslOf(p[i]/255,p[i+1]/255,p[i+2]/255);if(s<.12)continue;const [rr,gg,bb]=rgbOf(hue,Math.min(1,s*.85),Math.min(1,l*(theme==='sky'?1.05:.95)));p[i]=rr*255|0;p[i+1]=gg*255|0;p[i+2]=bb*255|0}g.putImageData(d,r[0],r[1])}
  IMG[key]=c;return key}
{const _gm8=goMap;goMap=function(){const r=_gm8.apply(this,arguments);try{if(M&&M.objs){const th=M.theme||(/^dream/.test(M.id)?'dream':'cave');for(const o of M.objs)if(o.img==='dprops'&&DECO_KEYS.includes(o.dk))o.img=decoAtlas(th)}}catch(e){}return r}}
// 3) Thai lanterns (LA family 30%): Lanna lantern strings between lamp posts · Yi Peng sky lanterns at dusk/night · krathongs on the lake
let YIPENG=[],KRATHONG=[];
function lannaPairs(){if(M._lanna)return M._lanna;const L=(M.objs||[]).filter(o=>o.lamp);const pairs=[];for(const a of L){let best=null,bd=1e9;for(const b of L){if(a===b)continue;const d=Math.hypot(a.x-b.x,a.y-b.y);if(d<bd&&d<300){bd=d;best=b}}if(best&&!pairs.some(p=>(p[0]===best&&p[1]===a)))pairs.push([a,best])}return M._lanna=pairs}
function duskish(){try{const p=dayPhase();return p==='dusk'||p==='night'}catch(e){return false}}
{const _dv4=drawVFX2;drawVFX2=function(tm){_dv4.apply(this,arguments);try{if(!M||M.kind!=='town')return;const glow=duskish();
  for(const [a,b] of lannaPairs()){const x1=a.x+22-camX,y1=a.y-58-camY,x2=b.x+22-camX,y2=b.y-58-camY;if(Math.max(x1,x2)<-20||Math.min(x1,x2)>VW+20)continue;const mx=(x1+x2)/2,my=(y1+y2)/2+22;
    ctx.strokeStyle='rgba(58,30,63,.8)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x1,y1);ctx.quadraticCurveTo(mx,my,x2,y2);ctx.stroke();
    for(let i=1;i<=5;i++){const tt=i/6,x=(1-tt)*(1-tt)*x1+2*(1-tt)*tt*mx+tt*tt*x2,y=(1-tt)*(1-tt)*y1+2*(1-tt)*tt*my+tt*tt*y2+Math.sin(tm*2+i)*1.2;
      if(glow){ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,170,90,.28)';ctx.beginPath();ctx.arc(x,y+5,8,0,6.283);ctx.fill();ctx.restore()}
      ctx.fillStyle=i%2?'#d9483b':'#f29a38';ctx.beginPath();ctx.ellipse(x,y+5,4,5,0,0,6.283);ctx.fill();ctx.fillStyle='#3a1e3f';ctx.fillRect(x-3,y,6,1);ctx.fillRect(x-3,y+9,6,1);ctx.fillStyle='#ffc857';ctx.fillRect(x,y+10,1,3)}}
  if(glow){if(YIPENG.length<8&&Math.random()<.02)YIPENG.push({x:camX+Math.random()*VW,y:camY+VH+20,s:.6+Math.random()*.6,ph:Math.random()*6});
    for(const L of YIPENG){L.y-=(8+6*L.s)*.016;L.ph+=.016;const x=L.x+Math.sin(L.ph*.8)*10-camX,y=L.y-camY,s=L.s;ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle='rgba(255,180,90,.3)';ctx.beginPath();ctx.arc(x,y,12*s,0,6.283);ctx.fill();ctx.restore();
      ctx.fillStyle='#f6a24a';ctx.beginPath();ctx.moveTo(x-5*s,y-7*s);ctx.lineTo(x+5*s,y-7*s);ctx.lineTo(x+4*s,y+5*s);ctx.lineTo(x-4*s,y+5*s);ctx.fill();ctx.fillStyle='#ffe08a';ctx.fillRect(x-2*s,y+2*s,4*s,2*s)}
    YIPENG=YIPENG.filter(L=>L.y>camY-60)}else YIPENG=[];
  if((M.id==='lake'||M.id==='beach')&&glow&&M.WATER&&M.WATER.size){if(!M._kr){const w=[...M.WATER].map(k=>k.split(',').map(Number)).filter(([x,y])=>x>1&&y>1&&x<M.w-2&&y<M.h-2);M._kr=[];for(let i=0;i<Math.min(6,w.length);i++){const [x,y]=w[Math.floor(Math.random()*w.length)];M._kr.push({x:x*T+16,y:y*T+16,vx:(Math.random()-.5)*6,ph:Math.random()*6})}}
    for(const k of M._kr){k.ph+=.016;const nx=k.x+k.vx*.016;if(M.WATER.has(Math.floor(nx/T)+','+Math.floor(k.y/T)))k.x=nx;else k.vx*=-1;const x=k.x-camX,y=k.y-camY+Math.sin(k.ph*1.5)*1;
      ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=`rgba(255,200,110,${.25+.1*Math.sin(k.ph*7)})`;ctx.beginPath();ctx.arc(x,y-4,10,0,6.283);ctx.fill();ctx.restore();
      ctx.fillStyle='#3f8a4a';ctx.beginPath();ctx.ellipse(x,y+2,8,3,0,0,6.283);ctx.fill();ctx.fillStyle='#f3a6c8';for(const dx of [-4,0,4]){ctx.beginPath();ctx.ellipse(x+dx,y-1,2.5,3.5,0,0,6.283);ctx.fill()}ctx.fillStyle='#fff3c4';ctx.fillRect(x,y-8,1,4);ctx.fillStyle='#ffd23f';ctx.fillRect(x,y-9,1,1)}}}catch(e){}}}
{const _gm9=goMap;goMap=function(){YIPENG=[];return _gm9.apply(this,arguments)}}
// 4) rounded Thai font for titles (falls back to the system font when offline)
(()=>{try{const l=document.createElement('link');l.rel='stylesheet';l.href='https://fonts.googleapis.com/css2?family=Itim&display=swap';document.head.append(l);const st=document.createElement('style');st.textContent="#modal h2,.modal h2,#goal,#dlgN,.card h1,.card h2{font-family:'Itim',system-ui,sans-serif}";document.head.append(st)}catch(e){}})();

// ================= bag slots, storage, and helpers (keeps saves small for future cloud saves) =================
// Bag (adults): 30 slots · +10 at class 5 · +10 at class 8 · +10 per upgrade (max 3) · Storage: 60 slots +20 per upgrade (max 3), only in towns/home
// Fish bucket 40 · cards 200 · kids' gear goes to the family gift box (40) as before
const FISH_MAX=40,CARD_MAX=200,UP_COST=[300,800,2000];
let bagMax=()=>30+(rank()>=5?10:0)+(rank()>=8?10:0)+10*(S.bagUp||0);
const storeMax=()=>60+20*(S.storeUp||0);
const isWorn=i=>i===S.eq||i===S.eqA||i===S.eqC;
function invRemove(i){const it=S.inv.splice(i,1)[0];for(const k of ['eq','eqA','eqC'])if(typeof S[k]==='number'&&S[k]>i)S[k]--;return it}
let FULL_T=0;
{const _pk=pickUp;pickUp=function(d){try{if(S&&!isKid()&&d&&d.k==='item'&&(S.inv||[]).length>=bagMax()){
    if(S.autoJunk&&d.item&&d.item.rar===0){d.taken=true;const v=SELL[0]||5;S.coins+=v;TXT.push({x:d.x,y:d.y-14,s:'+'+v+'🪙',c:'#ffe36b',t:0});return}
    if(performance.now()-FULL_T>3000){FULL_T=performance.now();say('🎒 '+t('bagFull')+' '+S.inv.length+'/'+bagMax());sfx('wrong')}return}
  if(S&&d&&d.k==='card'&&(S.cards||[]).length>=CARD_MAX){d.taken=true;S.coins+=10;say('🃏 '+t('cardFull'));return}}catch(e){}return _pk.apply(this,arguments)}}
{const _cf3=catchFish;catchFish=function(){if(S&&(S.fishBag||[]).length>=FISH_MAX){const r=_cf3.apply(this,arguments);S.fishBag.length=FISH_MAX;say('🪣 '+t('fishFull')+' '+FISH_MAX);return r}return _cf3.apply(this,arguments)}}
// storage screen
function openStore(){if(!S||isKid())return;if(M&&M.kind==='cave'){say('📦 '+t('storeTown'));return}S.store=S.store||[];
  const bag=S.inv.map((w,i)=>[w,i]).filter(([w,i])=>!isWorn(i));const row=(w,btn)=>`<div class="it pn" style="display:flex;gap:6px;align-items:center;width:100%"><span style="flex:1">${itemLine(w)}</span>${btn}</div>`;
  const bUp=(S.bagUp||0)<3?`<button id="upBag">🎒 +10 · ${UP_COST[S.bagUp||0]}🪙</button>`:'',sUp=(S.storeUp||0)<3?`<button id="upStore">📦 +20 · ${UP_COST[S.storeUp||0]}🪙</button>`:'';
  modal(`<h2>📦 ${t('storeT')}</h2><p class="note">🎒 ${S.inv.length}/${bagMax()} · 📦 ${S.store.length}/${storeMax()} · 🪙 ${S.coins}</p><p>${bUp} ${sUp}</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><div><h3>🎒 ${t('bagT')}</h3>${bag.map(([w,i])=>row(w,`<button data-dep="${i}" ${S.store.length>=storeMax()?'disabled':''}>${t('deposit')} →</button>`)).join('')||'<p class="note">—</p>'}</div>
    <div><h3>📦 ${t('storeT')}</h3>${S.store.map((w,j)=>row(w,`<button data-wd="${j}" ${S.inv.length>=bagMax()?'disabled':''}>← ${t('withdraw')}</button>`)).join('')||'<p class="note">—</p>'}</div></div>`);
  document.querySelectorAll('[data-dep]').forEach(b=>b.onclick=()=>{const i=+b.dataset.dep;if(isWorn(i)||S.store.length>=storeMax())return;S.store.push(invRemove(i));sfx('pick');save();openStore()});
  document.querySelectorAll('[data-wd]').forEach(b=>b.onclick=()=>{const j=+b.dataset.wd;if(S.inv.length>=bagMax())return;S.inv.push(S.store.splice(j,1)[0]);sfx('pick');save();openStore()});
  const ub=$('upBag');if(ub)ub.onclick=()=>{const c=UP_COST[S.bagUp||0];if(S.coins<c){say(t('noCoin'));return}S.coins-=c;S.bagUp=(S.bagUp||0)+1;sfx('lvl');save();hud();openStore()};
  const us=$('upStore');if(us)us.onclick=()=>{const c=UP_COST[S.storeUp||0];if(S.coins<c){say(t('noCoin'));return}S.coins-=c;S.storeUp=(S.storeUp||0)+1;sfx('lvl');save();hud();openStore()}}
// bag header: counter + storage + sort + sell all plain items
{const _ob3=openBag;openBag=function(){const r=_ob3.apply(this,arguments);try{if(!S||isKid())return r;const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(!h||$('bagBar'))return r;
  const d=document.createElement('div');d.id='bagBar';d.className='row2';d.style.cssText='margin:4px 0 8px;gap:6px;flex-wrap:wrap';const n=S.inv.length,mx=bagMax();
  d.innerHTML=`<b style="color:${n>=mx?'#ff8a7a':'#ffe7b0'}">🎒 ${n}/${mx}</b><button id="bbStore">📦 ${t('storeT')}</button><button id="bbSort">🔃 ${t('sortT')}</button><button id="bbJunk">💰 ${t('sellPlain')}</button>`;h.after(d);
  $('bbStore').onclick=openStore;
  $('bbSort').onclick=()=>{const worn={eq:S.inv[S.eq],eqA:S.inv[S.eqA],eqC:S.inv[S.eqC]};const ord={weapon:0,armor:1,acc:2};S.inv.sort((a,b)=>(ord[a.slot||'weapon']-ord[b.slot||'weapon'])||(b.rar-a.rar)||((b.atk||0)-(a.atk||0)));for(const k of ['eq','eqA','eqC'])if(worn[k])S[k]=S.inv.indexOf(worn[k]);sfx('pick');save();openBag()};
  $('bbJunk').onclick=()=>{let got=0,cnt=0;for(let i=S.inv.length-1;i>=0;i--){const w=S.inv[i];if(w.rar===0&&!isWorn(i)){got+=SELL[0]||5;cnt++;invRemove(i)}}if(!cnt){say(t('noPlain'));return}S.coins+=got;sfx('coin');say('💰 '+cnt+' · 🪙 +'+got);save();hud();openBag()}}catch(e){}return r}}
// auto helper option: sell plain items automatically when the bag is full
{const _oa=openAuto;openAuto=function(){const r=_oa.apply(this,arguments);try{const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('aJunk')){const p=document.createElement('div');p.className='pn';p.innerHTML=`<label><input type="checkbox" id="aJunk" ${S.autoJunk?'checked':''}> ${t('autoJunk')}</label>`;const go=$('aGo');(go?go.parentNode:h).before(p);$('aJunk').onchange=e=>{S.autoJunk=e.target.checked;save()}}}catch(e){}return r}}
// save size in the settings (parents can see if something grows too much)
function saveKB(){try{let n=0;for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);n+=(k.length+(localStorage.getItem(k)||'').length)*2}return Math.round(n/1024)}catch(e){return 0}}
{const _st2=openSettings;openSettings=function(){const r=_st2.apply(this,arguments);try{const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');if(h&&!$('svSize')){const kb=saveKB();const p=document.createElement('p');p.id='svSize';p.className='note';p.textContent='💾 '+t('saveSize')+' '+kb+' KB / 5000 KB'+(kb>1500?' · ⚠️ '+t('saveBig'):'');h.after(p)}}catch(e){}return r}}

// ================= Diablo-style grid bag: items take cells by shape, drag to arrange / equip / store / sell =================
// Bag grid 10 columns × 4 rows (+1 row at class 5, +1 at class 8, +1 per upgrade ×3) · storage 10 × 6 (+2 rows per upgrade ×3)
// Equipped items leave the grid (like Diablo). Tap an item to see it; drag it to move.
const GCOLS=10;const bagRows=()=>4+(rank()>=5?1:0)+(rank()>=8?1:0)+(S.bagUp||0);const storeRows=()=>6+2*(S.storeUp||0);
const ISIZE=w=>w.slot==='armor'?[2,3]:w.slot==='acc'?[1,1]:({sw:[1,3],dag:[1,2],bow:[2,3],staff:[1,4]}[w.type]||[1,2]);
const RBG=['#3d3650','#23407a','#6a5a14','#7a4a14','#1e5a2a'],RBD=['#8a84a0','#7fb6ff','#ffe36b','#ffb347','#7df28a'];
const gbIcon=w=>w.slot==='armor'?'🛡️':w.slot==='acc'?'💍':(WEP[w.type]&&WEP[w.type].icon)||'🗡️';
function gridOcc(list,rows,skip){const occ=Array.from({length:rows},()=>Array(GCOLS).fill(-1));list.forEach((w,i)=>{if(i===skip||!w||w.gx==null)return;const [sw,sh]=ISIZE(w);for(let y=w.gy;y<w.gy+sh&&y<rows;y++)for(let x=w.gx;x<w.gx+sw&&x<GCOLS;x++)if(y>=0&&x>=0)occ[y][x]=i});return occ}
function fits(list,rows,w,gx,gy,skip){const [sw,sh]=ISIZE(w);if(gx<0||gy<0||gx+sw>GCOLS||gy+sh>rows)return false;const occ=gridOcc(list,rows,skip);for(let y=gy;y<gy+sh;y++)for(let x=gx;x<gx+sw;x++)if(occ[y][x]!==-1)return false;return true}
function firstFit(list,rows,w,skip){for(let x=0;x<GCOLS;x++)for(let y=0;y<rows;y++)if(fits(list,rows,w,x,y,skip))return[x,y];return null}
function bagList(){return S.inv.map((w,i)=>isWorn(i)?null:w)} // worn items are not on the grid
function gridFix(){if(!S||isKid())return;S.store=S.store||[];const L=S.inv;L.forEach((w,i)=>{if(isWorn(i)){w.gx=w.gy=null;return}if(w.gx!=null&&fits(bagList(),bagRows(),w,w.gx,w.gy,i))return;w.gx=null;const p=firstFit(bagList(),bagRows(),w,i);if(p){w.gx=p[0];w.gy=p[1]}});
  // items that do not fit anywhere go to storage (never deleted)
  for(let i=L.length-1;i>=0;i--){const w=L[i];if(isWorn(i)||w.gx!=null)continue;const it=invRemove(i);it.gx=null;const p=firstFit(S.store,storeRows(),it);if(p){it.gx=p[0];it.gy=p[1]}S.store.push(it)}
  S.store.forEach((w,i)=>{if(w.gx!=null&&fits(S.store,storeRows(),w,w.gx,w.gy,i))return;w.gx=null;const p=firstFit(S.store,storeRows(),w,i);if(p){w.gx=p[0];w.gy=p[1]}})}
// pickups: full when the new item fits nowhere (replaces the plain slot count)
{const _pk2=pickUp;pickUp=function(d){try{if(S&&!isKid()&&d&&d.k==='item'&&d.item){gridFix();const p=firstFit(bagList(),bagRows(),d.item);if(!p){if(S.autoJunk&&d.item.rar===0){d.taken=true;S.coins+=SELL[0];return}if(performance.now()-FULL_T>3000){FULL_T=performance.now();say('🎒 '+t('bagFull'));sfx('wrong')}return}
    const r=_pk2.call(this,d);const it=S.inv[S.inv.length-1];if(it===d.item){it.gx=p[0];it.gy=p[1]}return r}}catch(e){}return _pk2.apply(this,arguments)}}
bagMax=()=>9999; // the grid decides now (kept for older code paths)
let GB={sel:null,store:false};
function openGridBag(){if(!S)return;gridFix();const inTown=M&&M.kind!=='cave';GB.store=GB.store&&inTown;const avail=GB.cw||Math.min(innerWidth*.8,900)-40;const C=Math.max(18,Math.min(32,Math.floor((avail-30)/(GB.store?22:12)),Math.floor((innerHeight*.9-190)/Math.max(bagRows(),GB.store?storeRows():0))));
  const cellsHTML=(list,rows,name)=>{let h=`<div class="gbGrid" data-grid="${name}" style="position:relative;width:${GCOLS*C}px;height:${rows*C}px;background-image:linear-gradient(#3a2e52 1px,transparent 1px),linear-gradient(90deg,#3a2e52 1px,transparent 1px);background-size:${C}px ${C}px;background-color:#1b1330;border:2px solid #6b5d82;border-radius:6px;touch-action:none">`;
    list.forEach((w,i)=>{if(!w||w.gx==null)return;const [sw,sh]=ISIZE(w);h+=`<div class="gbIt" data-src="${name}" data-i="${i}" style="position:absolute;left:${w.gx*C+1}px;top:${w.gy*C+1}px;width:${sw*C-2}px;height:${sh*C-2}px;background:${RBG[w.rar]};border:2px solid ${RBD[w.rar]};border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:${Math.round(C*.7)}px;${GB.sel&&GB.sel.src===name&&GB.sel.i===i?'box-shadow:0 0 0 2px #fff':''}">${gbIcon(w)}</div>`});return h+'</div>'};
  const eqBox=(k,label,idx)=>{const w=typeof idx==='number'?S.inv[idx]:null;return `<div class="gbEq" data-eqslot="${k}" style="width:${2*C}px;height:${(k==='acc'?1.4:2.4)*C}px;border:2px dashed #b48cff;border-radius:6px;display:flex;flex-direction:column;align-items:center;justify-content:center;background:${w?RBG[w.rar]:'#241b38'}"><span style="font-size:${Math.round(C*.8)}px">${w?gbIcon(w):''}</span><small style="font-size:10px;color:#cbbfe6">${label}</small></div>`};
  const sel=GB.sel?(GB.sel.src==='bag'?S.inv[GB.sel.i]:S.store[GB.sel.i]):null;
  modal(`<h2 style="margin:0 0 6px">🎒 ${t('bagT')}</h2><div style="display:flex;gap:8px;align-items:flex-start;flex-wrap:nowrap">
    <div style="display:flex;flex-direction:column;gap:6px;align-items:center">${eqBox('weapon',t('weaponT'),S.eq)}${eqBox('armor',t('armor'),S.eqA)}${eqBox('acc',t('acc'),S.eqC)}<div data-sellzone="1" style="width:${2*C}px;height:${1.3*C}px;border:2px dashed #ffc857;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:12px;color:#ffe7b0">💰 ${t('sell')}</div></div>
    <div>${cellsHTML(bagList(),bagRows(),'bag')}<div class="row2" style="gap:6px;margin-top:6px;flex-wrap:wrap"><button id="gbSort">🔃 ${t('sortT')}</button><button id="gbJunk">💰 ${t('sellPlain')}</button>${inTown?`<button id="gbStore">📦 ${GB.store?t('closeStore'):t('storeT')}</button>`:''}<button id="gbOld">📜 ${t('gbOld')}</button></div></div>
    ${GB.store?`<div><small class="note">📦 ${t('storeT')}</small>${cellsHTML(S.store,storeRows(),'store')}</div>`:''}</div>
    <div class="pn" id="gbInfo" style="margin-top:6px;min-height:34px;font-size:12px">${sel?itemLine(sel)+(GB.sel.src==='bag'?`<div class="row2" style="gap:6px;margin-top:4px"><button id="gbEqB">${t('equip')}</button><button id="gbSellB">${t('sell')} +${SELL[sel.rar]}🪙</button></div>`:''):`<small class="note">${t('gbHelp')}</small>`}</div>`);
  gbWire(C);try{const g=document.querySelector('[data-grid="bag"]');const box=g&&g.parentNode&&g.parentNode.parentNode;const cw=box?box.clientWidth:0;if(cw&&Math.abs(cw-(GB.cw||0))>8&&!GB.measuring){GB.cw=cw;GB.measuring=true;openGridBag();GB.measuring=false}}catch(e){}}
function gbSell(i){if(isWorn(i))return;const w=S.inv[i];S.coins+=SELL[w.rar];invRemove(i);GB.sel=null;sfx('coin');say(t('sold')+' +'+SELL[w.rar]+'🪙');save();hud()}
function gbEquip(i){const w=S.inv[i];if(!w)return;const k=w.slot==='armor'?'eqA':w.slot==='acc'?'eqC':'eq';const old=S[k];const from=[w.gx,w.gy];w.gx=w.gy=null;S[k]=i;
  if(typeof old==='number'&&S.inv[old]&&old!==i){const o=S.inv[old];if(fits(bagList(),bagRows(),o,from[0],from[1],old)){o.gx=from[0];o.gy=from[1]}else{const p=firstFit(bagList(),bagRows(),o,old);if(!p){S[k]=old;w.gx=from[0];w.gy=from[1];say('🎒 '+t('bagFull'));return}o.gx=p[0];o.gy=p[1]}}
  sfx('pick');GB.sel=null;save();hud();try{if(typeof refreshSheet==='function')refreshSheet()}catch(e){}}
function gbWire(C){const q=s=>document.querySelector(s);const b=id=>document.getElementById(id);
  b('gbSort').onclick=()=>{const L=bagList();const items=L.map((w,i)=>[w,i]).filter(([w])=>w).sort((a,b2)=>{const A=ISIZE(a[0]),B=ISIZE(b2[0]);return (B[0]*B[1])-(A[0]*A[1])||b2[0].rar-a[0].rar});items.forEach(([w])=>w.gx=null);for(const [w,i] of items){const p=firstFit(bagList(),bagRows(),w,i);if(p){w.gx=p[0];w.gy=p[1]}}sfx('pick');save();openGridBag()};
  b('gbJunk').onclick=()=>{let n=0,got=0;for(let i=S.inv.length-1;i>=0;i--){const w=S.inv[i];if(w.rar===0&&!isWorn(i)){got+=SELL[0];n++;invRemove(i)}}if(!n){say(t('noPlain'));return}S.coins+=got;sfx('coin');say('💰 '+n+' · 🪙 +'+got);GB.sel=null;save();hud();openGridBag()};
  if(b('gbStore'))b('gbStore').onclick=()=>{GB.store=!GB.store;openGridBag()};
  b('gbOld').onclick=()=>{GB.old=true;closeModal();openBag();GB.old=false};
  if(b('gbEqB'))b('gbEqB').onclick=()=>{gbEquip(GB.sel.i);openGridBag()};if(b('gbSellB'))b('gbSellB').onclick=()=>{gbSell(GB.sel.i);openGridBag()};
  document.querySelectorAll('.gbIt').forEach(el=>{el.onpointerdown=e=>{e.preventDefault();const src=el.dataset.src,i=+el.dataset.i,r=el.getBoundingClientRect(),ox=e.clientX-r.left,oy=e.clientY-r.top,sx=e.clientX,sy=e.clientY;let moved=false;
    const gh=el.cloneNode(true);gh.style.position='fixed';gh.style.left=r.left+'px';gh.style.top=r.top+'px';gh.style.pointerEvents='none';gh.style.zIndex=99;gh.style.opacity=.85;document.body.append(gh);el.style.opacity=.3;
    const mv=ev=>{if(Math.hypot(ev.clientX-sx,ev.clientY-sy)>6)moved=true;gh.style.left=(ev.clientX-ox)+'px';gh.style.top=(ev.clientY-oy)+'px'};
    const up=ev=>{removeEventListener('pointermove',mv);removeEventListener('pointerup',up);gh.remove();el.style.opacity=1;
      if(!moved){GB.sel={src,i};openGridBag();return}
      const tgt=document.elementFromPoint(ev.clientX,ev.clientY);const list=src==='bag'?S.inv:S.store,w=list[i];let done=false;
      const grid=tgt&&tgt.closest&&tgt.closest('[data-grid]'),eq=tgt&&tgt.closest&&tgt.closest('[data-eqslot]'),sz=tgt&&tgt.closest&&tgt.closest('[data-sellzone]');
      if(grid){const gr=grid.getBoundingClientRect(),gx=Math.round((ev.clientX-ox-gr.left)/C),gy=Math.round((ev.clientY-oy-gr.top)/C),to=grid.dataset.grid;
        if(to===src){const L=src==='bag'?bagList():S.store,rows=src==='bag'?bagRows():storeRows();if(fits(L,rows,w,gx,gy,i)){w.gx=gx;w.gy=gy;done=true}}
        else if(to==='store'&&src==='bag'&&!isWorn(i)){if(fits(S.store,storeRows(),w,gx,gy)){const it=invRemove(i);it.gx=gx;it.gy=gy;S.store.push(it);done=true}}
        else if(to==='bag'&&src==='store'){if(fits(bagList(),bagRows(),w,gx,gy)){const it=S.store.splice(i,1)[0];it.gx=gx;it.gy=gy;S.inv.push(it);done=true}}}
      else if(eq&&src==='bag'){const k=eq.dataset.eqslot,ok=(k==='armor'&&w.slot==='armor')||(k==='acc'&&w.slot==='acc')||(k==='weapon'&&!w.slot);if(ok){gbEquip(i);done=true}else say('❌ '+t('gbWrongSlot'))}
      else if(sz&&src==='bag'){gbSell(i);done=true}
      if(done){GB.sel=null;sfx('pick');save()}else sfx('wrong');openGridBag()};
    addEventListener('pointermove',mv);addEventListener('pointerup',up)}})
  // drag an equipped item back into the bag = unequip is not allowed (a weapon must stay in hand); tap an equip box to see it
  document.querySelectorAll('[data-eqslot]').forEach(el=>el.onclick=()=>{const k={weapon:'eq',armor:'eqA',acc:'eqC'}[el.dataset.eqslot];const i=S[k];if(typeof i==='number'&&S.inv[i]){$('gbInfo').innerHTML=itemLine(S.inv[i])+`<br><small class="note">${t('equipped')}</small>`}})}
{const _ob4=openBag;openBag=function(){if(S&&!isKid()&&!GB.old){try{return openGridBag()}catch(e){}}return _ob4.apply(this,arguments)}}
{const _os5=openStore;openStore=function(){if(S&&!isKid()){if(M&&M.kind==='cave'){say('📦 '+t('storeTown'));return}GB.store=true;return openGridBag()}return _os5.apply(this,arguments)}}
{const _sg3=startGame;startGame=function(){const r=_sg3.apply(this,arguments);try{gridFix();save()}catch(e){}return r}}

// ================= Peb, redrawn in code to match the mascot (purple fluff, long ears, big eyes, a tiny spark inside) =================
// 8 directions × 64px like the old sheet, so every place that draws Peb keeps working. The old green crystal toad is kept as IMG.npc_peb_old.
function makePebSheet(){const S2=32,out=document.createElement('canvas');out.width=512;out.height=64;const og=out.getContext('2d');og.imageSmoothingEnabled=false;
  const C={body:'#9b6fd6',shade:'#7a4fb8',hi:'#c9a8f0',ear:'#f3a6c8',eye:'#2a1733',cheek:'#f28cb8',spark:'#ffe08a',line:'#3a1e3f'};
  for(let d=0;d<8;d++){const a=DIR_ANG[d],fx=Math.cos(a),fy=Math.sin(a),back=fy<-.3;const c=document.createElement('canvas');c.width=S2;c.height=S2;const g=c.getContext('2d');
    const cx=16,cy=21,circ=(x,y,r,col)=>{g.fillStyle=col;g.beginPath();g.arc(x,y,r,0,6.283);g.fill()};
    // ears (behind the body) tilt a little toward the facing side
    for(const s of [-1,1]){g.save();g.translate(cx+s*4+fx*1.5,cy-8);g.rotate(s*.25+fx*.15);g.fillStyle=C.shade;g.beginPath();g.ellipse(0,-5,2.6,6.5,0,0,6.283);g.fill();if(!back){g.fillStyle=C.ear;g.beginPath();g.ellipse(0,-4.5,1.2,4.5,0,0,6.283);g.fill()}g.restore()}
    // fluffy body: a ring of small puffs + a big middle
    for(let i=0;i<10;i++){const t2=i/10*6.283;circ(cx+Math.cos(t2)*8.2,cy+Math.sin(t2)*7,3.2,C.shade)}circ(cx,cy,8.4,C.body);circ(cx-3-fx,cy-3,3.4,C.hi);
    // feet
    g.fillStyle=C.shade;g.fillRect(cx-6,cy+7,4,2);g.fillRect(cx+2,cy+7,4,2);
    if(back){circ(cx,cy+4,2.2,C.hi)}else{
      const ex=fx*3.2,side=Math.abs(fx)>.9;const eye=(x)=>{circ(x,cy-1,2.1,C.eye);g.fillStyle='#fff';g.fillRect(Math.round(x-1),Math.round(cy-2),1,1)};
      if(side){eye(cx+ex+fx*1)}else{eye(cx-3.2+ex);eye(cx+3.2+ex)}
      g.fillStyle=C.cheek;if(!side||fx<0)g.fillRect(Math.round(cx-6+ex),cy+2,2,1);if(!side||fx>0)g.fillRect(Math.round(cx+4+ex),cy+2,2,1);
      g.fillStyle=C.eye;g.fillRect(Math.round(cx-1+ex),cy+3,2,1);circ(cx+ex*.6,cy+5,1.1,C.spark)}
    // crisp pixels + plum outline
    const im=g.getImageData(0,0,S2,S2),p=im.data;for(let i=3;i<p.length;i+=4)p[i]=p[i]>110?255:0;
    const src=new Uint8ClampedArray(p);for(let y=0;y<S2;y++)for(let x=0;x<S2;x++){const i=(y*S2+x)*4;if(src[i+3])continue;const nb=[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>{const X=x+dx,Y=y+dy;return X>=0&&Y>=0&&X<S2&&Y<S2&&src[(Y*S2+X)*4+3]});if(nb){p[i]=58;p[i+1]=30;p[i+2]=63;p[i+3]=255}}
    g.putImageData(im,0,0);og.drawImage(c,0,0,S2,S2,d*64,0,64,64)}
  return out}
function installPeb(){try{if(IMG.npc_peb&&!IMG.npc_peb_old)IMG.npc_peb_old=IMG.npc_peb;IMG.npc_peb=makePebSheet();PLUMMED.add('npc_peb')}catch(e){}}
{const _st3=showTitle;showTitle=function(){installPeb();return _st3.apply(this,arguments)}}
{const _sg4=startGame;startGame=function(){if(!IMG.npc_peb_old)installPeb();return _sg4.apply(this,arguments)}}

// ================= play helpers: loot filter · walk to the goal · follow a family member =================
// loot filter (grown-ups): pick up everything / magic and better / rare and better; coins, potions and gems are always picked up
{const _pk3=pickUp;pickUp=function(d){try{if(S&&!isKid()&&d&&d.k==='item'&&d.item&&d.item.rar<(S.lootMin||0))return}catch(e){}return _pk3.apply(this,arguments)}}
{const _st4=openSettings;openSettings=function(){const r=_st4.apply(this,arguments);try{if(S&&!isKid()&&!$('lootMin')){const h=document.querySelector('#modal h2')||document.querySelector('.modal h2');const d=document.createElement('div');d.className='row2';d.style.margin='6px 0';
    d.innerHTML=`<span>🧲 ${t('lootT')}</span><select id="lootMin"><option value="0">${t('loot0')}</option><option value="1">${t('loot1')}</option><option value="2">${t('loot2')}</option></select>`;h.after(d);$('lootMin').value=String(S.lootMin||0);$('lootMin').onchange=e=>{S.lootMin=+e.target.value;save()}}}catch(e){}return r}}
// tap the goal line: walk to where the arrow points (kids love this); the class panel stays in the bag/stats
let FOLLOW=null,FOLLOW_T=0;
function walkToGoal(){try{const g=guideTarget();if(!g){openRank();return}const p=findPath(M,P.x,P.y,g.x,g.y+8);if(p&&p.length){P.path=p;P.target=null;FOLLOW=null;say('🚶 '+t('walkGoal'))}else openRank()}catch(e){}}
// replace the old goal click (it opened the class panel) with a small choice: walk there
addEventListener('click',e=>{try{if(e.target&&e.target.id==='goal'&&S){e.stopImmediatePropagation();walkToGoal()}}catch(err){}},true);
// follow: pick the nearest family member online in the same map; stops when you move yourself
function followFamily(){const others=(Net&&Net.inMap)?Net.inMap():[];if(!others.length){say('👨‍👩‍👧 '+t('followNone'));return}
  const [id,o]=others.sort((a,b)=>Math.hypot(a[1].p.x-P.x,a[1].p.y-P.y)-Math.hypot(b[1].p.x-P.x,b[1].p.y-P.y))[0];FOLLOW=id;say('👣 '+t('followOn')+' '+(o.p.n||''))}
{const _up12=update;update=function(dt){const r=_up12.apply(this,arguments);try{if(FOLLOW&&!PAUSE){const o=(Net.others||{})[FOLLOW];if(!o||!o.p||!Net.inMap().some(([id])=>id===FOLLOW)){FOLLOW=null;return r}
    const mx=(keys.ArrowLeft||keys.a||keys.ArrowRight||keys.d||keys.ArrowUp||keys.w||keys.ArrowDown||keys.s)||(JOY.id!==null&&JOY.id!=='pad'&&Math.hypot(JOY.x,JOY.y)>.3);if(mx){FOLLOW=null;say('👣 '+t('followOff'));return r}
    FOLLOW_T-=dt;if(FOLLOW_T<=0){FOLLOW_T=.5;const d=Math.hypot(o.p.x-P.x,o.p.y-P.y);if(d>56){const p=findPath(M,P.x,P.y,o.p.x,o.p.y);if(p){P.path=p;P.target=null}}}}}catch(e){}return r}}
{const _ac2=addCtlButtons;addCtlButtons=function(){_ac2();const sk=$('bSk');if(!sk||$('bFollow'))return;const b=sk.cloneNode(true);b.id='bFollow';b.innerHTML=`👣<small>${t('followBtn')}</small>`;b.onclick=()=>{if(FOLLOW){FOLLOW=null;say('👣 '+t('followOff'))}else followFamily()};sk.parentNode.insertBefore(b,sk)}}
{const _cv2=ctlVis;ctlVis=function(){_cv2();const b=$('bFollow');if(b)b.style.display=S&&Net&&Net.online&&Net.inMap&&Net.inMap().length?'':'none';if(b)b.style.outline=FOLLOW?'2px solid #7fffa0':''}}

// ================= zone monsters (60% identity): one signature creature per land, drawn in code like the originals =================
// forest: glow moth (flies) · desert: sand scarab (tough) · underground lake: coral crab (shielded) · sky: cloud puff (flies)
Object.assign(MON_STAT,{moth:{hp:14,atk:5,spd:42,exp:8,fly:1},scarab:{hp:34,atk:8,spd:20,exp:13},crab:{hp:30,atk:9,spd:22,exp:13},puff:{hp:20,atk:6,spd:34,exp:10,fly:1}});
Object.assign(WEAK,{moth:['fire','bow'],scarab:['ice','staff'],crab:['bolt','sw'],puff:['bolt','bow']});
const MON_BASE={moth:'bat',scarab:'mushbug',crab:'mushbug',puff:'slime'}; // cards and pets reuse the base kind
function zoneMonArt(){if(MON_ART.moth0)return;const E=(g,x,y,h,s)=>{try{eyes(g,x,y,h,s)}catch(e){}};
  for(const happy of [0,1]){
    MON_ART['moth'+happy]=[0,1].map(f=>pix(30,22,g=>{const [w1,w2,b]=happy?['#bff5d8','#f4b8e8','#7a5aa0']:['#8fa39a','#9a8aa6','#4e4660'];g.fillStyle=w1;if(f){g.fillRect(2,3,10,8);g.fillRect(18,3,10,8)}else{g.fillRect(2,8,10,7);g.fillRect(18,8,10,7)}g.fillStyle=w2;if(f){g.fillRect(4,10,7,5);g.fillRect(19,10,7,5)}else{g.fillRect(4,14,7,4);g.fillRect(19,14,7,4)}
      g.fillStyle=b;g.fillRect(12,6,6,13);g.fillRect(11,3,1,4);g.fillRect(18,3,1,4);g.fillStyle=happy?'#fff6c8':'#c8c0a0';g.fillRect(13,17,4,2);E(g,12,9,happy,.55)}));
    MON_ART['scarab'+happy]=[0,1].map(f=>pix(28,22,g=>{const [c,d]=happy?['#ffd24a','#c8912e']:['#b8985a','#7a6340'];g.fillStyle='#3a2410';for(let i=0;i<3;i++){g.fillRect(3,9+i*4+((i+f)%2),4,2);g.fillRect(21,9+i*4+((i+1+f)%2),4,2)}
      g.fillStyle=d;g.fillRect(6,6,16,14);g.fillStyle=c;g.fillRect(7,7,14,11);g.fillStyle=d;g.fillRect(13,7,2,11);g.fillStyle='#3a2410';g.fillRect(9,3,10,4);g.fillStyle=happy?'#fff3b0':'#e6d6a0';g.fillRect(9,9,3,2);E(g,9,4,happy,.5)}));
    MON_ART['crab'+happy]=[0,1].map(f=>pix(30,22,g=>{const [c,d]=happy?['#ff9a8a','#e0645a']:['#a8706a','#7a4a46'];g.fillStyle=d;g.fillRect(1,5-f,7,6);g.fillRect(22,5-f,7,6);g.fillStyle=c;g.fillRect(2,6-f,5,4);g.fillRect(23,6-f,5,4);
      g.fillStyle=d;for(let i=0;i<3;i++){g.fillRect(4+i*3,17+((i+f)%2),2,4);g.fillRect(20+i*3,17+((i+1+f)%2),2,4)}g.fillRect(6,9,18,10);g.fillStyle=c;g.fillRect(7,10,16,8);g.fillStyle='#fff';g.fillRect(10,4,2,6);g.fillRect(18,4,2,6);E(g,9,3,happy,.5)}));
    MON_ART['puff'+happy]=[0,1].map(f=>pix(28,22,g=>{const [c,d]=happy?['#ffffff','#d8d0f4']:['#b8b8c8','#8e8ca6'];g.fillStyle=d;g.fillRect(3,9+f,22,10);g.fillRect(6,5+f,8,6);g.fillRect(13,4+f,9,7);g.fillStyle=c;g.fillRect(4,10+f,20,8);g.fillRect(7,6+f,6,5);g.fillRect(14,5+f,7,6);g.fillStyle=happy?'#f3a6c8':'#a8a0b8';g.fillRect(6,15+f,2,1);g.fillRect(20,15+f,2,1);E(g,8,11+f,happy,.6)}))}
  for(const k of ['moth','scarab','crab','puff'])for(const h of [0,1])MON_ART[k+h]=MON_ART[k+h].map(fr=>typeof plumCanvas==='function'?plumCanvas(fr):fr)}
{const _mk=mkMon;mkMon=function(kind){if(MON_BASE[kind])zoneMonArt();return _mk.apply(this,arguments)}}
// cards / pets: use the base kind so every existing card effect still works
{const _dr=drop;drop=function(mo){const b=mo&&MON_BASE[mo.kind];if(!b)return _dr.apply(this,arguments);const k=mo.kind;mo.kind=b;try{return _dr.apply(this,arguments)}finally{mo.kind=k}}}
{const _tp=tryPet;tryPet=function(kind){return _tp.call(this,MON_BASE[kind]||kind)}}
// signature monsters keep their own colours (no land tint)
{const _dm4=drawMon;drawMon=function(m,tm){if(MON_BASE[m.kind]&&M&&M.theme){const th=M.theme;M.theme=null;try{return _dm4.apply(this,arguments)}finally{M.theme=th}}return _dm4.apply(this,arguments)}}
// land rosters: each land swaps one monster for its signature creature
{const SIG={forest:['bat','moth'],desert:['mushbug','scarab'],ulake:['mushbug','crab'],sky:['slime','puff']};for(const [id,C] of Object.entries(CAVE_CFG)){if(!C.theme||!SIG[C.theme]||!C.mons)continue;const [from,to]=SIG[C.theme];C.mons=C.mons.map(([k,n])=>[k===from?to:k,n])}}

// ================= pixel icons for the HUD (replace OS emoji so every phone shows the same LA look) =================
const ICO={};
function icoMake(draw){const S2=16,c=document.createElement('canvas');c.width=S2;c.height=S2;const g=c.getContext('2d');draw(g);const im=g.getImageData(0,0,S2,S2),p=im.data;for(let i=3;i<p.length;i+=4)p[i]=p[i]>100?255:0;
  const src=new Uint8ClampedArray(p);for(let y=0;y<S2;y++)for(let x=0;x<S2;x++){const i=(y*S2+x)*4;if(src[i+3])continue;if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>{const X=x+dx,Y=y+dy;return X>=0&&Y>=0&&X<S2&&Y<S2&&src[(Y*S2+X)*4+3]})){p[i]=58;p[i+1]=30;p[i+2]=63;p[i+3]=255}}
  g.putImageData(im,0,0);const o=document.createElement('canvas');o.width=o.height=32;const og=o.getContext('2d');og.imageSmoothingEnabled=false;og.drawImage(c,0,0,32,32);return o.toDataURL()}
const IC_GD='#ffc857',IC_GDD='#c8912e',IC_CR='#f3e3c3',IC_CY='#7fe0ff',IC_PU='#9b6fd6',IC_RD='#e0573c',IC_GR='#6fbf5a',IC_BR='#8a5a3c';
const ICON_DRAW={
  bBag:g=>{g.fillStyle=IC_BR;g.fillRect(3,5,10,9);g.fillStyle=IC_GDD;g.fillRect(3,5,10,3);g.fillStyle=IC_GD;g.fillRect(7,7,2,2);g.fillStyle=IC_BR;g.fillRect(6,2,4,1);g.fillRect(5,3,1,2);g.fillRect(10,3,1,2)},
  bMap:g=>{g.fillStyle=IC_CR;g.fillRect(2,3,12,10);g.fillStyle='#d9c79e';g.fillRect(6,3,1,10);g.fillRect(10,3,1,10);g.fillStyle=IC_RD;g.fillRect(11,6,2,1);g.fillRect(12,5,1,3);g.fillStyle=IC_CY;g.fillRect(3,9,2,1);g.fillRect(5,8,2,1);g.fillRect(7,9,2,1)},
  bEmo:g=>{g.fillStyle=IC_GD;g.beginPath();g.arc(8,8,6,0,6.283);g.fill();g.fillStyle='#3a1e3f';g.fillRect(5,6,2,2);g.fillRect(9,6,2,2);g.fillRect(5,10,6,1);g.fillRect(4,9,1,1);g.fillRect(11,9,1,1)},
  bStat:g=>{g.fillStyle=IC_CY;g.fillRect(3,9,3,5);g.fillStyle=IC_GD;g.fillRect(7,5,3,9);g.fillStyle=IC_RD;g.fillRect(11,2,3,12)},
  bBook:g=>{g.fillStyle=IC_PU;g.fillRect(2,4,12,9);g.fillStyle=IC_CR;g.fillRect(3,4,5,8);g.fillRect(8,4,5,8);g.fillStyle='#b9a98a';g.fillRect(4,6,3,1);g.fillRect(9,6,3,1);g.fillRect(4,8,3,1);g.fillRect(9,8,3,1)},
  bSet:g=>{g.fillStyle='#c9c3d8';g.beginPath();g.arc(8,8,5,0,6.283);g.fill();for(let i=0;i<8;i++){const a=i/8*6.283;g.fillRect(Math.round(8+Math.cos(a)*6)-1,Math.round(8+Math.sin(a)*6)-1,2,2)}g.fillStyle='#3a1e3f';g.fillRect(7,7,2,2)},
  bAtk:g=>{g.fillStyle='#dfe6f0';for(let i=0;i<8;i++)g.fillRect(3+i,11-i,2,2);g.fillStyle=IC_GD;g.fillRect(2,10,5,2);g.fillRect(4,8,2,5);g.fillStyle=IC_BR;g.fillRect(1,13,3,2)},
  bSk:g=>{g.fillStyle=IC_GD;g.beginPath();g.moveTo(8,1);g.lineTo(10,6);g.lineTo(15,8);g.lineTo(10,10);g.lineTo(8,15);g.lineTo(6,10);g.lineTo(1,8);g.lineTo(6,6);g.fill();g.fillStyle='#fff6c8';g.fillRect(7,7,2,2)},
  bCmp:g=>{g.fillStyle=IC_CR;g.beginPath();g.arc(8,8,6,0,6.283);g.fill();g.fillStyle=IC_RD;g.beginPath();g.moveTo(8,3);g.lineTo(10,8);g.lineTo(6,8);g.fill();g.fillStyle=IC_CY;g.beginPath();g.moveTo(8,13);g.lineTo(10,8);g.lineTo(6,8);g.fill()},
  bPot:g=>{g.fillStyle=IC_CR;g.fillRect(6,2,4,3);g.fillStyle='#e8d9f5';g.beginPath();g.arc(8,10,5,0,6.283);g.fill();g.fillStyle='#f06c9b';g.fillRect(4,10,9,4);g.fillStyle='#fff';g.fillRect(5,8,2,1)},
  bFish:g=>{g.fillStyle=IC_BR;for(let i=0;i<10;i++)g.fillRect(2+i,12-i,1,1);g.fillStyle=IC_CR;g.fillRect(12,2,1,8);g.fillStyle=IC_CY;g.fillRect(9,11,5,3);g.fillRect(8,12,1,1);g.fillRect(14,10,1,5)},
  bDash:g=>{g.fillStyle=IC_CY;g.fillRect(2,5,8,2);g.fillRect(4,9,9,2);g.fillRect(1,12,6,2);g.fillStyle='#fff';g.fillRect(10,5,3,2);g.fillRect(13,9,2,2)},
  bSit:g=>{g.fillStyle='#f3a6c8';g.beginPath();g.ellipse(8,11,6,3,0,0,6.283);g.fill();g.fillStyle='#f7c6dc';g.beginPath();g.ellipse(8,8,2.5,5,0,0,6.283);g.fill();g.beginPath();g.ellipse(4.5,9,2,4,-.6,0,6.283);g.fill();g.beginPath();g.ellipse(11.5,9,2,4,.6,0,6.283);g.fill()},
  bAuto:g=>{g.fillStyle='#c9c3d8';g.fillRect(3,5,10,8);g.fillStyle=IC_CY;g.fillRect(5,7,2,2);g.fillRect(9,7,2,2);g.fillStyle='#3a1e3f';g.fillRect(6,11,4,1);g.fillStyle=IC_GD;g.fillRect(7,2,2,3)},
  bFollow:g=>{g.fillStyle=IC_CR;g.beginPath();g.ellipse(5,10,2.2,3.2,0,0,6.283);g.fill();g.beginPath();g.ellipse(11,6,2.2,3.2,0,0,6.283);g.fill();g.fillRect(4,5,1,1);g.fillRect(6,5,1,1);g.fillRect(10,1,1,1);g.fillRect(12,1,1,1)},
  bPets:g=>{g.fillStyle=IC_PU;g.beginPath();g.arc(8,10,3.5,0,6.283);g.fill();for(const [x,y] of [[3,6],[6,3],[10,3],[13,6]]){g.beginPath();g.arc(x,y,1.8,0,6.283);g.fill()}},
  bWheel:g=>{g.fillStyle=IC_GD;g.beginPath();g.arc(8,8,6,0,6.283);g.fill();g.fillStyle=IC_RD;g.beginPath();g.moveTo(8,8);g.arc(8,8,6,0,1.57);g.fill();g.fillStyle=IC_CY;g.beginPath();g.moveTo(8,8);g.arc(8,8,6,3.14,4.71);g.fill();g.fillStyle='#3a1e3f';g.fillRect(7,7,2,2)}};
function iconize(){try{for(const [id,draw] of Object.entries(ICON_DRAW)){const b=$(id);if(!b)continue;if(!ICO[id])ICO[id]=icoMake(draw);const img=b.querySelector('img.pxi');if(img&&img.dataset.k===id)continue;
    const small=b.querySelector('small');const lab=small?small.outerHTML:'';const txt=b.textContent.replace(small?small.textContent:'','').trim();const count=(txt.match(/\d+/)||[''])[0];
    b.innerHTML=`<img class="pxi" data-k="${id}" src="${ICO[id]}" alt="">${count&&id==='bPot'?`<small>${count}</small>`:lab}`}}catch(e){}}
(()=>{const st=document.createElement('style');st.textContent='img.pxi{width:26px;height:26px;image-rendering:pixelated;display:block;margin:0 auto;pointer-events:none}';document.head.append(st)})();
{const _hud3=hud;hud=function(){const r=_hud3.apply(this,arguments);iconize();return r}}

// ================= land guardians with their own bodies (was the same stone golem ×5) + one landmark per land =================
function chunky(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');draw(g);const im=g.getImageData(0,0,w,h),p=im.data;for(let i=3;i<p.length;i+=4)p[i]=p[i]>110?255:0;
  const src=new Uint8ClampedArray(p);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(src[i+3])continue;if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>{const X=x+dx,Y=y+dy;return X>=0&&Y>=0&&X<w&&Y<h&&src[(Y*w+X)*4+3]})){p[i]=58;p[i+1]=30;p[i+2]=63;p[i+3]=255}}
  g.putImageData(im,0,0);const o=document.createElement('canvas');o.width=w*2;o.height=h*2;const og=o.getContext('2d');og.imageSmoothingEnabled=false;og.drawImage(c,0,0,w*2,h*2);return o}
const BOSS_ART={};
function bossArt(){if(BOSS_ART.mushking)return;const E=(g,x,y,sleepy,happy)=>{g.fillStyle='#2a1733';if(sleepy&&!happy){g.fillRect(x,y+1,4,1);g.fillRect(x+8,y+1,4,1)}else{g.fillRect(x,y,3,3);g.fillRect(x+8,y,3,3);g.fillStyle='#fff';g.fillRect(x,y,1,1);g.fillRect(x+8,y,1,1)}};
  const mk=(draw)=>[0,1].map(h=>[0,1].map(f=>chunky(36,36,g=>draw(g,h,f))));
  BOSS_ART.mushking=mk((g,h,f)=>{const cap=h?'#f06cb4':'#9a8aa6',sp=h?'#fff3fa':'#c8c0d0',st=h?'#fff0d8':'#cfc6b4';g.fillStyle=st;g.fillRect(12,18+f,12,14);g.fillRect(10,30,4,3);g.fillRect(22,30,4,3);
    g.fillStyle=cap;g.beginPath();g.ellipse(18,15+f,16,10,0,Math.PI,0);g.fill();g.fillRect(2,14+f,32,3);g.fillStyle=sp;for(const [x,y] of [[8,9],[16,6],[25,9],[12,12],[22,13]]){g.beginPath();g.arc(x,y+f,1.8,0,6.283);g.fill()}
    g.fillStyle='#ffc857';g.fillRect(14,2+f,8,3);g.fillRect(14,0+f,2,2);g.fillRect(17,0+f,2,2);g.fillRect(20,0+f,2,2);E(g,13,21+f,true,h);if(!h){g.fillStyle='#cfe6ff';g.fillRect(28,6-f,3,1);g.fillRect(30,4-f,2,1)}});
  BOSS_ART.sphinx=mk((g,h,f)=>{const b=h?'#f2c46a':'#b8a078',d=h?'#c8913e':'#8a7456';g.fillStyle=d;g.fillRect(4,22,28,10);g.fillRect(2,28,8,4);g.fillRect(26,28,8,4);g.fillStyle=b;g.fillRect(6,21,24,9);
    g.fillStyle=h?'#3fa7a0':'#6a8a88';g.fillRect(9,4+f,18,16);g.fillStyle=h?'#ffc857':'#b8a47a';for(let i=0;i<4;i++)g.fillRect(9,6+i*4+f,18,1);g.fillStyle=b;g.fillRect(12,8+f,12,12);E(g,13,12+f,false,h);g.fillStyle='#2a1733';g.fillRect(16,17+f,4,1);
    if(!h){g.fillStyle='#ffe7a0';g.fillRect(29,2,2,4);g.fillRect(31,2,2,2);g.fillRect(29,8,2,2)}});
  BOSS_ART.turtle=mk((g,h,f)=>{const sh=h?'#3fb5a8':'#6f8a86',pl=h?'#8ff0d8':'#9fb2ae',sk=h?'#a8e08a':'#8e9e86';g.fillStyle=sk;g.fillRect(2,20+f,7,6);g.fillRect(8,28,6,5);g.fillRect(24,28,6,5);
    g.fillStyle=sh;g.beginPath();g.ellipse(20,20,14,11,0,Math.PI,0);g.fill();g.fillRect(6,19,28,8);g.fillStyle=pl;for(const [x,y] of [[13,13],[20,10],[27,13],[16,19],[24,19]]){g.beginPath();g.arc(x,y,2.6,0,6.283);g.fill()}
    g.fillStyle=sk;g.fillRect(0,17+f,8,7);E(g,1,19+f,true,h);if(!h){g.fillStyle='#8f8ca6';g.fillRect(12,4,16,3);g.fillRect(10,6,20,2)}});
  BOSS_ART.mist=mk((g,h,f)=>{const c=h?['#ffb3d9','#ffe08a','#9fe0ff','#b8f5a8','#c9a8f0']:['#9a98b0','#8a88a0','#aaa8c0','#9392aa','#a2a0b8'];for(let i=0;i<9;i++){g.fillStyle=c[i%5];g.beginPath();g.arc(8+i*2.6+Math.sin(i+f)*1.5,14+Math.cos(i*1.7)*6+f,6.5,0,6.283);g.fill()}
    g.fillStyle=h?'#ffffff':'#b8b6cc';g.beginPath();g.ellipse(18,19+f,11,9,0,0,6.283);g.fill();g.fillStyle=c[2];g.fillRect(6,26+f,4,6);g.fillRect(16,27+f,4,7);g.fillRect(26,26+f,4,6);E(g,12,17+f,false,h);g.fillStyle=h?'#f28cb8':'#8a88a0';g.fillRect(16,23+f,4,1)})}
// draw the right body for the land's guardian (kind stays "golem" so all boss rules keep working)
{const _dm5=drawMon;drawMon=function(m,tm){if(m.boss&&M&&M.bossName&&m.kind==='golem'){bossArt();const art=BOSS_ART[M.bossName];if(art){const h=m.happy?1:0,k='golem'+h,orig=MON_ART[k],th=M.theme;MON_ART[k]=art[h];M.theme=null;try{return _dm5.apply(this,arguments)}finally{MON_ART[k]=orig;M.theme=th}}}return _dm5.apply(this,arguments)}}
{const _sl2=showLine;showLine=function(){const r=_sl2.apply(this,arguments);try{const [who]=DLG.lines[DLG.i];if(LAND_BOSS[who]){bossArt();const a=BOSS_ART[who]&&BOSS_ART[who][0][0];if(a){const g=$('dlgP').getContext('2d');g.clearRect(0,0,64,64);g.imageSmoothingEnabled=false;g.drawImage(a,0,0,72,72,0,2,64,64)}}}catch(e){}return r}}
// landmarks: something you remember each land by (placed where it cannot block any path)
const LM={forest:{w:48,h:40,fw:3,fh:1,draw:g=>{for(const [x,y,r,c] of [[10,22,9,'#e35d9c'],[26,14,13,'#f06cb4'],[40,24,8,'#c74a8a']]){g.fillStyle='#f3e6c8';g.fillRect(x-2,y,4,40-y);g.fillStyle=c;g.beginPath();g.ellipse(x,y,r,r*.6,0,Math.PI,0);g.fill();g.fillRect(x-r,y-1,r*2,2);g.fillStyle='#fff3fa';g.beginPath();g.arc(x-r/3,y-r/3,1.6,0,6.283);g.fill()}}},
  desert:{w:48,h:36,fw:3,fh:1,draw:g=>{for(let i=0;i<6;i++){g.fillStyle=i%2?'#d9aa62':'#e8c07a';g.fillRect(4+i*3.5,35-(i+1)*5.5,40-i*7,6)}g.fillStyle='#3fa7a0';g.fillRect(21,27,6,8);g.fillStyle='#b5563a';g.fillRect(22,28,4,1);g.fillStyle='#fff0c8';g.fillRect(23,1,2,2)}},
  ulake:{w:48,h:24,fw:3,fh:1,flat:1,draw:g=>{g.fillStyle='#1c2f57';g.beginPath();g.ellipse(24,15,22,8,0,0,6.283);g.fill();g.fillStyle='#56d6d0';g.fillRect(8,14,6,1);g.fillRect(30,17,8,1);g.fillStyle='#8a5a3c';g.fillRect(16,9,16,4);g.fillRect(18,13,12,1);g.fillStyle='#f3e3c3';g.fillRect(23,3,1,6);g.fillStyle='#f28c8c';g.fillRect(24,4,4,3)}},
  sky:{w:32,h:56,fw:2,fh:1,draw:g=>{g.fillStyle='#dde7f2';g.fillRect(6,14,20,42);g.fillStyle='#bfd3ea';g.fillRect(6,14,4,42);g.fillStyle='#a99be0';g.beginPath();g.moveTo(3,15);g.lineTo(16,1);g.lineTo(29,15);g.fill();g.fillStyle='#f3e3c3';g.fillRect(13,24,6,8);g.fillRect(13,38,6,8);g.fillStyle='#f6a24a';g.fillRect(2,20,3,4);g.fillRect(27,30,3,4)}}};
function placeLandmark(){if(!M||!M.land||M.floor!==1||M._lm)return;const th=M.theme,L=LM[th];if(!L)return;M._lm=1;const key='lm_'+th;if(!IMG[key])IMG[key]=chunky(L.w,L.h,L.draw);
  const sp=M.spawnDefault,sx=Math.floor(sp[0]/T),sy=Math.floor(sp[1]/T);const all=freeTilesFrom(sx,sy,60),total=all.length;const rnd2=faSeed('lm'+M.id);const cands=all.filter(t=>t.d>=7).sort(()=>rnd2()-.5).slice(0,60);
  const busy=(x,y)=>(M.crystals||[]).some(c=>Math.abs(c.tx-x)<3&&Math.abs(c.ty-y)<3)||(M.digs||[]).some(d=>Math.abs(Math.floor(d.x/T)-x)<2&&Math.abs(Math.floor(d.y/T)-y)<2)||M.exits.some(e=>Math.abs(Math.floor(e.x/T)-x)<3&&Math.abs(Math.floor(e.y/T)-y)<3)||(M.fa||[]).some(f=>Math.abs(f.tx-x)<2&&Math.abs(f.ty-y)<2);
  for(const c of cands){const tiles=[];for(let dx=0;dx<L.fw;dx++)tiles.push((c.x+dx)+','+c.y);if(!tiles.every(k=>M.FLOOR.has(k)&&!M.SOLID.has(k))||busy(c.x,c.y))continue;tiles.forEach(k=>M.SOLID.add(k));
    if(freeTilesFrom(sx,sy,60).length===total-tiles.length){const W=L.w*2,H=L.h*2;M.objs.push({img:key,sx:0,sy:0,sw:W,sh:H,x:(c.x+L.fw/2)*T,y:(c.y+1)*T-2,cb:H-1,a:1,tall:1,lm:th});return}tiles.forEach(k=>M.SOLID.delete(k))}}
{const _gm10=goMap;goMap=function(){const r=_gm10.apply(this,arguments);try{placeLandmark()}catch(e){}return r}}

// ---- 60-30-10 audit fixes (measured in qa052) ----
// lands are lit enough to show their own colours; caves keep their mystery
{const _gm11=goMap;goMap=function(){const r=_gm11.apply(this,arguments);try{if(M&&M.land&&!M.bright)M.darkA=S&&S.boss?.34:.5}catch(e){}return r}}
// daytime towns get the LA dusk grade: a soft violet vignette (the 30% family tone) so bright towns still look like LA
// a CSS layer over the canvas: the browser composites it for free (painting it on the canvas every frame cost ~15 fps on phones)
const VIGEL=(()=>{const d=document.createElement('div');d.id='laVig';d.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:1;opacity:0;transition:opacity .8s;background:radial-gradient(ellipse at 50% 55%,rgba(75,63,114,0) 40%,rgba(75,63,114,.42) 100%)';try{const c=document.getElementById('c');c.parentNode.insertBefore(d,c.nextSibling)}catch(e){document.body.append(d)}return d})();
let VIG_T=0;{const _up13=update;update=function(dt){const r=_up13.apply(this,arguments);VIG_T-=dt;if(VIG_T<=0){VIG_T=1;try{VIGEL.style.opacity=(M&&M.kind==='town'&&!duskish())?'1':'0'}catch(e){}}return r}}
