// ===== maps =====
const PR={banana:[1,1],bananaB:[67,1],frangi:[133,1],roundA:[199,1],roundB:[1,67],pink:[67,67],mango:[133,67],well:[199,67],lamp:[1,133],palm:[67,133],coop:[133,133],stall:[199,133],bench:[1,199],board:[67,199],arch:[133,199],bath:[199,199]};
const MR=__MRECTS__,CR=__CRECTS__,FR=__FRECTS__,DR=__DRECTS__;
// new PixelLab cave set (A-30/A-31, passed review 27 Sep 2026)
function addDP(m,k,x,y,o={}){const r=DR[k];if(!r)return null;const ob={img:'dprops',sx:r[0],sy:r[1],sw:64,sh:64,x,y,tall:o.flat?0:1,cs:o.cs??.4,flat:!!o.flat,dk:k,needBoss:o.needBoss};m.objs.push(ob);if(o.solid)m.SOLID.add(key(Math.floor(x/T),Math.floor(y/T)));return ob}
function newMap(id,kind,w,h,seed){return{id,kind,w,h,seed,PATH:new Set(),COBBLE:new Set(),WATER:new Set(),CLIFF:new Set(),FLOOR:new Set(),SOLID:new Set(),objs:[],decks:[],exits:[],stones:[],blocks:[],crystals:[],digs:[],spawns:[],glows:[],anims:[]}}
function addTree(m,k,tx,ty,solid=true){const src=MR[k]?['mprops',MR[k]]:['props',PR[k]];m.objs.push({img:src[0],sx:src[1][0],sy:src[1][1],sw:64,sh:64,x:tx*T+16,y:ty*T+30,sway:1,tall:1,cs:.5,ph:rnd()*6});if(solid)m.SOLID.add(key(tx,ty))}
function addProp(m,k,tx,ty,o={}){m.objs.push({img:'props',sx:PR[k][0],sy:PR[k][1],sw:64,sh:64,x:tx*T+16+(o.dx||0),y:ty*T+(o.dy??28),tall:o.tall??1,cs:o.cs??.45,lamp:k==='lamp'});if(o.solid!==0)m.SOLID.add(key(tx,ty))}
function addDeco(m,k,tx,ty,solid,dx=0){m.objs.push({img:'mprops',sx:MR[k][0],sy:MR[k][1],sw:64,sh:64,x:tx*T+16+dx,y:ty*T+28,cs:.3,tall:0,small:!solid});if(solid)m.SOLID.add(key(tx,ty))}
function addCave(m,k,x,y,o={}){const r=CR[k];m.objs.push({img:'cprops',sx:r[0],sy:r[1],sw:r[2],sh:r[3],x,y,tall:o.tall??(r[2]>32?1:0),small:r[2]<=32,cs:o.cs??.4,flat:o.flat});if(o.solid)m.SOLID.add(key(Math.floor(x/T),Math.floor(y/T)))}
function addNpc(m,who,tx,ty,face=0){const o={img:'npc_'+who,sx:face*64,sy:0,sw:64,sh:64,x:tx*T+16,y:ty*T+28,tall:1,cs:.45,npc:who,face};m.objs.push(o);m.SOLID.add(key(tx,ty));(m.npcs||(m.npcs=[])).push(o)}
function addStone(m,id,tx,ty,plaza){const o={img:plaza?'stonePlaza':'stone',sx:0,sy:0,sw:64,sh:64,x:tx*T+16,y:ty*T+28,tall:1,cs:.45,stoneId:id};m.objs.push(o);m.SOLID.add(key(tx,ty));m.stones.push({id,x:o.x,y:o.y,obj:o})}

// ---------- Fountain Plaza (town centre, paved) ----------
function buildPlaza(){SEED=11;const m=newMap('plaza','town',36,24,11),PX=18,PY=12;m.nameKey='plaza';
  for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++)if(Math.hypot(x+.5-PX,y+.5-PY)<4.9)m.COBBLE.add(key(x,y));
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)m.COBBLE.add(key(x,y))};pr(17,0,18,8);pr(0,11,14,12);pr(22,11,35,12);pr(17,16,18,23);
  for(let y=-1;y<=m.h;y++){const c=28+Math.round(1.4*Math.sin(y*.33+1));m.WATER.add(key(c,y));m.WATER.add(key(c+1,y))}
  m.WATER.forEach(k=>m.SOLID.add(k));const br=[];for(const y of [11,12])for(let x=0;x<m.w;x++)if(m.WATER.has(key(x,y))){m.SOLID.delete(key(x,y));br.push(x)}
  m.decks.push({img:'bridgeStone',x:(Math.min(...br)+Math.max(...br)+1)/2*T,y:12*T,oy:64});
  [['roundA',11,7],['roundB',9,9],['mango',5,9],['roundA',8,15],['roundB',12,18],['roundA',23,6],['roundB',21,4],['frangi',14,5],['pink',24,15],['roundA',25,18],
   ['roundB',32,6],['roundA',33,9],['palm',32,14],['roundB',32,17],['roundA',31,21],['roundA',4,6],['roundB',3,16],['roundA',6,20],['banana',12,21],['roundB',23,21],['bananaB',26,16],['frangi',2,13]].forEach(a=>addTree(m,...a));
  const F={img:'fountBig',sx:0,sy:0,sw:128,sh:128,x:PX*T,y:(PY+1)*T+14,tall:1,cs:.35,pick:()=>(LIGHT<.6&&IMG.fountOld)||IMG.fountBig};m.objs.push(F);m.fountain=F;for(let x=16;x<=19;x++)for(let y=11;y<=12;y++)m.SOLID.add(key(x,y));
  addProp(m,'bench',15,8,{tall:0,cs:.3});addProp(m,'bench',20,8,{tall:0,cs:.3});addProp(m,'board',13,9);m.board=m.objs[m.objs.length-1];addProp(m,'stall',25,9);addProp(m,'bath',22,15,{tall:0,cs:.3});
  [[16,6],[19,6],[14,15],[21,15],[10,10],[16,18],[19,18]].forEach(([x,y])=>addProp(m,'lamp',x,y));
  addDeco(m,'flowers',12,14,0);addDeco(m,'flowers',23,9,0);addDeco(m,'flowers',15,17,0);addDeco(m,'flowers',21,17,0);addDeco(m,'bush',11,14,1);addDeco(m,'bush',24,8,1);addDeco(m,'grass',7,12,0);addDeco(m,'grass',27,20,0);
  addStone(m,'plaza',21,9,true);addNpc(m,'leah',16,15,0);
  m.exits.push({id:'n',x:18*T,y:12,to:'mountain',toExit:'s',label:'mountain'},{id:'w',x:14,y:12*T,to:'home',toExit:'e',label:'home'},{id:'e',x:m.w*T-14,y:12*T,to:'market',toExit:'w',label:'market'},{id:'s',x:18*T,y:m.h*T-8,locked:1,label:'soonS'});
  m.spawnDefault=[18*T,7*T];return m}

// ---------- Mountain Foot (cliffs, cave in the cliff, waterfall, rockfall) ----------
function buildMountain(){SEED=23;const m=newMap('mountain','town',34,22,23);m.nameKey='mountain';
  const base=x=>(x>=14&&x<=20)?6:Math.max(4,Math.min(7,5+Math.round(1.2*Math.sin(x*.55)+.8*Math.sin(x*1.3))));
  for(let x=-1;x<=m.w;x++)for(let y=-1;y<=base(Math.max(0,Math.min(m.w-1,x)));y++)m.CLIFF.add(key(x,y));
  for(let x=3;x<=5;x++)for(let y=1;y<=base(x)+1;y++)m.CLIFF.delete(key(x,y));
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)m.PATH.add(key(x,y))};
  pr(15,9,16,21);pr(14,8,19,9);pr(4,12,16,13);pr(17,12,33,13);for(let y=1;y<=12;y++)m.PATH.add(key(4,y));
  const sBase=Math.max(base(26),base(27),base(28),base(29));for(let y=sBase+1;y<m.h+1;y++){const c=27+Math.round(1.5*Math.sin(y*.35));m.WATER.add(key(c,y));m.WATER.add(key(c+1,y))}
  m.CLIFF.forEach(k=>m.SOLID.add(k));m.WATER.forEach(k=>m.SOLID.add(k));for(let x=3;x<=5;x++)for(let y=1;y<=base(x)+1;y++)m.SOLID.add(key(x,y));m.SOLID.add(key(15,7));m.SOLID.add(key(18,7));
  const br=[];for(const y of [12,13])for(let x=0;x<m.w;x++)if(m.WATER.has(key(x,y))){m.SOLID.delete(key(x,y));br.push(x)}
  m.decks.push({img:'bridgeRope',x:(Math.min(...br)+Math.max(...br)+1)/2*T,y:13*T,oy:61});
  [['pine',1,9],['pineTwin',2,11],['pine2',1,14],['pineThick',3,16],['pine',1,18],['pine2',6,19],['roundA',8,17],['pineYoung',10,20],['pineBird',8,8],['pine',11,9],
   ['pine',31,9],['pineThick',32,10],['pink',30,15],['pine2',32,18],['roundB',31,20],['frangi',22,11],['roundA',23,16],['pineYoung',20,19],['bananaB',24,9]].forEach(a=>addTree(m,...a));
  [['pine',1,2],['pine2',7,2],['pineThick',9,1],['pineTwin',11,2],['pine',13,1],['pine2',21,2],['pineYoung',23,1],['pine',25,2],['pineTwin',29,1],['pine2',31,2],['pine',33,3]].forEach(([k,x,y])=>addTree(m,k,x,y,false));
  addDeco(m,'bush',7,base(7)+1,1);addDeco(m,'fern',12,base(12)+1,0);addDeco(m,'boulder',10,10,1);addDeco(m,'flowers',8,15,0);addDeco(m,'flowers',24,18,0);addDeco(m,'grass',12,18,0);
  addDeco(m,'mossRock',25,10,0);addDeco(m,'stump',5,17,1);addDeco(m,'log',11,15,1);addDeco(m,'berry',29,17,1);
  addProp(m,'lamp',14,10);addProp(m,'lamp',19,10);
  addCave(m,'crate',13*T+16,8*T+28,{solid:1});addCave(m,'rope',12*T+14,8*T+24,{solid:1});
  m.objs.push({img:'caveDoor',sx:0,sy:0,sw:128,sh:128,x:17*T,y:7*T-10,flat:1});
  m.objs.push({img:'rock',sx:0,sy:0,sw:128,sh:128,x:4*T+16,y:(base(4)+2)*T+4,cs:.3});m.blocks.push({x:4*T+16,y:(base(4)+1)*T,msg:'rock'});
  addStone(m,'mountain',20,8);addNpc(m,'dad',13,11,2);
  m.exits.push({id:'s',x:16*T,y:m.h*T-6,to:'plaza',toExit:'n',label:'plaza'},{id:'e',x:m.w*T-14,y:13*T,locked:1,label:'soonE'},{id:'cave',x:17*T,y:7*T+20,to:'cave1',toExit:'up',label:'cave1'});
  const wf={x:(27+Math.round(1.5*Math.sin((sBase+1)*.35)))*T+6,top:(sBase-1)*T+6,bot:(sBase+1)*T+14,w:2*T-12};
  m.anims.push(tm=>{const x0=wf.x-camX,w=wf.w,top=wf.top-camY,bot=wf.bot-camY;ctx.fillStyle='rgba(120,215,235,.9)';ctx.fillRect(x0,top,w,bot-top);ctx.fillStyle='rgba(60,150,190,.9)';ctx.fillRect(x0,top,2,bot-top);ctx.fillRect(x0+w-2,top,2,bot-top);
    for(let i=0;i<14;i++){const xx=x0+3+((i*7)%(w-6)),len=6+(i%4)*3,yy=top+((tm*60+i*17)%(bot-top+len))-len;ctx.fillStyle=i%3?'rgba(235,252,255,.9)':'rgba(175,235,248,.95)';const y1=Math.max(top,Math.round(yy));ctx.fillRect(xx,y1,1,Math.max(0,Math.min(len,bot-y1)))}
    for(let i=0;i<16;i++){const a=tm*6+i*2.1,rx=Math.cos(a)*(8+(i%5)*2),ry=Math.abs(Math.sin(a*1.7))*5;ctx.fillStyle='rgba(255,255,255,.95)';ctx.fillRect(Math.round(x0+w/2+rx),Math.round(bot-ry),1+(i%2),1)}});
  m.glows.push([17*T-34,7*T-76],[17*T+34,7*T-76]);m.spawnDefault=[16*T,19*T];return m}

// ---------- Crystal Cave floors (rooms + corridors from a fixed seed, so saved crystals keep their ids) ----------
const CAVE_CFG={cave1:{gw:4,gh:3,branch:2,seed:101,w:36,h:26,rooms:8,crystals:8,digs:5,mons:[['slime',4],['bat',2]],next:'cave2'},
  cave2:{gw:4,gh:3,branch:2,seed:202,w:38,h:28,rooms:9,crystals:6,digs:5,mons:[['slime',4],['bat',3],['mushbug',3]],next:'cave3'},
  cave3:{gw:5,gh:3,branch:2,seed:303,w:40,h:30,rooms:7,crystals:4,digs:4,mons:[['bat',3],['mushbug',3]],boss:true}};
const CHUNKS={"rooms":{"hall":["###.....###","#P.......P#","#..c...p..#","...........","....m......","...........","#..d...m..#","#p.......p#","###.....###"],"bend":["####...####","##.....P..#","#..p.c....#",".....##....","....###.m..","...........","#.d.....p.#","##..m....##","####...####"],"pillars":["####...####","#p.......c#","#..P...P..#","...........","..m..o..m..","...........","#..P...P..#","#d.......p#","####...####"],"pond":["###.....###","#p..c....P#","#...###...#","....#####..",".m..#####..","....###....","#.........#","#P..d...p.#","####...####"],"twin":["####...####","#c..#.#..p#","#...#.#...#","...........","..m..o..m..","...........","#...#.#...#","#p..#.#.d.#","####...####"],"nook":["####...####","#P..c...###","#.......p##","...........",".....m.....","...........","##p...d...#","###....P..#","####...####"],"cross":["###.....###","##p..c..P##","#.........#","...........","..o..m..o..","...........","#.........#","##P..d..p##","###.....###"],"ring":["####...####","#p.......c#","#..#####..#","...#####...",".m.#####.m.","...#####...","#..#####..#","#d.......p#","####...####"],"snake":["####...####","#P..#...c.#","#...#.....#","....#..p...",".m..o..m...","......#....","#.....#...#","#p.d..#..P#","####...####"],"garden":["###.....###","#p.c...p..#","#.........#","....ppp....","..m.....m..","...........","#.d.....c.#","#P.......P#","###.....###"],"wide":["##.......##","#.P.....p.#","#....c....#","...........","...m...m...","...........","#.d.......#","#p.......P#","##.......##"],"cave":["####...####","###.....###","#p...c...P#","...........","..m....o...","...........","#P..d....p#","###.....###","####...####"]},"entrance":["####...####","#p.......P#","#.........#","...S.......","...........","...........","#.........#","#P.......p#","####...####"],"arena":["###.....###","#P.......P#","#.........#","...........","...........","...........","#.........#","#p.......p#","###.....###"]};

// ---------- caves built from hand-designed room chunks (Diablo 2 "presets" idea) ----------
// Each floor = a grid of 11x9 rooms. A path runs from the entrance room (left edge) to the last room (right edge);
// short side rooms always hold a reward. Props/crystals/monster spots come from the room designs, so nothing lands in a corridor.
const CW=11,CHH=9,BIGP=['dStalag','dCyan','dViolet','dGeode','dPillar','dLantern','dCyan','dStalag'],SMALLP=['dMushY','dMushB','dShards','dPuddle','dFossil','dNest','pebbles','rocks','mushR','dShards','dMushY'],FLATP={dShards:1,dPuddle:1,dFossil:1,dNest:1,dPool:1};
function chunkPlan(C,r){const gw=C.gw,gh=C.gh,sy=Math.floor(r()*gh),ey=Math.floor(r()*gh),used=new Map(),K=(x,y)=>x+','+y,link=(a,b)=>{a.doors.add(b.gx>a.gx?'E':b.gx<a.gx?'W':b.gy>a.gy?'S':'N');b.doors.add(a.gx>b.gx?'E':a.gx<b.gx?'W':a.gy>b.gy?'S':'N')};
  const cell=(x,y)=>{if(!used.has(K(x,y)))used.set(K(x,y),{gx:x,gy:y,doors:new Set()});return used.get(K(x,y))};
  let cur=cell(0,sy);const path=[cur];let vmoves=0;
  while(cur.gx<gw-1||cur.gy!==ey){let nx=cur.gx,ny=cur.gy;
    if(cur.gx===gw-1)ny+=Math.sign(ey-cur.gy);
    else{const up=cur.gy>0&&!used.has(K(cur.gx,cur.gy-1)),dn=cur.gy<gh-1&&!used.has(K(cur.gx,cur.gy+1)),q=r();if(vmoves<1&&up&&q<.25)ny--;else if(vmoves<1&&dn&&q<.5)ny++;else nx++}
    vmoves=nx===cur.gx?vmoves+1:0;const nxt=cell(nx,ny);link(cur,nxt);path.push(nxt);cur=nxt}
  const branches=[];for(let b=0;b<(C.branch||2);b++){for(let k=0;k<20;k++){const p=path[1+Math.floor(r()*Math.max(1,path.length-2))];if(!p)break;const d=[[0,-1],[0,1],[1,0],[-1,0]][Math.floor(r()*4)],x=p.gx+d[0],y=p.gy+d[1];if(x<0||y<0||x>=gw||y>=gh||used.has(K(x,y)))continue;const c=cell(x,y);c.branch=1;link(p,c);branches.push(c);break}}
  return{used,start:path[0],end:path[path.length-1],path,branches}}
function buildCave(id){const C=CAVE_CFG[id];const gw=C.gw||4,gh=C.gh||3,W=gw*CW,H=gh*CHH;const m=newMap(id,'cave',W,H,C.seed);m.nameKey=id;const r=seeded(C.seed);SEED=C.seed;
  const plan=chunkPlan({gw,gh,branch:C.branch},r),grid=[],marks=[];for(let y=0;y<H;y++)grid.push(Array(W).fill('#'));
  const names=Object.keys(CHUNKS.rooms);let bag=[];const pickRoom=()=>{if(!bag.length)bag=names.slice();return bag.splice(Math.floor(r()*bag.length),1)[0]};
  m.rooms=[];for(const c of plan.used.values()){const isS=c===plan.start,isE=c===plan.end&&C.boss;let tpl=isS?CHUNKS.entrance:isE?CHUNKS.arena:CHUNKS.rooms[pickRoom()];if(!isS&&r()<.5)tpl=tpl.map(row=>row.split('').reverse().join(''));
    const open=new Set(c.doors);if(isS)open.add('W');if(c===plan.end&&C.next)open.add('E');c.open=open;
    for(let y=0;y<CHH;y++)for(let x=0;x<CW;x++){let ch=tpl[y][x];const edgeW=x===0&&y>=3&&y<=5,edgeE=x===CW-1&&y>=3&&y<=5,edgeN=y===0&&x>=4&&x<=6,edgeS=y===CHH-1&&x>=4&&x<=6;
      if((edgeW&&!open.has('W'))||(edgeE&&!open.has('E'))||(edgeN&&!open.has('N'))||(edgeS&&!open.has('S')))ch='#';
      if((x===0&&!edgeW)||(x===CW-1&&!edgeE)||(y===0&&!edgeN)||(y===CHH-1&&!edgeS))if(ch!=='#')ch='#';
      const X=c.gx*CW+x,Y=c.gy*CHH+y;grid[Y][X]=ch==='#'?'#':'.';if('cdmPpoS'.includes(ch))marks.push({ch,x:X,y:Y,c})}
    m.rooms.push({x:c.gx*CW+1,y:c.gy*CHH+1,w:CW-2,h:CHH-2,start:isS,boss:isE,branch:!!c.branch})}
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(grid[y][x]==='.'&&x>0&&y>0&&x<W-1&&y<H-1)m.FLOOR.add(key(x,y));
  // the entrance sits on the map edge; keep its doorway walkable one tile in
  const S=plan.start,sx=S.gx*CW+1,sy=S.gy*CHH+4;for(const yy of [sy-1,sy,sy+1])m.FLOOR.add(key(1,yy));
  const E=plan.end,ex=E.gx*CW+CW-2,ey=E.gy*CHH+4;
  // props from the room designs only
  const solid=new Set(),place=(k,x,y,sol,glow)=>{if(DR[k])addDP(m,k,x*T+16,y*T+30,{solid:sol,flat:FLATP[k]});else addCave(m,k,x*T+16,y*T+(CR[k][2]>32?30:26),{solid:sol});if(sol)solid.add(key(x,y));if(glow)m.glows.push([x*T+16,y*T+10])};
  for(const q of marks)if(q.ch==='P'){const k=BIGP[Math.floor(r()*BIGP.length)];place(k,q.x,q.y,true,k==='dLantern')}
  for(const q of marks)if(q.ch==='p'){const k=SMALLP[Math.floor(r()*SMALLP.length)];place(k,q.x,q.y,false,k==='dNest')}
  // optional blockers: only kept if every floor tile can still be reached from the entrance
  const reachAll=block=>{const ok=(x,y)=>{const kk=key(x,y);return m.FLOOR.has(kk)&&!solid.has(kk)&&!block.has(kk)};const seen=new Set([key(1,sy)]),st=[[1,sy]];let n=1;while(st.length){const [x,y]=st.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const kk=key(x+dx,y+dy);if(!seen.has(kk)&&ok(x+dx,y+dy)){seen.add(kk);st.push([x+dx,y+dy]);n++}}}let tot=0;for(const k of m.FLOOR)if(!solid.has(k)&&!block.has(k))tot++;return n===tot};
  for(const q of marks)if(q.ch==='o'&&r()<.5){const kk=key(q.x,q.y);if(reachAll(new Set([kk])))place('rocks',q.x,q.y,true)}
  for(const k of solid)m.FLOOR.has(k)&&m.SOLID.add(k);
  for(let y=0;y<H;y++)for(let x=0;x<W;x++)if(!m.FLOOR.has(key(x,y)))m.SOLID.add(key(x,y));
  // nothing that looks walkable may be unreachable: turn unreachable floor into wall
  {const seen=new Set([key(1,sy)]),st=[[1,sy]];while(st.length){const [x,y]=st.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const kk=key(x+dx,y+dy);if(!seen.has(kk)&&m.FLOOR.has(kk)&&!m.SOLID.has(kk)){seen.add(kk);st.push([x+dx,y+dy])}}}
    for(const k of [...m.FLOOR])if(!seen.has(k)&&!solid.has(k)){m.FLOOR.delete(k);m.SOLID.add(k)}m.objs=m.objs.filter(o=>!(o.solidKey&&!m.FLOOR.has(o.solidKey)))}
  // exits on the map edge
  m.exits.push({id:'up',x:1*T+16,y:sy*T+16,to:C.up||(id==='cave1'?'mountain':'cave'+(+id.slice(4)-1)),toExit:C.upExit||(id==='cave1'?'cave':'down'),label:id==='cave1'?'mountain':'up'});addDP(m,'dLadder',1*T+16,sy*T+10,{})||addCave(m,'ladder',1*T+16,sy*T+12,{flat:1});
  if(C.mul)m.mul=C.mul;m.mod=C.mod;m.bossEl=C.bossEl;if(C.mod==='house')m.expMul=1.5;if(C.mod==='dark')m.darkFloor=1;
  {const st=marks.find(q=>q.ch==='S');if(st)addStone(m,id,st.x,st.y)}
  if(C.next){m.exits.push({id:'down',x:ex*T+16,y:ey*T+16,to:C.next,toExit:'up',label:'down',lockBoss:!!C.boss});addDP(m,'dStairs',ex*T+16,ey*T+34,{flat:1})||addCave(m,'stairs',ex*T+16,ey*T+30,{flat:1})}
  const occupied=(x,y,d)=>[...m.crystals,...m.digs].some(q=>Math.hypot(q.tx-x,q.ty-y)<d)||m.exits.some(e=>Math.hypot(e.x/T-.5-x,e.y/T-.5-y)<2.5)||m.SOLID.has(key(x,y));
  const inStart=(x,y)=>Math.floor(x/CW)===S.gx&&Math.floor(y/CHH)===S.gy;
  const floorCells=[...m.FLOOR].map(k=>k.split(',').map(Number)).filter(([x,y])=>!m.SOLID.has(key(x,y))&&!inStart(x,y));
  // crystals: designed spots first (side rooms preferred), then any floor far from others
  const cs=marks.filter(q=>q.ch==='c'&&q.c!==S).sort((a,b)=>(b.c.branch?1:0)-(a.c.branch?1:0)||r()-.5);
  for(const q of cs){if(m.crystals.length>=C.crystals)break;if(occupied(q.x,q.y,3))continue;m.crystals.push({id:id+'-c'+m.crystals.length,tx:q.x,ty:q.y,x:q.x*T+16,y:q.y*T+22,awake:false})}
  for(let k=0;m.crystals.length<C.crystals&&k<400;k++){const [x,y]=floorCells[Math.floor(r()*floorCells.length)];if(occupied(x,y,4))continue;m.crystals.push({id:id+'-c'+m.crystals.length,tx:x,ty:y,x:x*T+16,y:y*T+22,awake:false})}
  // dig spots move every day (same for everyone on that day)
  {const day=Math.floor(Date.now()/864e5),rd=seeded(C.seed*7+day),ds=marks.filter(q=>q.ch==='d'&&q.c!==S).map(q=>[q.x,q.y]).concat(floorCells.slice(0,0));const pool=ds.length>=C.digs?ds:ds.concat(floorCells);
    for(let k=0;m.digs.length<C.digs&&k<400;k++){const [x,y]=pool[Math.floor(rd()*pool.length)];if(occupied(x,y,3))continue;m.digs.push({id:id+'-d'+m.digs.length+'-'+day,tx:x,ty:y,x:x*T+16,y:y*T+18,done:false})}}
  // monsters: designed spots first, never in the entrance room
  const ms=marks.filter(q=>q.ch==='m'&&q.c!==S);let mi=0;for(const [kind,n] of C.mons)for(let i=0;i<n;i++){let p=ms[mi++];if(!p||m.SOLID.has(key(p.x,p.y))){const f=floorCells[Math.floor(r()*floorCells.length)];p={x:f[0],y:f[1]}}m.spawns.push({kind,x:p.x*T+16,y:p.y*T+16})}
  if(C.mod==='treasure'){m.chests=[];for(const b of plan.branches.concat(plan.path.slice(1,-1)).slice(0,2)){const cx=b.gx*CW+5,cy=b.gy*CHH+4;if(m.FLOOR.has(key(cx,cy))&&!m.SOLID.has(key(cx,cy)))m.chests.push({x:cx*T+16,y:cy*T+24,open:false,id:id+'-c'+m.chests.length+'-'+Math.floor(Date.now()/864e5)})}}
  if(C.boss){const bx=E.gx*CW+5,by=E.gy*CHH+4;m.bossSpawn={x:bx*T+16,y:by*T+16};m.bossRoom={x:E.gx*CW+1,y:E.gy*CHH+1,w:CW-2,h:CHH-2,boss:1};
    if(id==='cave3'){const side=!E.doors.has('S')?'S':!E.doors.has('N')?'N':null;const dy=side==='S'?E.gy*CHH+7:side==='N'?E.gy*CHH+1:by+2;m.exits.push({id:'dream',x:bx*T+16,y:dy*T+16,to:'dream1',toExit:'up',label:'dreamIn',needBoss:1});m.dreamDoor=1;addDP(m,'dPortal',bx*T+16,dy*T+30,{needBoss:1});addDP(m,'dHeart',bx*T+16,by*T+36,{needBoss:1})}}
  // Dream Cave extras: a campfire at the entrance, one buff shrine per floor (Diablo pylon idea)
  if(id.startsWith('dream')){const st=marks.find(q=>q.ch==='S');if(st){const fx=st.x+2,fy=st.y+1;if(m.FLOOR.has(key(fx,fy))){addDP(m,'dFire',fx*T+16,fy*T+30,{});m.fire={x:fx*T+16,y:fy*T+24};m.glows.push([fx*T+16,fy*T+14])}}
    if(!C.boss){const mids=plan.path.slice(1,-1).concat(plan.branches);const c=mids[Math.floor(r()*mids.length)];if(c){const sx2=c.gx*CW+5,sy2=c.gy*CHH+4;if(m.FLOOR.has(key(sx2,sy2))&&!m.SOLID.has(key(sx2,sy2))&&reachAll(new Set([key(sx2,sy2)]))){const kind=['C','G','P'][Math.floor(r()*3)];m.shrines=[{x:sx2*T+16,y:sy2*T+24,kind,used:false}];addDP(m,'sh'+kind,sx2*T+16,sy2*T+30,{solid:1});m.glows.push([sx2*T+16,sy2*T+8])}}}}
  m.seen=new Set();m.spawnDefault=[2*T+16,sy*T+16];m.plan=plan;return m}
function addFarm(m,k,tx,ty,solid=true,dy=0){const r=FR[k];m.objs.push({img:'farm',sx:r[0],sy:r[1],sw:32,sh:32,x:tx*T+16,y:ty*T+28+dy,small:1,cs:.3,tall:0});if(solid)m.SOLID.add(key(tx,ty))}
function buildHome(){SEED=31;const m=newMap('home','town',34,22,31);m.nameKey='home';
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)m.PATH.add(key(x,y))};pr(6,11,33,12);pr(10,9,11,10);pr(19,10,20,10);pr(16,13,17,21);
  m.objs.push({img:'bld',sx:1,sy:1,sw:128,sh:128,x:10*T+16,y:9*T+2,tall:1,cs:.45});for(let x=8;x<=13;x++)for(let y=6;y<=8;y++)m.SOLID.add(key(x,y));
  // fenced vegetable garden with a gate facing the road
  for(let x=15;x<=24;x++){addFarm(m,'fenceSide',x,4);if(x!==19&&x!==20)addFarm(m,'fenceSide',x,9)}for(let y=5;y<=8;y++){addFarm(m,'fenceTop',15,y);addFarm(m,'fenceTop',24,y)}
  addFarm(m,'gateOpen',19,9,false);addFarm(m,'gateOpen',20,9,false);
  [['cabbageBed',16,5],['carrotBed',17,5],['tomatoBed',18,5],['sproutBed',21,5],['strawberryBed',22,5],['pumpkinPatch',23,5],].forEach(([k,x,y])=>addFarm(m,k,x,y));
  m.plots=[[16,7],[17,7],[18,7],[21,7],[22,7],[23,7]].map(([x,y],i)=>({i,tx:x,ty:y,x:x*T+16,y:y*T+22}));
  addFarm(m,'scarecrow',20,6);addFarm(m,'wateringCan',18,8,false);addFarm(m,'wheelbarrow',21,8);
  addFarm(m,'greenhouse',26,6);addFarm(m,'beehive',27,8);addFarm(m,'waterBarrel',14,9);addFarm(m,'hayBale',5,9);addFarm(m,'firewood',7,9);addFarm(m,'birdhouse',12,10,false);m.mailbox={x:12*T+16,y:10*T+26};addFarm(m,'birdhouse',25,10);
  addProp(m,'well',4,13);addProp(m,'coop',3,8);addProp(m,'lamp',14,13);addProp(m,'lamp',22,13);
  [['roundA',1,4],['roundB',2,16],['mango',6,18],['roundA',10,19],['pink',12,15],['roundB',27,3],['roundA',30,6],['frangi',31,15],['roundB',29,19],['roundA',22,17],['banana',25,15],['palm',32,10],['roundB',1,11],['roundA',6,3]].forEach(a=>addTree(m,...a));
  addDeco(m,'flowers',9,13,0);addDeco(m,'flowers',19,14,0);addDeco(m,'bush',13,16,1);addDeco(m,'grass',28,13,0);addDeco(m,'flowers',26,17,0);
  addNpc(m,'mom',12,11,0);
  if(houseLv()>=9){m.pool=new Set();for(let y=14;y<=16;y++)for(let x=6;x<=11;x++){const k=key(x,y);m.pool.add(k);m.SOLID.delete(k)}
    m.paint=g=>{g.fillStyle='#f4efe4';g.fillRect(6*T-16-5,14*T-16-5,6*T+10,3*T+10);for(const k of m.pool){const [x,y]=k.split(',').map(Number);g.fillStyle=(x+y)%2?'#4fb6e0':'#45a9d6';g.fillRect(x*T-16,y*T-16,T,T);g.fillStyle='rgba(255,255,255,.18)';g.fillRect(x*T-16,y*T-16,T,1)}}}
  m.exits.push({id:'e',x:m.w*T-14,y:12*T,to:'plaza',toExit:'w',label:'plaza'},{id:'s',x:16.5*T,y:m.h*T-8,to:'lake',toExit:'n',label:'lake'},{id:'door',x:10*T+16,y:9*T+18,to:'room',toExit:'door',label:'room'});m.spawnDefault=[30*T,12*T];return m}
// ---------- Market Street (Granny Nuan's shop, stalls) ----------
function buildMarket(){SEED=41;const m=newMap('market','town',34,22,41);m.nameKey='market';
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)m.COBBLE.add(key(x,y))};pr(0,11,33,12);pr(9,9,11,10);pr(22,13,23,16);
  m.objs.push({img:'bld',sx:131,sy:1,sw:128,sh:128,x:10*T+16,y:9*T+2,tall:1,cs:.45});for(let x=8;x<=13;x++)for(let y=6;y<=8;y++)m.SOLID.add(key(x,y));
  addNpc(m,'nuan',11,10,0);
  [[16,9],[20,9],[25,9],[17,14],[27,14]].forEach(([x,y])=>addProp(m,'stall',x,y));
  [['appleCrate',15,10],['fruitBasket',18,10],['vegBasket',19,10],['milkCan',21,10],['eggBasket',24,10],['pumpkins',26,10],['wheelbarrowPumpkin',29,10],['sunflower',14,9],['firewood',6,9],['hayBale',16,15],['pumpkins',18,15],['vegBasket',28,15],['appleCrate',26,15]].forEach(([k,x,y])=>addFarm(m,k,x,y));
  [[7,13],[13,13],[20,13],[30,13]].forEach(([x,y])=>addProp(m,'lamp',x,y));addProp(m,'bench',24,17,{tall:0,cs:.3});addProp(m,'bath',21,17,{tall:0,cs:.3});
  [['roundA',2,6],['roundB',4,16],['pink',9,18],['roundA',13,20],['frangi',19,20],['roundB',31,5],['roundA',32,18],['mango',28,20],['banana',3,10],['palm',31,9],['roundB',26,3],['roundA',17,4]].forEach(a=>addTree(m,...a));
  addDeco(m,'flowers',12,14,0);addDeco(m,'flowers',29,16,0);addDeco(m,'bush',15,17,1);
  m.exits.push({id:'w',x:14,y:12*T,to:'plaza',toExit:'e',label:'plaza'},{id:'e',x:m.w*T-14,y:12*T,locked:1,label:'forestSoon',msg:'forestMsg'});m.spawnDefault=[3*T,12*T];return m}
// ---------- Lakeside (lake, pier without a boat, the Coral Grotto still closed) ----------
function buildLake(){SEED=53;const m=newMap('lake','town',34,22,53);m.nameKey='lake';
  for(let y=0;y<m.h+1;y++)for(let x=-1;x<m.w+1;x++){const dx=(x-13)/11,dy=(y-17)/7;if(dx*dx+dy*dy<1||y>=m.h-1&&x<26)m.WATER.add(key(x,y))}
  for(let x=24;x<=31;x++)for(let y=0;y<=6+Math.round(Math.sin(x*1.3)*.8);y++)m.CLIFF.add(key(x,y));
  const pr=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)m.PATH.add(key(x,y))};pr(16,0,17,8);pr(12,8,28,9);pr(27,8,28,8);
  m.WATER.forEach(k=>m.SOLID.add(k));m.CLIFF.forEach(k=>m.SOLID.add(k));
  const px=13;for(let y=10;y<=13;y++)for(const x of [px-1,px]){m.SOLID.delete(key(x,y))}m.decks.push({img:'pier',x:px*T,y:9*T+8,oy:0});
  m.fishSpot={x:px*T-16,y:13*T+10,wx:px*T-16,wy:15*T+8};
  m.objs.push({img:'caveDoor',sx:0,sy:0,sw:128,sh:128,x:27.5*T,y:8*T-14,flat:1});m.SOLID.add(key(26,7));m.SOLID.add(key(29,7));
  [['palm',4,4],['palm',8,6],['roundA',2,9],['bananaB',30,11],['palm',32,14],['roundB',20,3],['frangi',22,11],['pink',6,2],['roundA',11,3],['palm',30,19]].forEach(a=>addTree(m,...a));
  addDeco(m,'rocks',23,12,0);addDeco(m,'mossRock',25,10,0);addDeco(m,'flowers',18,6,0);addDeco(m,'grass',9,9,0);addDeco(m,'fern',21,7,0);addDeco(m,'boulder',32,8,1);
  m.exits.push({id:'n',x:16.5*T,y:12,to:'home',toExit:'s',label:'home'},{id:'cave',x:27.5*T,y:8*T+18,locked:1,label:'coralSoon',msg:'coralMsg'});m.spawnDefault=[16.5*T,4*T];return m}
// ---------- our home inside (decorate, shared by the family on this device) ----------
const FU={bed:[0,0,60],table:[1,0,40],chair:[2,0,20],lamp:[3,0,25],rug:[0,1,30],plant:[1,1,15],shelf:[2,1,50],sofa:[3,1,60],toy:[0,2,35],cab:[1,2,70]},FLAT={rug:1};
const HSZ=[[14,10],[18,11],[22,12]];
let VISIT=null; // {owner,name,data:{lv,rooms}} while visiting a friend's home
function houseLv(h=HOME.get()){if(!h.lv){h.lv=(h.floors||1)>=3?7:(h.floors||1)>=2?5:(h.size||1)>=3?3:(h.size||1)>=2?2:1;HOME.put(h)}return h.lv}
function cfgFor(lv){return{lv,size:lv>=3?3:lv>=2?2:1,floors:lv>=7?3:lv>=5?2:1}}
function houseCfg(){return VISIT?cfgFor(VISIT.data.lv||1):cfgFor(houseLv())}
function floorLayout(fl){return VISIT?((VISIT.data.rooms||{})[fl]||[]):roomLayout(fl)}
function roomLayout(fl){const h=HOME.get();h.rooms=h.rooms||{};if(fl===1&&h.room&&!h.rooms[1]){h.rooms[1]=h.room;HOME.put(h)}return h.rooms[fl]||[]}
function buildRoom(layout,fl=1,cfg=houseCfg()){const [W,H]=HSZ[Math.min(3,cfg.size)-1],id=fl===1?'room':'room'+fl;SEED=61+fl;const m=newMap(id,'room',W,H,61+fl);m.nameKey='room';m.floor=fl;m.indoor=true;
  const cx=Math.floor(W/2);for(let y=3;y<=H-2;y++)for(let x=1;x<=W-2;x++)m.FLOOR.add(key(x,y));
  if(fl===1){m.FLOOR.add(key(cx,H-1));for(let y=3;y<=H-2;y++)if(y!==H-3)m.FLOOR.delete(key(5,y));m.bath={x0:1,x1:4,y0:3,y1:H-2};
    m.paint=g=>{for(let y=3;y<=H-2;y++)for(let x=1;x<=4;x++){g.fillStyle=(x+y)%2?'#dfe9ee':'#b9d3dd';g.fillRect(x*T-16+1,y*T-16+1,T-2,T-2);g.fillStyle='rgba(120,150,165,.35)';g.fillRect(x*T-16,y*T-16,T,1);g.fillRect(x*T-16,y*T-16,1,T)}}}
  for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++)if(!m.FLOOR.has(key(x,y)))m.SOLID.add(key(x,y));
  for(const wx of fl===1?[cx-2,cx+3]:[cx-3,cx+2])m.objs.push({img:'furn',sx:133,sy:133,sw:64,sh:64,x:wx*T,y:3*T-6,flat:1});
  if(fl===1)m.objs.push({img:'furn',sx:199,sy:133,sw:64,sh:64,x:cx*T+16,y:(H-1)*T+30,flat:1});
  m.fixed=m.objs.length;m.stairs=[];
  if(fl<cfg.floors){m.stairs.push({x:(W-3)*T+16,y:(H-4)*T+16,up:1});m.exits.push({id:'up',x:(W-3)*T+16,y:(H-4)*T+16,to:'room'+(fl+1),toExit:'down',label:'up'})}
  if(fl>1){m.stairs.push({x:2*T+16,y:(H-4)*T+16,up:0});m.exits.push({id:'down',x:2*T+16,y:(H-4)*T+16,to:fl===2?'room':'room'+(fl-1),toExit:'up',label:'down'})}
  if(fl===1)m.exits.push({id:'door',x:cx*T+16,y:(H-1)*T+10,to:'home',toExit:'door',label:'home'});
  const Z=[],lv=cfg.lv||1,z=(x0,y0,x1,y1,k,c1,c2)=>Z.push({x0,y0,x1,y1,k,c1,c2});
  if(fl===1){if(lv>=2)z(W-6,3,W-2,5,'z_kitchen','#efe3c8','#dccaa4');if(lv>=3)z(6,3,9,5,'z_bed','#9fb8d8','#8faacb');if(lv>=4)z(6,H-2,W-2,H-2,'z_porch','#b98a5a','#a67a4c')}
  if(fl===2){z(1,3,6,6,'z_kids','#f3d6e4','#ecc6d8');z(W-5,3,W-2,5,'z_bath2','#cfe6d2','#b6d9bc');if(lv>=6)z(1,H-5,5,H-2,'z_read','#cfe0b8','#bfd4a6')}
  if(fl===3){if(lv>=7)z(W-8,3,W-2,7,'z_star','#28305a','#222a4e');if(lv>=8){z(2,4,8,8,'z_balls','#fff','#fff');m.balls={x0:2,y0:4,x1:8,y1:8}}}
  m.zones=Z;const oldPaint=m.paint;m.paint=g=>{if(oldPaint)oldPaint(g);for(const q of Z){for(let y=q.y0;y<=q.y1;y++)for(let x=q.x0;x<=q.x1;x++){if(!m.FLOOR.has(key(x,y)))continue;const X=x*T-16,Y=y*T-16;
      if(q.k==='z_balls'){g.fillStyle='#fdf6e8';g.fillRect(X,Y,T,T);const r=seeded(x*31+y*7);for(let i=0;i<14;i++){g.fillStyle=['#ffb3d9','#ffe36b','#9fd8ff','#a8f0a0','#ffc38a'][Math.floor(r()*5)];const bx=X+2+Math.floor(r()*26),by=Y+2+Math.floor(r()*26);g.fillRect(bx,by,5,5);g.fillStyle='rgba(255,255,255,.7)';g.fillRect(bx+1,by+1,2,1)}continue}
      g.fillStyle=(x+y)%2?q.c1:q.c2;g.fillRect(X+1,Y+1,T-2,T-2);if(q.k==='z_star'&&((x*7+y*13)%5===0)){g.fillStyle='#fff6c0';g.fillRect(X+10,Y+12,2,2)}}}};
  if(VISIT)m.visiting=VISIT.name;
  m.layout=layout||[];placeFurniture(m);m.spawnDefault=fl===1?[cx*T+16,(H-2)*T+10]:[4*T+16,(H-3)*T+10];return m}
function placeFurniture(m){m.objs.length=m.fixed;m.SOLID.forEach(k=>{if(m.FLOOR.has(k))m.SOLID.delete(k)});
  for(const f of m.layout){const r=FU[f.k];if(!r||!m.FLOOR.has(key(f.tx,f.ty)))continue;const o={img:'furn',sx:r[0]*66+1,sy:r[1]*66+1,sw:64,sh:64,x:f.tx*T+16,y:f.ty*T+28,tall:FLAT[f.k]?0:1,flat:!!FLAT[f.k],cs:.4,fu:f,flip:!!f.fl};if(IMG.furn)measure(o);else{o.cb=63;o.foot=20;o.fx=0;o.a=1}m.objs.push(o);if(!FLAT[f.k])m.SOLID.add(key(f.tx,f.ty))}}
function dreamCfg(n){const id='dream'+n;if(CAVE_CFG[id])return;const k=Math.min(n,12),mod=n%5===0?'boss':['calm','dark','treasure','house','calm','dark','treasure','house'][(n*7+3)%8],hm=mod==='house'?2:1;CAVE_CFG[id]={gw:3+Math.min(2,Math.floor(n/5)),gh:3,branch:mod==='treasure'?3:2,mod,bossEl:n%15===5?'ice':n%15===10?'fire':n%15===0?'storm':null,seed:5000+n*37,w:34+k,h:24+Math.floor(k/2),rooms:7+Math.floor(k/3),crystals:3,digs:mod==='treasure'?9:4,mons:[['slime',(3+Math.floor(n/3))*hm],['bat',(2+Math.floor(n/4))*hm],['mushbug',(2+Math.floor(n/3))*hm]],next:'dream'+(n+1),boss:n%5===0,up:n===1?'cave3':'dream'+(n-1),upExit:n===1?'dream':'down',mul:2.3+.35*n};
  const C=CAVE_CFG[id],suf=k2=>C.mod!=='calm'&&C.mod!=='boss'?' · '+TX[k2]['mod_'+C.mod]:'';TX.th[id]=TX.th.dream+' · ชั้น '+n+suf('th');TX.en[id]=TX.en.dream+' · Floor '+n+suf('en');MAPS[id]=()=>buildCave(id)}
const MAPS={room:()=>buildRoom(floorLayout(1),1),room2:()=>buildRoom(floorLayout(2),2),room3:()=>buildRoom(floorLayout(3),3),market:buildMarket,lake:buildLake,home:buildHome,plaza:buildPlaza,mountain:buildMountain,cave1:()=>buildCave('cave1'),cave2:()=>buildCave('cave2'),cave3:()=>buildCave('cave3')};
