// ===== engine =====
const WANG=__WANG__;
const cv=document.getElementById('c'),ctx=cv.getContext('2d'),vig=document.getElementById('vig');
let VW=0,VH=0,SC=1,camX=0,camY=0,LITE=false;
const key=(x,y)=>x+','+y;
function resize(){const dpr=devicePixelRatio||1,dw=Math.round(innerWidth*dpr),dh=Math.round(innerHeight*dpr);SC=Math.max(1,Math.round(dh/384));VW=Math.ceil(dw/SC);VH=Math.ceil(dh/SC);cv.width=VW*SC;cv.height=VH*SC;cv.style.width=(VW*SC/dpr)+'px';cv.style.height=(VH*SC/dpr)+'px';if(M)M.shadowSC=0}
addEventListener('resize',resize);
function checkRot(){const el=document.getElementById('rot');if(!el)return;const port=innerHeight>innerWidth*1.1&&Math.min(innerWidth,innerHeight)<820;el.classList.toggle('hide',!port)}addEventListener('resize',checkRot);addEventListener('orientationchange',checkRot);
let SEED=1;const rnd=()=>(SEED=(SEED*16807)%2147483647)/2147483647;
function seeded(s){let v=s%2147483647||1;return()=>(v=(v*16807)%2147483647)/2147483647}

// --- ground: Wang tiles on a half-tile offset grid (a tile's 4 corners = 4 map cells) ---
function wangLayer(g,im,isA,w,h,only,seed){const r=seeded(seed||7);
  for(let y=0;y<=h;y++)for(let x=0;x<=w;x++){const k=[[x-1,y-1],[x,y-1],[x-1,y],[x,y]].map(([a,b])=>isA(a,b)?'A':'B').join('');if(only&&!k.includes('A'))continue;
    const [tx,ty]=WANG[k][Math.floor(r()*WANG[k].length)];
    if(!im){g.fillStyle=k==='BBBB'?'#4c8a3e':'#c9a46a';g.fillRect(x*T-16,y*T-16,T,T);continue}
    if(k==='BBBB'&&r()<.5){g.save();g.translate(x*T-16+T,y*T-16);g.scale(-1,1);g.drawImage(im,tx*T,ty*T,T,T,0,0,T,T);g.restore()}else g.drawImage(im,tx*T,ty*T,T,T,x*T-16,y*T-16,T,T)}}
function grassDecor(g,m){const r=seeded(m.seed+3);for(let i=0;i<m.w*m.h*.45;i++){const x=Math.floor(r()*m.w*T),y=Math.floor(r()*m.h*T),c=key(Math.floor(x/T),Math.floor(y/T));
  if(m.PATH.has(c)||m.WATER.has(c)||m.CLIFF.has(c)||m.COBBLE.has(c)||m.kind==='cave')continue;const k=r();
  if(k<.35){g.fillStyle='rgba(30,70,30,.16)';for(let j=0;j<18;j++)g.fillRect(x+Math.floor(r()*14)-7,y+Math.floor(r()*8)-4,1,1)}
  else if(k<.85){g.fillStyle='#3d7a3a';g.fillRect(x,y,1,3);g.fillRect(x+2,y+1,1,2);g.fillStyle='#8fd06a';g.fillRect(x+1,y-1,1,3)}
  else{g.fillStyle=['#fff6d8','#ffd6e6','#fff0a0'][Math.floor(r()*3)];g.fillRect(x,y,1,1);g.fillStyle='#3d7a3a';g.fillRect(x,y+1,1,1)}}}
function buildGround(m){const c=document.createElement('canvas');c.width=m.w*T;c.height=m.h*T;const g=c.getContext('2d');g.imageSmoothingEnabled=false;
  if(m.kind==='cave'){wangLayer(g,IMG.caveCalm||null,(x,y)=>m.FLOOR.has(key(x,y)),m.w,m.h,false,m.seed)}
  else if(m.kind==='room'){wangLayer(g,IMG.house||null,(x,y)=>m.FLOOR.has(key(x,y)),m.w,m.h,false,m.seed)}
  else{wangLayer(g,IMG.ground||null,(x,y)=>m.PATH.has(key(x,y)),m.w,m.h,false,m.seed);
    if(m.COBBLE.size)wangLayer(g,IMG.cobble||null,(x,y)=>m.COBBLE.has(key(x,y)),m.w,m.h,true,m.seed+1);
    if(m.WATER.size)wangLayer(g,IMG.water||null,(x,y)=>m.WATER.has(key(x,y)),m.w,m.h,true,m.seed+2);
    if(m.CLIFF.size)wangLayer(g,IMG.cliff||null,(x,y)=>m.CLIFF.has(key(x,y)),m.w,m.h,true,m.seed+4);grassDecor(g,m)}
  if(m.paint)m.paint(g);m.ground=c}

// --- sprites: measure the real foot line of each picture, make a silhouette for shadows ---
function measure(o){const im=IMG[o.img];if(!im){o.cb=o.sh-1;o.foot=16;o.fx=0;o.a=1;return}const c=document.createElement('canvas');c.width=o.sw;c.height=o.sh;const g=c.getContext('2d');g.drawImage(im,o.sx,o.sy,o.sw,o.sh,0,0,o.sw,o.sh);
  const d=g.getImageData(0,0,o.sw,o.sh).data,A=(x,y)=>d[(y*o.sw+x)*4+3]>40;let cb=o.sh-1;const row=y=>{for(let x=0;x<o.sw;x++)if(A(x,y))return 1;return 0};while(cb>0&&!row(cb))cb--;
  let x0=o.sw,x1=0;for(let y=Math.max(0,cb-5);y<=cb;y++)for(let x=0;x<o.sw;x++)if(A(x,y)){x0=Math.min(x0,x);x1=Math.max(x1,x)}
  o.cb=cb;o.foot=Math.max(8,x1-x0+1);o.fx=(x0+x1)/2-o.sw/2;g.globalCompositeOperation='source-in';g.fillStyle='#0e1a10';g.fillRect(0,0,o.sw,o.sh);o.sil=c;o.a=1}
function silOf(im){const c=document.createElement('canvas');c.width=im.width;c.height=im.height;const g=c.getContext('2d');g.drawImage(im,0,0);g.globalCompositeOperation='source-in';g.fillStyle='#0e1a10';g.fillRect(0,0,c.width,c.height);return c}
function softAO(c,x,y,w,a){const h=Math.max(3,w/3.4);c.save();c.translate(x,y);c.scale(1,h/w);const g=c.createRadialGradient(0,0,0,0,0,w/2);g.addColorStop(0,`rgba(10,20,26,${a})`);g.addColorStop(.6,`rgba(10,20,26,${a*.55})`);g.addColorStop(1,'rgba(10,20,26,0)');c.fillStyle=g;c.beginPath();c.arc(0,0,w/2,0,7);c.fill();c.restore()}
// Trickster-style shadows: cast backwards and leaning right, merged into one soft layer, baked with the ground once per map
// shadows baked once per map at 1x into a soft mask (small, fast); the ground stays 1x too. Both are scaled up only for the part on screen.
function bakeShadows(m){const Wp=m.w*T,Hp=m.h*T,mk=document.createElement('canvas');mk.width=Wp;mk.height=Hp;const g=mk.getContext('2d');g.imageSmoothingEnabled=true;const k=.55;
  for(const o of m.objs){if(!o.sil||o.flat)continue;const sh=o.cs||.45,h=o.cb+1,X=Math.round(o.x-o.sw/2),Y=Math.round(o.y);
    if(!o.small)for(let r=0;r<h;r+=2){g.globalAlpha=.3+.7*Math.pow(r/h,1.4);g.setTransform(1,0,-k,sh,X+k*h,Y-sh*h);g.drawImage(o.sil,0,r,o.sw,2,0,r,o.sw,2)}
    g.setTransform(1,0,0,1,0,0);g.globalAlpha=1;softAO(g,o.x+o.fx,o.y,o.foot*(o.small?1.1:1.25),o.small?.7:1)}
  const f=document.createElement('canvas');f.width=Wp;f.height=Hp;const q=f.getContext('2d');q.filter='blur(2.5px)';q.drawImage(mk,0,0);q.filter='none';q.globalCompositeOperation='source-in';q.fillStyle=m.kind==='cave'?'rgb(66,54,108)':'rgb(88,78,130)'; // LA dusk-violet shadows everywhere (ART_DIRECTION 30%)q.fillRect(0,0,Wp,Hp);
  const gh=document.createElement('canvas');gh.width=Wp;gh.height=Hp;const hc=gh.getContext('2d');hc.drawImage(m.ground,0,0);hc.globalCompositeOperation='multiply';hc.drawImage(f,0,0);m.shadow=gh;m.shadowSC=SC}
function blitMap(img,smooth,op){let sx=camX,sy=camY,dx=0,dy=0,w=VW,h=VH;if(sx<0){dx=-sx;w+=sx;sx=0}if(sy<0){dy=-sy;h+=sy;sy=0}w=Math.min(w,img.width-sx);h=Math.min(h,img.height-sy);if(w<=0||h<=0)return;
  ctx.imageSmoothingEnabled=smooth;if(op)ctx.globalCompositeOperation=op;ctx.drawImage(img,sx,sy,w,h,dx*SC,dy*SC,w*SC,h*SC);ctx.globalCompositeOperation='source-over'}
function drawObj(o,tm){if(o.needBoss&&!(S&&S.boss))return;const im=o.pick?o.pick():IMG[o.img];const X=Math.round(o.x-o.sw/2-camX),Y=Math.round(o.y-(o.cb+1)-camY);if(X>VW||Y>VH||X+o.sw<0||Y+o.sh<0)return;ctx.globalAlpha=o.a;
  if(!im){ctx.fillStyle=o.col||'#6b8a4a';ctx.fillRect(X+o.sw/2-8,Y+o.sh-20,16,20);ctx.globalAlpha=1;return}
  if(o.sway){const a=Math.sin(tm*1.3+o.ph)*1.6;for(let r=0;r<o.sh;r+=4){const kk=1-r/o.sh,dx=Math.round(a*kk*kk);ctx.drawImage(im,o.sx,o.sy+r,o.sw,4,X+dx,Y+r,o.sw,4)}}
  else if(o.flip){ctx.save();ctx.translate(X+o.sw,Y);ctx.scale(-1,1);ctx.drawImage(im,o.sx,o.sy,o.sw,o.sh,0,0,o.sw,o.sh);ctx.restore()}
  else ctx.drawImage(im,o.sx,o.sy,o.sw,o.sh,X,Y,o.sw,o.sh);ctx.globalAlpha=1}
function label(x,y,s,col){ctx.save();ctx.font='bold 8px system-ui,sans-serif';const w=ctx.measureText(s).width+8;ctx.fillStyle='rgba(27,19,48,.88)';ctx.fillRect(Math.round(x-w/2),Math.round(y-9),Math.round(w),11);ctx.fillStyle=col||'#a8793a';ctx.fillRect(Math.round(x-w/2),Math.round(y+2),Math.round(w),1);ctx.fillStyle='#fff3d6';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(s,x,y-3);ctx.restore()}
function ring(x,y,tm,power,col){ctx.save();ctx.globalCompositeOperation='lighter';const c=col||'150,240,255';for(let i=0;i<2;i++){ctx.strokeStyle=`rgba(${c},${(.35+.45*power)*(i?.7:1)})`;ctx.lineWidth=i?1:1.5;ctx.setLineDash(i?[3,4]:[8,3]);ctx.lineDashOffset=(i?-1:1)*tm*12;ctx.beginPath();ctx.ellipse(x,y,i?11:17,i?5:8,0,0,7);ctx.stroke()}
  ctx.setLineDash([]);const g=ctx.createRadialGradient(x,y,0,x,y,18);g.addColorStop(0,`rgba(${c},${.18+.3*power})`);g.addColorStop(1,`rgba(${c},0)`);ctx.fillStyle=g;ctx.fillRect(x-18,y-18,36,36);
  for(let i=0;i<5;i++){const a=tm*1.3+i*1.26,py=y-((tm*14+i*7)%26);ctx.fillStyle='rgba(230,252,255,.8)';ctx.fillRect(Math.round(x+Math.cos(a)*10),Math.round(py),1,1)}ctx.restore()}
function glow(x,y,r,rgb,a){const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,`rgba(${rgb},${a})`);g.addColorStop(1,`rgba(${rgb},0)`);ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2)}

// --- walking: A* on the tile grid, then straighten the path where the line is clear ---
function walkable(m,tx,ty){return tx>=0&&ty>=0&&tx<m.w&&ty<m.h&&!m.SOLID.has(key(tx,ty))}
function findPath(m,sx,sy,gx,gy){let [ax,ay]=[Math.floor(sx/T),Math.floor(sy/T)],[bx,by]=[Math.floor(gx/T),Math.floor(gy/T)];
  if(!walkable(m,bx,by)){let best=null,bd=1e9;for(let r=1;r<4&&!best;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const x=bx+dx,y=by+dy;if(walkable(m,x,y)){const d=Math.hypot(dx,dy);if(d<bd){bd=d;best=[x,y]}}}if(!best)return null;[bx,by]=best;gx=bx*T+16;gy=by*T+16}
  if(ax===bx&&ay===by)return[[gx,gy]];
  const W=m.w,start=ay*W+ax,goal=by*W+bx,g=new Map([[start,0]]),came=new Map(),open=[[0,start]];let n=0;
  const hh=(i)=>{const x=i%W,y=(i/W)|0,dx=Math.abs(x-bx),dy=Math.abs(y-by);return Math.max(dx,dy)+.414*Math.min(dx,dy)};
  while(open.length&&n++<6000){let bi=0;for(let i=1;i<open.length;i++)if(open[i][0]<open[bi][0])bi=i;const [,cur]=open.splice(bi,1)[0];if(cur===goal)break;const cx=cur%W,cy=(cur/W)|0;
    for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const nx=cx+dx,ny=cy+dy;if(!walkable(m,nx,ny))continue;if(dx&&dy&&(!walkable(m,cx+dx,cy)||!walkable(m,cx,cy+dy)))continue;
      const ni=ny*W+nx,ng=g.get(cur)+(dx&&dy?1.414:1);if(ng<(g.has(ni)?g.get(ni):1e9)){g.set(ni,ng);came.set(ni,cur);open.push([ng+hh(ni),ni])}}}
  if(!came.has(goal))return null;const cells=[];let c=goal;while(c!==start){cells.push(c);c=came.get(c)}cells.reverse();
  const pts=cells.map(i=>[(i%W)*T+16,((i/W)|0)*T+16]);pts[pts.length-1]=[gx,gy];
  const out=[];let from=[sx,sy],i=0;while(i<pts.length){let j=pts.length-1;while(j>i&&!clearLine(m,from,pts[j]))j--;out.push(pts[j]);from=pts[j];i=j+1}return out}
function clearLine(m,a,b){const d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.ceil(d/6);for(let i=1;i<=n;i++){const x=a[0]+(b[0]-a[0])*i/n,y=a[1]+(b[1]-a[1])*i/n;if(blockedAt(m,x,y))return false}return true}
function blockedAt(m,x,y){if(x<5||y<5||x>m.w*T-5||y>m.h*T-3)return true;for(const [dx,dy] of [[-5,0],[5,0],[0,-3],[0,2]])if(m.SOLID.has(key(Math.floor((x+dx)/T),Math.floor((y+dy)/T))))return true;return false}

// --- minimap (top right, like RO) ---
const mm=document.getElementById('mm'),mc=mm.getContext('2d');let mmBase=null,MMS=3;
function makeMinimap(m){MMS=Math.max(2,Math.min(4,Math.floor(130/m.w)));mm.width=m.w*MMS;mm.height=m.h*MMS;mm.style.width=mm.width+'px';mm.style.height=mm.height+'px';mmBase=document.createElement('canvas');mmBase.width=mm.width;mmBase.height=mm.height;const g=mmBase.getContext('2d');
  for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){const k=key(x,y);g.fillStyle=m.kind==='cave'?(m.FLOOR.has(k)?'#8a6a4a':'#3b3050'):m.kind==='room'?(m.FLOOR.has(k)?'#c98a4a':'#e8dcc0'):m.CLIFF.has(k)?'#6b6384':m.WATER.has(k)&&(m.PATH.has(k)||m.COBBLE.has(k))?'#a0703a':m.WATER.has(k)?'#3aa7c2':m.COBBLE.has(k)?'#cfc2a8':m.PATH.has(k)?'#d8b879':'#4c8a3e';g.fillRect(x*MMS,y*MMS,MMS,MMS)}
  for(const o of m.objs)if(o.sway){g.fillStyle='#24502a';g.fillRect(Math.floor(o.x/T)*MMS,Math.floor(o.y/T)*MMS,MMS,MMS)}
  for(const b of m.blocks||[]){g.strokeStyle='#e0413b';g.lineWidth=1.5;const x=b.x/T*MMS,y=b.y/T*MMS;g.beginPath();g.moveTo(x-3,y-3);g.lineTo(x+3,y+3);g.moveTo(x+3,y-3);g.lineTo(x-3,y+3);g.stroke()}}
function drawMinimap(tm){if(!mmBase)return;mc.drawImage(mmBase,0,0);
  if(M.kind==='cave'&&M.seen){if(!M.fog||M.fogDirty){M.fog=M.fog||document.createElement('canvas');M.fog.width=mm.width;M.fog.height=mm.height;const fg=M.fog.getContext('2d');fg.fillStyle='rgba(12,8,22,.92)';for(let y=0;y<M.h;y++)for(let x=0;x<M.w;x++)if(!M.seen.has(key(x,y)))fg.fillRect(x*MMS,y*MMS,MMS,MMS);M.fogDirty=0}mc.drawImage(M.fog,0,0)}
  for(const e of M.exits){if(M.seen&&!M.seen.has(key(Math.floor(e.x/T),Math.floor(e.y/T))))continue;mc.fillStyle=e.locked?'#e0413b':'#8ff4ff';mc.fillRect(e.x/T*MMS-2,e.y/T*MMS-2,4,4)}
  for(const s of M.stones){mc.fillStyle=s.awake?'#8ff4ff':'#9aa0a8';mc.fillRect(s.x/T*MMS-2,s.y/T*MMS-3,4,4)}
  for(const c of M.crystals||[])if(c.awake){mc.fillStyle='#5fe0ff';mc.fillRect(c.x/T*MMS-1,c.y/T*MMS-1,3,3)}
  if(M.boss&&!M.boss.gone){mc.fillStyle='#ff5a8a';mc.fillRect(M.boss.x/T*MMS-3,M.boss.y/T*MMS-3,6,6)}
  if(Math.floor(tm*3)%2===0||P.moving){const x=P.x/T*MMS,y=P.y/T*MMS,a=DIR_ANG[P.row];mc.save();mc.translate(x,y);mc.rotate(a);mc.fillStyle='#fff';mc.strokeStyle='#1b1330';mc.lineWidth=1;mc.beginPath();mc.moveTo(5,0);mc.lineTo(-3,-3.5);mc.lineTo(-1.5,0);mc.lineTo(-3,3.5);mc.closePath();mc.fill();mc.stroke();mc.restore()}}
// sprite rows: 0 S,1 SE,2 E,3 NE,4 N,5 NW,6 W,7 SW
const DIR_ANG=[Math.PI/2,Math.PI/4,0,-Math.PI/4,-Math.PI/2,-3*Math.PI/4,Math.PI,3*Math.PI/4];
const rowFor=(dx,dy)=>[2,1,0,7,6,5,4,3][((Math.round(Math.atan2(dy,dx)/(Math.PI/4))%8)+8)%8];
