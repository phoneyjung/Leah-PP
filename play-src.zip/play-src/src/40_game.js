// ===== game state =====
let M=null,LIGHT=.35,PAUSE=false;const CACHE={};
const P={x:0,y:0,row:0,moving:false,dist:0,path:null,target:null,act:null,cd:0,hurt:0,dizzy:0,atkAnim:0};
let S=null; // saved profile + progress
const Store={key:'leahpp2d-slots',old:'leahpp2d-v1',all(){try{let d=JSON.parse(localStorage.getItem(this.key)||'null');if(!d){const o=JSON.parse(localStorage.getItem(this.old)||'null');d={v:2,slots:o?[o]:[],cur:o?0:-1}}return d}catch(e){return{v:2,slots:[],cur:-1}}},
  put(d){try{localStorage.setItem(this.key,JSON.stringify(d))}catch(e){}},save(s){const d=this.all();if(d.cur<0||!d.slots[d.cur]){d.slots.push(s);d.cur=d.slots.length-1}else d.slots[d.cur]=s;this.put(d)},
  load(){const d=this.all();return d.cur>=0?d.slots[d.cur]:null},clear(){const d=this.all();if(d.cur>=0)d.slots.splice(d.cur,1);d.cur=-1;this.put(d)}};
// ---- today's quests (board in the plaza) ----
const today=()=>new Date().toISOString().slice(0,10);
const QPOOL={kid:[['wake',2],['quiz',3],['dig',2],['fish',1],['plant',1],['harvest',1],['feed',1],['deco',1]],adult:[['help',6],['dig',2],['fish',2],['cook',1],['wake',1],['quiz',2],['dream',1],['feed',1]]};
const weekKey=()=>{const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()+3-(d.getDay()+6)%7);const w1=new Date(d.getFullYear(),0,4);return d.getFullYear()+'-W'+(1+Math.round(((d-w1)/864e5-3+(w1.getDay()+6)%7)/7))};
function ensureDaily(){if(!S.weekly||S.weekly.wk!==weekKey()){const W=isKid()?[['wake',12],['quiz',25],['dig',10]]:[['help',60],['dig',12],['quiz',15]];const r=seeded(weekKey().length*97+weekKey().charCodeAt(6)+(S.name||'').length);const [k,n]=W[Math.floor(r()*W.length)];S.weekly={wk:weekKey(),k,n,got:0,claimed:false}}
  if(S.daily&&S.daily.date===today())return;const pool=[...QPOOL[isKid()?'kid':'adult']],r=seeded(Math.floor(Date.now()/864e5)*7+(S.name||'x').charCodeAt(0));const L=[];while(L.length<4&&pool.length)L.push(pool.splice(Math.floor(r()*pool.length),1)[0]);
  if(isKid()&&!L.some(q=>q[0]==='wake'))L[0]=['wake',2];S.daily={date:today(),seen:false,list:L.map(([k,n])=>({k,n,got:0,claimed:false}))};save()}
function mission(k,n=1){if(!S||!S.daily)return;let done=false;const W=S.weekly;if(W&&W.k===k&&W.got<W.n){W.got=Math.min(W.n,W.got+n);if(W.got>=W.n){sfx('lvl');say('📜 '+t('weekly')+' ✓')}}for(const q of S.daily.list)if(q.k===k&&q.got<q.n){q.got=Math.min(q.n,q.got+n);if(q.got>=q.n)done=true}if(done){sfx('right');say('📜 '+t('m_'+k)+' ✓')}}
function bookAdd(q){const L=q[LANG]||q.th;S.book=S.book||[];if(S.book.some(b=>b.id===q.id))return;S.book.unshift({id:q.id,sub:q.subject,lang:LANG,q:L.q,a:L.choices[q.answer],ex:L.explain||''});if(S.book.length>300)S.book.pop()}
const isKid=()=>S&&S.age<12;
function newSave(p){return{v:1,snd:true,st:{str:1,agi:1,vit:1,int:1,dex:1},cards:[],cardBook:[],name:p.name,kid:p.kid,house:p.house,age:p.age,lang:LANG,lv:1,exp:0,hp:40,coins:0,gems:0,potions:1,
  inv:[mkItem('sw',0)],eq:0,crystals:{},digs:{},stones:['plaza'],lastStone:'plaza',boss:false,pos:{map:'plaza',x:18*T,y:7*T},asked:[]}}
let UID=1;const AFF=['str','agi','vit','int','dex','hpP','crit','aspd'];
const ARM_DEF=[3,5,8,12,10];function mkGear(slot,rar){const it=mkItem('sw',rar);delete it.atk;delete it.spd;it.type=slot;it.slot=slot;if(slot==='armor')it.def=ARM_DEF[rar]+(rar?Math.floor(Math.random()*3):0);else{const k=['str','agi','vit','int','dex'][Math.floor(Math.random()*5)];it.aff.push({k,v:2+rar*2})}return it}
const randItem=rar=>{const r=Math.random();return r<.2?mkGear('armor',rar):r<.35?mkGear('acc',rar):mkItem(['sw','bow','staff','dag'][Math.floor(Math.random()*4)],rar)};
function mkItem(type,rar){const base={sw:6,bow:5,staff:7,dag:4}[type],mul=[1,1.25,1.55,2,1.8][rar];const aff=[];const n=[0,1,2,3,2][rar];for(let i=0;i<n;i++){const k=AFF[Math.floor(Math.random()*AFF.length)],v=1+Math.floor(Math.random()*(2+rar*1.5));const e=aff.find(a=>a.k===k);if(e)e.v+=v;else aff.push({k,v})}
  const slots=rar===0?0:rar===1?(Math.random()<.5?1:0):rar===2?1:2;return{u:Date.now().toString(36)+(UID++),type,rar,atk:Math.round(base*mul+(rar?Math.floor(Math.random()*3):0)),spd:rar===4?1.2:1,aff,slots,cards:[]}}
const WEP={sw:{cd:.5,range:26,icon:'🗡️'},bow:{cd:.74,range:150,icon:'🏹'},staff:{cd:.8,range:120,icon:'🪄',splash:28},dag:{cd:.52,range:22,icon:'🔪'}};
const RAR_COL=['#f3efe6','#7fb6ff','#ffe36b','#ffb347','#7df28a'];
const weapon=()=>{const w=S.inv[S.eq];return w&&!w.slot?w:{type:'sw',rar:0,atk:4,spd:1}};const armorIt=()=>S.eqA>=0?S.inv[S.eqA]:null,accIt=()=>S.eqC>=0?S.inv[S.eqC]:null;
const worn=()=>[weapon(),armorIt(),accIt()].filter(Boolean);
const STATS=['str','agi','vit','int','dex'];
const CARDS={slime:{hpP:8},bat:{aspd:5},mushbug:{stun:10},golem:{vit:5,def:15,noKnock:1}},CAVE1_SET=['slime','bat','mushbug','golem'];
const statCost=v=>1+Math.floor(v/10),costTo=v=>{let c=0;for(let k=1;k<v;k++)c+=statCost(k);return c};
function fixSave(){if(S.eqA===undefined)S.eqA=-1;if(S.eqC===undefined)S.eqC=-1;S.st=S.st||{str:1,agi:1,vit:1,int:1,dex:1};S.cards=S.cards||[];S.cardBook=S.cardBook||[];(S.inv||[]).forEach(it=>{it.aff=it.aff||[];it.slots=it.slots??0;it.cards=it.cards||[]})}
const spLeft=()=>3*(S.lv-1)-STATS.reduce((a,k)=>a+costTo(S.st[k]),0);
function gear(){const g={str:0,agi:0,vit:0,int:0,dex:0,hpP:0,crit:0,aspd:0,def:0,stun:0,atkP:0};g.hpP+=petBonus('hpP')+buffV('hpP')+jobP('hpP');g.def+=buffV('def');g.crit+=jobP('crit');g.dex+=jobP('dex');g.atkP+=petBonus('atkP');
  for(const w of worn()){if(w.def)g.def+=w.def;for(const a of w.aff||[])g[a.k]=(g[a.k]||0)+a.v;for(const c of w.cards||[])for(const [k,v] of Object.entries(CARDS[c]||{}))g[k]=(g[k]||0)+v}const sets=worn().filter(w=>w.rar===4).length;if(sets>=2){g.hpP+=sets>=3?12:5;g.atkP+=sets>=3?12:5}return g}
const ST=k=>(S.st?S.st[k]:1)+gear()[k];
const hpMax=()=>Math.round((40+8*(S.lv-1)+ST('vit')*6)*(1+gear().hpP/100));
const MAIN={sw:['str'],dag:['str','agi'],bow:['dex'],staff:['int']};
const atkPow=()=>{const w=weapon(),ks=MAIN[w.type],m=ks.reduce((a,k)=>a+ST(k),0)/ks.length;return Math.round(((4+w.atk)*(1+m/40)+S.lv*1.5)*(1+(buffV('atkP')+gear().atkP)/100))};
const aspdMul=()=>Math.min(1.6,1+ST('agi')*.015+gear().aspd/100),critCh=()=>Math.min(.5,ST('dex')*.006+gear().crit/100+(hasSk('hawk')&&weapon().type==='bow'?.05:0)),fleeCh=()=>Math.min(.6,ST('agi')*.005+(effOn('evade')?.3:0)),defVal=()=>ST('vit')*.5+gear().def,cdrMul=()=>Math.max(.55,1-ST('int')*.01-buffV('cdr')/100-jobP('cdr')/100);
let SHAKE=0;function critHit(base,mo){const cr=Math.random()<critCh();if(cr){TXT.push({x:mo.x,y:mo.y-(mo.h||20)-16,s:t('crit'),c:'#ff9f43',t:0,big:1});SHAKE=.14;sfx('kill')}return Math.max(1,Math.round(base*(cr?(S.job==='hunter'?1.65:1.5):1)))}
const needExp=()=>Math.round(18*Math.pow(S.lv,1.45));
function save(){if(!S)return;if(M)S.pos={map:M.id,x:Math.round(P.x),y:Math.round(P.y)};S.lang=LANG;Store.save(S)}

// ---- player sprite sheets in house colour ----
const PS={};function buildPlayerSheets(){const k=KIDS[S.kid][0],H=HOUSES[S.house].h;
  PS.stand=IMG['s_'+k]?recolorKey(IMG['s_'+k],H):fakeSheet(8,1);PS.walk=IMG['w_'+k]?recolorKey(IMG['w_'+k],H):fakeSheet(6,8);PS.F=Math.round(PS.walk.height/8);PS.silS=silOf(PS.stand);PS.silW=silOf(PS.walk);PS.sc=0}
function blurSheet(sil){const c=document.createElement('canvas');c.width=sil.width*SC;c.height=sil.height*SC;const x=c.getContext('2d');x.imageSmoothingEnabled=true;x.filter=`blur(${Math.round(1.6*SC)}px)`;x.drawImage(sil,0,0,c.width,c.height);return c}

// ---- monsters: stand-in pixel art drawn in code until the PixelLab monsters arrive ----
function pix(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');draw(g);const d=g.getImageData(0,0,w,h),p=d.data,o=new Uint8ClampedArray(p);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(p[i+3])continue;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const X=x+dx,Y=y+dy;if(X<0||Y<0||X>=w||Y>=h)continue;if(p[(Y*w+X)*4+3]>0){o[i]=34;o[i+1]=22;o[i+2]=44;o[i+3]=255;break}}}
  g.putImageData(new ImageData(o,w,h),0,0);return c}
function eyes(g,x,y,happy,sz=1){g.fillStyle='#1b1330';if(happy){g.fillRect(x,y+1,2*sz,1);g.fillRect(x-1,y,1,1);g.fillRect(x+2*sz,y,1,1);g.fillRect(x+6*sz,y+1,2*sz,1);g.fillRect(x+5*sz,y,1,1);g.fillRect(x+8*sz,y,1,1)}
  else{for(const ox of [0,6*sz]){g.fillRect(x+ox,y-1,3,1);g.fillRect(x+ox+2,y,1,2);g.fillRect(x+ox,y+1,2,1);g.fillRect(x+ox,y,1,1)}}}
const MON_ART={};function monArt(){const body=(col,dark)=>[col,dark];
  for(const happy of [0,1]){
    MON_ART['slime'+happy]=[0,1].map(f=>pix(26,22,g=>{const [c,d]=happy?['#ffb3d9','#e37fb4']:['#8f86a8','#6d6488'];g.fillStyle=d;g.fillRect(3,8+f,20,13-f);g.fillRect(6,5+f,14,4);g.fillStyle=c;g.fillRect(4,8+f,18,11-f);g.fillRect(7,6+f,12,3);g.fillStyle='rgba(255,255,255,.7)';g.fillRect(7,8+f,3,2);eyes(g,8,13,happy)}));
    MON_ART['bat'+happy]=[0,1].map(f=>pix(30,20,g=>{const [c,d]=happy?['#cdb6ff','#9f86e0']:['#7c7394','#5c5474'];g.fillStyle=d;if(f){g.fillRect(1,4,9,6);g.fillRect(20,4,9,6)}else{g.fillRect(1,9,9,6);g.fillRect(20,9,9,6)}g.fillStyle=c;g.fillRect(9,5,12,11);g.fillRect(10,3,3,3);g.fillRect(17,3,3,3);g.fillStyle=happy?'#fff':'#c7c1d8';g.fillRect(12,14,2,2);g.fillRect(16,14,2,2);eyes(g,11,9,happy,.67)}));
    MON_ART['mushbug'+happy]=[0,1].map(f=>pix(28,24,g=>{g.fillStyle='#5a3b2a';for(let i=0;i<4;i++)g.fillRect(6+i*5,19+((i+f)%2),2,4);g.fillStyle=happy?'#f4e6c8':'#d9c9aa';g.fillRect(7,12,14,8);g.fillStyle=happy?'#ff6b6b':'#a86a6a';g.fillRect(3,6,22,8);g.fillRect(6,3,16,4);g.fillStyle='#fff3e0';g.fillRect(8,5,3,2);g.fillRect(16,8,3,2);g.fillRect(12,4,2,2);eyes(g,9,15,happy)}));
    MON_ART['golem'+happy]=[0,1].map(f=>pix(72,72,g=>{const c=happy?'#9b93b5':'#7a7390',d=happy?'#77709a':'#5c5674';g.fillStyle=d;g.fillRect(10,24+f,52,40);g.fillRect(2,30+f,12,24);g.fillRect(58,30+f,12,24);g.fillRect(18,62,12,9);g.fillRect(42,62,12,9);g.fillStyle=c;g.fillRect(14,20+f,44,40);g.fillRect(20,10+f,32,14);
      g.fillStyle='#6fae5a';g.fillRect(20,9+f,32,4);g.fillRect(14,20+f,10,3);g.fillRect(46,22+f,12,3);g.fillStyle=happy?'#ffd6f0':'#b9a6ff';g.fillRect(28,4+f,4,6);g.fillRect(36,2+f,4,8);g.fillRect(44,5+f,3,5);
      g.fillStyle='#1b1330';if(happy){g.fillRect(26,18+f,6,2);g.fillRect(40,18+f,6,2);g.fillRect(31,28+f,10,2);g.fillRect(30,26+f,2,2);g.fillRect(40,26+f,2,2)}else{for(const ox of [24,40]){g.fillRect(ox,15+f,7,2);g.fillRect(ox+5,17+f,2,4);g.fillRect(ox,21+f,6,2);g.fillRect(ox,17+f,2,3);g.fillRect(ox+2,18+f,2,1)}g.fillRect(30,30+f,12,2)}}))}}
const WEAK={slime:['fire','dag'],bat:['bow','bolt'],mushbug:['fire','sw'],golem:['staff','ice','bolt']},SHIELD={slime:2,bat:2,mushbug:3,golem:6};
const WICON={sw:'🗡',bow:'🏹',staff:'🪄',dag:'🔪',fire:'🔥',ice:'❄',bolt:'⚡'};
const MON_STAT={slime:{hp:18,atk:4,spd:24,exp:6},bat:{hp:12,atk:5,spd:40,exp:7,fly:1},mushbug:{hp:28,atk:7,spd:18,exp:11},golem:{hp:520,atk:12,spd:16,exp:160}};
let MONS=[],DROPS=[],SHOTS=[],FX=[],TXT=[];
function spawnMonsters(){MONS=[];DROPS=[];SHOTS=[];FX=[];TXT=[];if(M.kind!=='cave')return;const mul=M.mul||{cave1:1,cave2:1.6,cave3:2.3}[M.id];
  for(const s of M.spawns)MONS.push(mkMon(s.kind,s.x,s.y,mul));
  if(M.bossSpawn&&(!S.boss||M.id!=='cave3')){const b=mkMon('golem',M.bossSpawn.x,M.bossSpawn.y,M.id==='cave3'?1:M.mul/2);b.el=M.bossEl||null;b.boss=1;b.w=72;b.h=72;b.nextAtk=2;b.summoned=0;MONS.push(b);M.boss=b}else M.boss=null;MONS.forEach((m,i)=>m.idx=i)}
function mkMon(kind,x,y,mul){const st=MON_STAT[kind];return{kind,x,y,hx:x,hy:y,hp:Math.round(st.hp*mul),max:Math.round(st.hp*mul),atk:Math.round(st.atk*mul),spd:st.spd,exp:Math.round(st.exp*mul),fly:st.fly,st:'wander',tx:x,ty:y,t:rnd()*3,cd:0,flash:0,happy:0,gone:0,w:26,h:22,sh:SHIELD[kind]||2,shMax:SHIELD[kind]||2,brk:0,act:0}}
function monHit(mo,dmg,src,type){if(mo.happy)return;if(src!=='net')mo.hitByMe=true;type=type||(src!=='net'?weapon().type:null);
  if(type&&(WEAK[mo.kind]||[]).includes(type)&&!(src!=='net'&&Net.coop()&&!Net.isHost())){S.weakKnown=S.weakKnown||{};const kk=S.weakKnown[mo.kind]=S.weakKnown[mo.kind]||[];if(!kk.includes(type))kk.push(type);if(mo.brk<=0){mo.sh--;if(mo.sh<=0){mo.brk=2.5;mo.stun=2.5;mo.act=0;TXT.push({x:mo.x,y:mo.y-(mo.h||20)-24,s:t('brk'),c:'#7fd8ff',t:0,big:1});SHAKE=.18;sfx('kill')}}}
  if(mo.brk>0)dmg=Math.round(dmg*2);
  if(src!=='net'&&Net.coop()&&!Net.isHost()){Net.hit(mo.idx,dmg,type);mo.flash=.15;sfx('hit');TXT.push({x:mo.x,y:mo.y-(mo.h||20)-4,s:'-'+dmg,c:'#ffe8a0',t:0});for(let i=0;i<6;i++)FX.push({k:'dust',x:mo.x+(rnd()-.5)*16,y:mo.y-10+(rnd()-.5)*10,vx:(rnd()-.5)*30,vy:-20-rnd()*20,t:0,life:.6});return}
  mo.hp-=dmg;sfx('hit');if(!mo.boss){const a=Math.atan2(mo.y-P.y,mo.x-P.x),nx=mo.x+Math.cos(a)*5,ny=mo.y+Math.sin(a)*5;if(!blockedAt(M,nx,ny)){mo.x=nx;mo.y=ny}}mo.flash=.15;TXT.push({x:mo.x,y:mo.y-(mo.h||20)-4,s:'-'+dmg,c:'#ffe8a0',t:0});for(let i=0;i<6;i++)FX.push({k:'dust',x:mo.x+(rnd()-.5)*16,y:mo.y-10+(rnd()-.5)*10,vx:(rnd()-.5)*30,vy:-20-rnd()*20,t:0,life:.6});
  if(!isKid()&&!mo.boss)mo.st='chase';
  if(mo.hp<=0&&mo.kind==='slime'&&!mo.mini&&monMul()>=1.6&&!(Net.coop()&&!Net.isHost())){for(let i=0;i<2;i++){const m2=mkMon('slime',mo.x+(i?-12:12),mo.y+6,monMul()*.35);m2.mini=1;m2.w=18;m2.h=16;m2.st='chase';m2.idx=MONS.length;MONS.push(m2)}}
  if(mo.hp<=0){sfx('kill');mo.happy=1;mo.gone=1.6;if(mo.hitByMe){mission('help');bump('help');if(S.job){S.jp=S.jp||{};S.jp[S.job]=(S.jp[S.job]||0)+(mo.boss?10:1)}gainExp(mo.exp);drop(mo);if(!mo.boss)tryPet(mo.kind)}if(mo.boss&&M.id!=='cave3'){if(mo.hitByMe){S.coins+=100;save()}(M.chests||(M.chests=[])).push({x:mo.x,y:mo.y+20,open:false,id:M.id+'-boss-'+today(),big:1})}else if(mo.boss&&mo.hitByMe){S.boss=true;S.pts=(S.pts||0)+10;Net.addPoints(10);save();bossWin()}}}
const PEB={on:false,x:0,y:0,row:0,hop:0};
function gainExp(n){if(M&&M.expMul)n=Math.round(n*M.expMul);if(S.buff2&&S.buff2.until>Date.now())n=Math.round(n*(1+S.buff2.v/100));n=Math.round(n*(1+(petBonus('expP')+buffV('expP'))/100));if(S.cardBook&&CAVE1_SET.every(c=>S.cardBook.includes(c)))n=Math.round(n*1.03);S.exp+=n;TXT.push({x:P.x,y:P.y-72,s:'+'+n+' EXP',c:'#ffe36b',t:0});while(S.exp>=needExp()){S.exp-=needExp();S.lv++;S.hp=hpMax();sfx('lvl');say('⭐ '+t('lvup')+' Lv '+S.lv);for(let i=0;i<24;i++)FX.push({k:'star',x:P.x,y:P.y-30,vx:Math.cos(i/24*6.28)*60,vy:Math.sin(i/24*6.28)*60,t:0,life:.9})}hud()}
function drop(mo){const r=Math.random(),n=Math.random();const f={cave1:1,cave2:2,cave3:3}[M.id]||1;
  {const rate=(mo.boss?.05:.01)*(1+ST('dex')*.01);if(Math.random()<rate)DROPS.push({k:'card',mon:mo.kind,x:mo.x+6,y:mo.y-4})}
  if(mo.boss){DROPS.push({k:'item',item:mkItem(['sw','bow','staff','dag'][Math.floor(Math.random()*4)],3),x:mo.x,y:mo.y+8});DROPS.push({k:'coin',n:60,x:mo.x+14,y:mo.y+4});return}
  if(r<.65)DROPS.push({k:'coin',n:1+Math.floor(n*4*f),x:mo.x,y:mo.y});
  if(Math.random()<.18)DROPS.push({k:'potion',x:mo.x+8,y:mo.y+4});
  if(Math.random()<.1){const q=Math.random(),rar=q<.01?3:q<.08?2:q<.3?1:0;DROPS.push({k:'item',item:randItem(rar),x:mo.x-8,y:mo.y+2})}}
function pickUp(d){if(d.k==='coin'&&buffV('luck'))d.n=Math.round(d.n*1.3);sfx(d.k==='coin'?'coin':'pick');if(d.k==='card'){S.cards.push(d.mon);if(!S.cardBook.includes(d.mon)){S.cardBook.push(d.mon);if(CAVE1_SET.every(c=>S.cardBook.includes(c)))setTimeout(()=>say('🃏 '+t('cardDone')),1200)}say('🃏 '+t('gotCard')+' '+t('c_'+d.mon).split(' · ')[0]);sfx('lvl')}if(d.k==='coin'){S.coins+=d.n;TXT.push({x:d.x,y:d.y-14,s:'+'+d.n+'🪙',c:'#ffe36b',t:0})}else if(d.k==='potion'){S.potions++;TXT.push({x:d.x,y:d.y-14,s:'+1 🧪',c:'#ffb3d9',t:0})}else if(d.k==='gem'){S.gems++;TXT.push({x:d.x,y:d.y-14,s:'+1 💎',c:'#b8e0ff',t:0})}
  else if(d.k==='item'){S.inv.push(d.item);say((WEP[d.item.type]?WEP[d.item.type].icon:d.item.slot==='armor'?'🛡️':'💍')+' '+itemName(d.item))}d.taken=1;hud();save()}
const WNAME={th:{sw:['ดาบไม้','ดาบเหล็ก','ดาบคริสตัล','ดาบทอง','ดาบชุดแสง'],bow:['ธนูไม้','ธนูล่าสัตว์','ธนูคริสตัล','ธนูทอง','ธนูชุดแสง'],staff:['คทาไม้','คทาเงิน','คทาจันทร์','คทาดาว','คทาชุดแสง'],dag:['มีดไม้','มีดเหล็ก','มีดคริสตัล','มีดทอง','มีดชุดแสง']},
  en:{sw:['Wooden sword','Iron sword','Crystal sword','Golden sword','Light-set sword'],bow:['Wooden bow','Hunting bow','Crystal bow','Golden bow','Light-set bow'],staff:['Wooden staff','Silver staff','Moon staff','Star staff','Light-set staff'],dag:['Wooden dagger','Iron dagger','Crystal dagger','Golden dagger','Light-set dagger']}};
WNAME.th.armor=['เสื้อผ้าฝ้าย','เสื้อหนัง','เกราะเหล็ก','เกราะคริสตัล','เกราะชุดแสง'];WNAME.th.acc=['สร้อยไม้','แหวนเงิน','จี้คริสตัล','มงกุฎจิ๋วทอง','เข็มกลัดชุดแสง'];WNAME.en.armor=['Cotton shirt','Leather vest','Iron armor','Crystal armor','Light-set armor'];WNAME.en.acc=['Wooden necklace','Silver ring','Crystal pendant','Tiny gold crown','Light-set brooch'];
const itemName=it=>(WNAME[LANG]||WNAME.th)[it.type][it.rar||0];const SELL=[5,15,40,120,80];
function bossWin(){setTimeout(()=>playScene('boss',()=>{showCard(t('ch1done'),t('ch1next'));sfx('lvl')}),1600);say(t('bossWin'));LIGHT=1;for(let i=0;i<60;i++)FX.push({k:'star',x:M.boss.x+(rnd()-.5)*60,y:M.boss.y-40+(rnd()-.5)*40,vx:(rnd()-.5)*80,vy:-40-rnd()*60,t:0,life:1.4})}

// ---- player actions ----
function attackTarget(mo){P.target=mo;P.act=null;P.path=null}
function doAttack(mo){const atkType=weapon().type;const w=weapon(),W=WEP[w.type];P.cd=W.cd/(w.spd||1)/aspdMul();P.atkAnim=.25;P.row=rowFor(mo.x-P.x,mo.y-P.y);const cr=Math.random()<critCh();let dmg=Math.max(1,Math.round(atkPow()*(.85+Math.random()*.3)*(cr?(S.job==='hunter'?1.65:1.5):1)));if(cr)TXT.push({x:mo.x,y:mo.y-(mo.h||20)-14,s:t('crit'),c:'#ff9f43',t:0});if(gear().stun&&Math.random()<gear().stun/100)mo.stun=1;
  if(w.type==='bow'||w.type==='staff'){sfx('shoot');}if(w.type==='bow'||w.type==='staff')SHOTS.push({k:w.type,x:P.x,y:P.y-26,tx:mo,sp:w.type==='bow'?260:170,dmg,from:'p',type:w.type});
  else{monHit(mo,dmg,undefined,atkType);FX.push({k:'slash',x:mo.x,y:mo.y-14,t:0,life:.25,a:Math.atan2(mo.y-P.y,mo.x-P.x)})}}
function hurtPlayer(n){if(isKid()||P.dead)return;if(Math.random()<fleeCh()){TXT.push({x:P.x,y:P.y-66,s:t('miss'),c:'#bfe8ff',t:0});return}n=Math.max(1,Math.round(n*50/(50+defVal())*(effOn('guard')?.6:1)));S.hp-=n;sfx('hurt');P.hurt=.3;TXT.push({x:P.x,y:P.y-66,s:'-'+n,c:'#ff7a6b',t:0});hud();if(S.hp<=0){S.hp=0;faint()}}
function faint(){P.dead=1;const loss=Math.floor(needExp()*.01);S.exp=Math.max(0,S.exp-loss);say(t('fell')+(loss?' · '+t('expLoss')+' '+loss:''));fadeTo(()=>{S.hp=hpMax();P.dead=0;const st=S.lastStone||'plaza';const mapId=st==='plaza'?'plaza':st==='mountain'?'mountain':st;goMap(mapId,null,true)})}
function usePotion(){if(!S.potions||isKid())return;S.potions--;S.hp=Math.min(hpMax(),S.hp+Math.round(hpMax()*.6));TXT.push({x:P.x,y:P.y-66,s:'+HP',c:'#8ff7a0',t:0});hud();save()}

const monMul=()=>M.mul||{cave1:1,cave2:1.6,cave3:2.3}[M.id]||1;
function openChest(c){S.chests=S.chests||[];if(S.chests.includes(c.id)){c.open=true;return}c.open=true;S.chests.push(c.id);if(S.chests.length>200)S.chests.shift();const n=+(M.id.slice(5))||1,big=c.big;
  S.coins+=(big?40:15)+n*(big?10:4);DROPS.push({k:'gem',x:c.x+8,y:c.y});DROPS.push({k:'item',item:mkItem(['sw','bow','staff','dag'][Math.floor(Math.random()*4)],big?(Math.random()<.3+n*.01?3:2):(Math.random()<.4?2:1)),x:c.x-8,y:c.y});if(Math.random()<(big?.25:.1))DROPS.push({k:'card',mon:CAVE1_SET[Math.floor(Math.random()*4)],x:c.x,y:c.y+6});
  sfx('lvl');say('🎁 '+t('chestOpen'));for(let i=0;i<24;i++)FX.push({k:'star',x:c.x,y:c.y-10,vx:(rnd()-.5)*90,vy:-40-rnd()*60,t:0,life:1});hud();save()}
// ---- decorating our home ----
const DEC={on:false,sel:null,tool:'take'};
function roomSave(m){if(VISIT)return;const h=HOME.get();h.rooms=h.rooms||{};h.rooms[m.floor||1]=m.layout;if((m.floor||1)===1)h.room=m.layout;HOME.put(h);Net.publishHome&&Net.publishHome()}
function resetRooms(){['room','room2','room3'].forEach(k=>delete CACHE[k])}
const HCOST=[0,0,150,300,500,800,1100,1500,2000,3000];
function houseUpgrade(){const h=HOME.get(),lv=houseLv(h);if(lv>=9)return false;const c=HCOST[lv+1];if(S.coins<c){say(t('noCoin'));return false}S.coins-=c;h.lv=lv+1;HOME.put(h);resetRooms();delete CACHE.home;Net.publishHome&&Net.publishHome();sfx('lvl');say('🏡 '+t('houseUp')+' '+h.lv+' · '+t('hl'+h.lv));hud();save();return true}
async function visitHome(uid,name){const data=await Net.getHome(uid);VISIT={owner:uid,name,data};resetRooms();say('🏠 '+t('visitNow')+' '+name);Net.knock(uid);fadeTo(()=>goMap('room','door'))}
function mapKey(){return M?(M.kind==='room'?M.id+'@'+(VISIT?VISIT.owner:Net.uid):M.id):''}
function decoTap(wx,wy){const m=M,tx=Math.floor(wx/T),ty=Math.floor(wy/T);const hit=m.layout.find(f=>f.tx===tx&&(f.ty===ty||f.ty===ty+1));const h=HOME.get();h.furn=h.furn||{};
  if(hit){if(DEC.tool==='flip'){hit.fl=hit.fl?0:1;roomSave(m);placeFurniture(m);m.shadowSC=0;sfx('pick');return}m.layout.splice(m.layout.indexOf(hit),1);h.furn[hit.k]=(h.furn[hit.k]||0)+1;HOME.put(h);roomSave(m);placeFurniture(m);m.shadowSC=0;sfx('pick');return}
  if(!DEC.sel){say(t('decoTip'));return}if(!m.FLOOR.has(key(tx,ty))||ty>=m.h-2||m.SOLID.has(key(tx,ty))||m.exits.some(e=>Math.hypot(e.x-(tx*T+16),e.y-(ty*T+16))<40)||(m.floor===1&&tx===5)||Math.hypot(P.x-(tx*T+16),P.y-(ty*T+16))<14)return;
  if(!(h.furn[DEC.sel]>0)){DEC.sel=null;return}h.furn[DEC.sel]--;HOME.put(h);m.layout.push({k:DEC.sel,tx,ty});roomSave(m);placeFurniture(m);m.shadowSC=0;bump('deco');mission('deco');hud();sfx('dig');if(!(HOME.get().furn[DEC.sel]>0))DEC.sel=null}

// ---- jobs (FF Tactics): pick at Lv10 from the Wizard, earn job points, learn skills, slot any 2 learned skills ----
const JOBS={sword:{p:{hpP:10},sk:['bash','guard','provoke']},archer:{p:{crit:5},sk:['shower','evade','hawk']},mage:{p:{cdr:10},sk:['fire','ice','bolt']},hunter:{p:{dex:3},sk:['steal','dig2','dash']}};
const SK={bash:[10,5,'💥'],guard:[15,15,'🛡️'],provoke:[20,12,'📣'],shower:[10,7,'🌧️'],evade:[15,15,'💨'],hawk:[20,0,'🦅'],fire:[10,5,'🔥'],ice:[15,9,'❄️'],bolt:[20,8,'⚡'],steal:[10,6,'🫳'],dig2:[15,0,'⛏️'],dash:[20,14,'👟']};
const hasSk=k=>(S.learn||[]).includes(k),mastered=j=>JOBS[j].sk.every(hasSk),jobP=k=>{let v=(JOBS[S.job]&&JOBS[S.job].p[k])||0;const c=S.carry;if(c&&c!==S.job&&JOBS[c]&&mastered(c))v+=JOBS[c].p[k]||0;return v};
const JCD={};const effOn=k=>(S.eff&&S.eff[k]||0)>performance.now();
function useJob(k){if(!S||P.dead||PAUSE||!hasSk(k))return;const [,cd]=SK[k];if(!cd)return;if((JCD[k]||0)>performance.now()){say(t('skWait')+' '+Math.ceil((JCD[k]-performance.now())/1000)+'s');return}
  const alive=MONS.filter(o=>!o.happy).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y));const tgt=(P.target&&!P.target.happy)?P.target:alive[0],pow=atkPow(),near=r=>alive.filter(o=>Math.hypot(o.x-P.x,o.y-P.y)<r);
  const needT=['bash','shower','fire','ice','bolt','steal'];if(needT.includes(k)&&(!tgt||Math.hypot(tgt.x-P.x,tgt.y-P.y)>200)){say(t('noHit'));return}S.eff=S.eff||{};
  if(k==='bash'){monHit(tgt,critHit(pow*2.8,tgt),undefined,'sw');FX.push({k:'boom',x:tgt.x,y:tgt.y-12,t:0,life:.35})}
  else if(k==='guard'){S.eff.guard=performance.now()+5000}
  else if(k==='provoke'){for(const o of near(150)){o.taunt=performance.now()+6000;o.st='chase'}FX.push({k:'bonk',x:P.x,y:P.y-50,t:0,life:.5})}
  else if(k==='shower'){for(const o of alive)if(Math.hypot(o.x-tgt.x,o.y-tgt.y)<55)monHit(o,critHit(pow*1.3,o),undefined,'bow');for(let i=0;i<14;i++)FX.push({k:'spark',x:tgt.x+(rnd()-.5)*70,y:tgt.y-50,vx:0,vy:160,t:0,life:.35})}
  else if(k==='evade'){S.eff.evade=performance.now()+5000}
  else if(k==='fire'){for(const o of alive)if(Math.hypot(o.x-tgt.x,o.y-tgt.y)<42)monHit(o,critHit(pow*1.8,o),undefined,'fire');FX.push({k:'boom',x:tgt.x,y:tgt.y-12,t:0,life:.5})}
  else if(k==='ice'){monHit(tgt,critHit(pow*1.2,tgt),undefined,'ice');tgt.stun=2}
  else if(k==='bolt'){let cur=tgt;const hit=new Set();for(let i=0;i<3&&cur;i++){monHit(cur,critHit(pow*1.4,cur),undefined,'bolt');hit.add(cur);FX.push({k:'spark',x:cur.x,y:cur.y-14,vx:0,vy:-20,t:0,life:.4});cur=alive.filter(o=>!hit.has(o)&&!o.happy).sort((a,b)=>Math.hypot(a.x-cur.x,a.y-cur.y)-Math.hypot(b.x-cur.x,b.y-cur.y))[0]}}
  else if(k==='steal'){if(!tgt.stolen){tgt.stolen=1;drop(tgt);S.coins+=Math.random()<.2?5:0}}
  else if(k==='dash'){S.eff.dash=performance.now()+6000}
  JCD[k]=performance.now()+cd*1000*cdrMul();P.atkAnim=.25;sfx('lvl');say(SK[k][2]+' '+t('k_'+k))}

// ---- parents: time played per day, answers per subject, daily limit behind a grown-up question ----
function dayStat(k,n){S.days=S.days||{};const d=S.days[today()]=S.days[today()]||{sec:0,q:0};d[k]=(d[k]||0)+n;const keys=Object.keys(S.days).sort();while(keys.length>30)delete S.days[keys.shift()]}
let playT=0,limitWarned=false,limitShown=false;
function limitTick(dt){if(!S||PAUSE||document.hidden)return;playT+=dt;if(playT>=5){dayStat('sec',Math.round(playT));playT=0;const lim=(S.limit||0)*60,used=(S.days[today()]||{}).sec||0;
  if(lim&&!S.limitOk){if(used>=lim-300&&!limitWarned&&used<lim){limitWarned=true;say('⏰ '+t('limitSoon'));speak(t('limitSoon'))}if(used>=lim&&!limitShown){limitShown=true;limitStop()}}}}
function limitStop(){speak(t('limitDone'));modal(`<h2>🌙 ${t('limitDone')}</h2><p><button id="lmP">${t('limitParent')}</button></p>`,false);$('lmP').onclick=()=>parentGate(()=>{S.limitOk=today();save();closeModal()})}
function parentGate(ok){const a=6+Math.floor(Math.random()*4),b=6+Math.floor(Math.random()*4);modal(`<h2>🔒 ${t('gate')}</h2><div class="qz">${a} × ${b} = ?</div><div class="row2"><input id="pgA" inputmode="numeric" style="font:inherit;font-size:18px;padding:8px;width:120px"><button id="pgGo" class="go">OK</button></div>`);$('pgGo').onclick=()=>{if(+$('pgA').value===a*b){closeModal();ok()}else say(t('gateBad'))}}
function openParent(){const d=S.days||{},td=(d[today()]||{}).sec||0,qs=S.qs||{};const days=[...Array(7)].map((_,i)=>new Date(Date.now()-i*864e5).toISOString().slice(0,10)).reverse();const mx=Math.max(60,...days.map(k=>(d[k]||{}).sec||0));
  const subj=Object.entries(qs);modal(`<h2>${t('parent')} · ${t('report')} ${S.name}</h2><p><b>${t('today')}: ${Math.round(td/60)} ${t('min')}</b></p>
  <p class="note">${t('last7')}</p><div style="display:flex;gap:6px;align-items:flex-end;height:70px;margin-bottom:10px">${days.map(k=>{const v=(d[k]||{}).sec||0;return`<div style="flex:1;text-align:center;font-size:10px"><div style="background:#e0a92e;height:${Math.round(50*v/mx)}px"></div>${k.slice(8)}</div>`}).join('')}</div>
  <p class="note">${t('accuracy')}</p>${subj.length?subj.map(([s,v])=>{const n=v.ok+v.no,p=n?Math.round(100*v.ok/n):0;return`<div class="row2" style="margin-bottom:4px"><span style="width:90px">${t('sub_'+s)}</span><div class="bar" style="flex:1;margin:0"><i style="width:${p}%;background:#7df28a"></i><b>${p}% · ${n}</b></div></div>`}).join(''):`<p class="note">${t('noData')}</p>`}
  <p class="note">🔁 ${t('toReview')}: ${Object.values(S.qr||{}).filter(r=>r.box<3).length}</p><p style="margin-top:10px"><b>${t('subjects')}</b></p><div class="row2" style="flex-wrap:wrap">${['math','english','thai','chinese','general'].map(s2=>`<button data-sub="${s2}" style="${(S.subOff||{})[s2]?'opacity:.45':'background:#2f7d3a'}">${(S.subOff||{})[s2]?'⬜':'✅'} ${t('sub_'+s2)}</button>`).join('')}</div>
  <p style="margin-top:10px"><b>${t('limit')}</b></p><div class="row2">${[0,30,45,60,90].map(m=>`<button data-lim="${m}" style="${(S.limit||0)===m?'background:#5a4690':''}">${m?m+' '+t('min'):t('off')}</button>`).join('')}</div>`);
  document.querySelectorAll('[data-sub]').forEach(b=>b.onclick=()=>{S.subOff=S.subOff||{};const k=b.dataset.sub;const on=['math','english','thai','chinese','general'].filter(x=>!S.subOff[x]);if(!S.subOff[k]&&on.length<=1)return;S.subOff[k]=!S.subOff[k];save();openParent()});
  document.querySelectorAll('[data-lim]').forEach(b=>b.onclick=()=>{S.limit=+b.dataset.lim;S.limitOk=null;limitWarned=limitShown=false;save();openParent()})}

// ---- story scenes: short talks with a picture of who is speaking ----
const SCENES={intro:[['leah','sc_i1'],['leah','sc_i2'],['leah','K']],first:[['peb','sc_f1'],['leah','sc_f2']],floor:[['leah','sc_d1']],boss:[['guardian','sc_b1'],['guardian','sc_b2'],['leah','sc_b3']]};
let DLG=null;function playScene(id,after){S.seen=S.seen||{};if(S.seen[id]){after&&after();return}S.seen[id]=1;save();DLG={lines:SCENES[id].map(([w,k])=>[w,k==='K'?(isKid()?'sc_i3k':'sc_i3a'):k]),i:0,after};PAUSE=true;showLine()}
function showLine(){const [who,k]=DLG.lines[DLG.i],c=$('dlgP'),g=c.getContext('2d');g.clearRect(0,0,64,64);g.imageSmoothingEnabled=false;
  if(who==='guardian'){const a=MON_ART.golem1&&MON_ART.golem1[0];if(a)g.drawImage(a,4,6,56,56)}else{const im=IMG['npc_'+who];if(im)g.drawImage(im,0,0,64,64,-16,-2,96,96)}
  $('dlgN').textContent=t('n_'+who);$('dlgT').textContent=t(k);$('dlgH').textContent=t('tapNext');$('dlg').classList.remove('hide');$('msg').style.opacity=0;msgT=0;speak(t(k))}
function nextLine(){if(!DLG)return;DLG.i++;if(DLG.i>=DLG.lines.length){$('dlg').classList.add('hide');const a=DLG.after;DLG=null;PAUSE=false;try{speechSynthesis.cancel()}catch(e){}a&&a();return}sfx('pick');showLine()}

// ---- achievements + titles (RO / Diablo) ----
const CNT=k=>(S.cnt&&S.cnt[k])||0;function bump(k,n=1){S.cnt=S.cnt||{};S.cnt[k]=(S.cnt[k]||0)+n}
const ACH=[['wake1','wakeU',1,10],['wake10','wakeU',10,30],['wake18','wakeU',18,80],['book10','book',10,20],['book50','book',50,60],['dig5','dig',5,10],['dig25','dig',25,40],['help10','help',10,15],['help100','help',100,60],['help500','help',500,150],['boss','boss',1,100],
  ['fish1','fish',1,10],['fish5','fishSp',5,30],['fish12','fishSp',12,120],['legend','legend',1,100],['card1','cards',1,20],['card4','cards',4,80],['pet1','pets',1,20],['bond','bond',100,60],['harv1','harv',1,10],['harv20','harv',20,50],['cook5','cook',5,40],
  ['lv10','lv',10,30],['lv30','lv',30,80],['lv50','lv',50,150],['lv99','lv',99,500],['quest10','quest',10,40],['online','online',1,20],['deco5','deco',5,30],['wheel7','wheelBest',7,70],['dream10','dream',10,100],['job','job',1,30],['master','masters',2,150],['helper','helps',10,80],['fossil8','fossils',8,120],['skill8','skills',8,120],['dream25','dream',25,250]];
function achVal(k){switch(k){case 'book':return(S.book||[]).length;case 'fishSp':return Object.keys(S.fish||{}).length;case 'legend':return(S.fish||{})[11]?1:0;case 'cards':return(S.cardBook||[]).length;case 'pets':return(S.pets||[]).length;case 'bond':return Math.max(0,...(S.pets||[]).map(p=>p.aff));case 'lv':return S.lv;case 'boss':return S.boss?1:0;case 'online':return S.room?1:0;case 'dream':return S.dreamBest||0;case 'wakeU':return totalCrystals();case 'fossils':return Object.keys(S.fossils||{}).length;case 'job':return S.job?1:0;case 'masters':return Object.keys(JOBS).filter(mastered).length;case 'helps':return CNT('req');case 'skills':return(S.learn||[]).length;case 'wheelBest':return(S.wheel&&S.wheel.best)||0;default:return CNT(k)}}
const titleOf=id=>{if(!id)return'';const a=(TX[LANG]||{})['at_'+id];return a!==undefined?a:(TX.th['at_'+id]||'')};
let achQ=[],achT=0;function achCheck(){if(!S)return;S.ach=S.ach||{};for(const [id,k,n,coins] of ACH)if(!S.ach[id]&&achVal(k)>=n){S.ach[id]=Date.now();S.coins+=coins;achQ.push(id)}if(achQ.length&&achT<=0)achNext()}
function achNext(){const id=achQ.shift();if(!id)return;achT=3.2;say(t('achGot')+': '+t('an_'+id)+(titleOf(id)?' · '+t('title')+' «'+titleOf(id)+'»':''));msgT=3;sfx('lvl');for(let i=0;i<20;i++)FX.push({k:'star',x:P.x,y:P.y-40,vx:Math.cos(i/20*6.28)*50,vy:Math.sin(i/20*6.28)*50-20,t:0,life:.9});save()}

// ---- home garden + kitchen, shared by everyone who plays on this device (Stardew) ----
const CROPS={cab:{min:5,bed:'cabbageBed',price:5},car:{min:8,bed:'carrotBed',price:6},tom:{min:12,bed:'tomatoBed',price:8},str:{min:15,bed:'strawberryBed',price:10},pum:{min:25,bed:'pumpkinPatch',price:14}};
const RECIPES={salad:{need:{cab:2},buff:{hpP:12}},curry:{need:{car:2,fish:1},buff:{atkP:12}},soup:{need:{tom:2},buff:{cdr:15}},pie:{need:{str:2},buff:{expP:15}},pum:{need:{pum:1,cab:1},buff:{def:12}},fish:{need:{fish:1},heal:1},rice:{need:{cab:1,car:1},buff:{luck:30}},smoothie:{need:{str:1},buff:{spd:15}}};
const HOME={key:'leahpp2d-home',get(){try{return JSON.parse(localStorage.getItem(this.key)||'null')||{plots:{},seeds:{},pantry:{},dishes:{}}}catch(e){return{plots:{},seeds:{},pantry:{},dishes:{}}}},put(h){try{localStorage.setItem(this.key,JSON.stringify(h))}catch(e){}}};
function plotState(p){const h=HOME.get(),q=h.plots[p.i];if(!q)return{st:'empty'};const c=CROPS[q.crop],half=c.min*60000/2,now=Date.now();
  if(q.st==='seed'&&q.w&&now-q.t>=half){q.st='sprout';q.w=false;q.t=now;HOME.put(h)}else if(q.st==='sprout'&&q.w&&now-q.t>=half){q.st='ripe';HOME.put(h)}return q}
function plotAct(p){const h=HOME.get(),q=plotState(p);
  if(q.st==='empty'){const own=Object.entries(h.seeds).filter(([,n])=>n>0);if(!own.length){say(t('noSeed'));return}modal(`<h2>🌱 ${t('pickSeed')}</h2><div class="grid">${own.map(([k,n])=>`<button class="it" data-sd="${k}">🌱 ${t('cr_'+k)} ×${n}</button>`).join('')}</div>`);
    document.querySelectorAll('[data-sd]').forEach(b=>b.onclick=()=>{const k=b.dataset.sd,H=HOME.get();H.seeds[k]--;H.plots[p.i]={crop:k,st:'seed',w:false,t:Date.now()};HOME.put(H);closeModal();sfx('dig');say('🌱 '+t('planted'));mission('plant')});return}
  const Q=h.plots[p.i];if(Q.st==='ripe'){delete h.plots[p.i];h.pantry[Q.crop]=(h.pantry[Q.crop]||0)+(Q.star?3:2);HOME.put(h);bump('harv');mission('harvest');sfx('coin');say('🧺 '+t('got')+' '+t('cr_'+Q.crop)+' ×2');for(let i=0;i<12;i++)FX.push({k:'star',x:p.x,y:p.y-10,vx:(rnd()-.5)*60,vy:-30-rnd()*40,t:0,life:.8});gainExp(6);return}
  if(!Q.w){Q.w=true;Q.t=Date.now();if(Q.st==='sprout'&&(h.fert||0)>0&&!Q.star){h.fert--;Q.star=1;say('🌟 '+t('fertUsed'))}HOME.put(h);sfx('pick');say('💧 '+t('watered'));for(let i=0;i<10;i++)FX.push({k:'spark',x:p.x+(rnd()-.5)*18,y:p.y-14,vx:(rnd()-.5)*10,vy:30+rnd()*20,t:0,life:.5});return}
  const left=Math.ceil((CROPS[Q.crop].min*60000/2-(Date.now()-Q.t))/60000);say('🌿 '+t('growing')+' ~'+Math.max(1,left)+' '+t('minLeft'))}
function buffNow(){return S.buff&&S.buff.until>Date.now()?S.buff:null}
function buffV(k){const b=buffNow();return b&&RECIPES[b.id].buff?RECIPES[b.id].buff[k]||0:0}
function eatDish(id){const h=HOME.get();if(!(h.dishes[id]>0))return;h.dishes[id]--;HOME.put(h);const r=RECIPES[id];if(r.heal){S.hp=hpMax()}else S.buff={id,until:Date.now()+10*60000};sfx('lvl');say('😋 '+t('ds_'+id)+' · '+t('bf_'+id));hud();save()}
function cookDish(id){const h=HOME.get(),r=RECIPES[id];const fishN=(S.fishBag||[]).length;for(const [k,n] of Object.entries(r.need)){if(k==='fish'?fishN<n:(h.pantry[k]||0)<n)return false}
  for(const [k,n] of Object.entries(r.need)){if(k==='fish')S.fishBag.splice(0,n);else h.pantry[k]-=n}h.dishes[id]=(h.dishes[id]||0)+1;HOME.put(h);bump('cook');mission('cook');sfx('right');save();return true}

// ---- pets: some monsters that stop being dizzy ask to come along (RO pets + Pokémon) ----
const PETB={slime:{hpP:5},bat:{magnet:14},mushbug:{expP:5}},PET={x:0,y:0,row:0,t:0,find:45,heart:0};
function tryPet(kind){if(!PETB[kind]||Math.random()>.08)return;S.pets=S.pets||[];if(S.pets.some(p=>p.kind===kind))return;S.pets.push({kind,aff:10});if(S.pet==null||S.pet<0)S.pet=S.pets.length-1;PET.x=P.x;PET.y=P.y;sfx('wake');setTimeout(()=>{say('🐾 '+t('n_'+kind)+' '+t('petJoin'));msgT=5},900);save()}
const petNow=()=>S&&S.pets&&S.pet>=0?S.pets[S.pet]:null;
const petMul=()=>{const p=petNow();return p?1+p.aff/100:0};const petLv=()=>{const p=petNow();return p?Math.min(5,1+Math.floor(p.aff/20)):0};
function petBonus(k){const p=petNow();if(!p)return 0;if(k==='atkP')return petLv()>=3?5:0;if(k==='magnet'&&petLv()>=2)return(PETB[p.kind].magnet||0)*petMul()+10;return PETB[p.kind][k]?PETB[p.kind][k]*petMul():0}
function updPet(dt){const p=petNow();if(!p||!M)return;PET.t+=dt;PET.heart=Math.max(0,PET.heart-dt);const a=DIR_ANG[P.row]+2.2,gx=P.x-Math.cos(a)*26,gy=P.y-Math.sin(a)*16+4;const dx=gx-PET.x,dy=gy-PET.y,d=Math.hypot(dx,dy);
  if(Math.hypot(P.x-PET.x,P.y-PET.y)>170){PET.x=gx;PET.y=gy}else if(d>2){const sp=Math.min(1,d/20)*100*dt;PET.x+=dx/d*Math.min(sp,d);PET.y+=dy/d*Math.min(sp,d)}
  PET.find-=dt*(petLv()>=5?2:1);if(PET.find<=0){PET.find=45+Math.random()*30;if(petLv()>=4&&Math.random()<.3)DROPS.push({k:'gem',x:PET.x-6,y:PET.y});DROPS.push({k:'coin',n:1+Math.floor(Math.random()*3*petMul()),x:PET.x+6,y:PET.y});TXT.push({x:PET.x,y:PET.y-26,s:t('petFound'),c:'#ffe36b',t:0})}}

// ---- real-time day and night + rainy days (same for everyone on the same date) ----
function dayPhase(h=new Date().getHours()+new Date().getMinutes()/60){return h>=5&&h<7?'dawn':h>=7&&h<17?'day':h>=17&&h<19?'dusk':'night'}
function isRainy(d=today()){let x=0;for(const c of d)x=(x*31+c.charCodeAt(0))%100003;return(x%100)<25}
let rainSaid='';function rainTick(){if(!isRainy()||!M)return;const h=HOME.get();let changed=false;for(const k of Object.keys(h.plots||{})){const q=h.plots[k];if(q&&q.st!=='ripe'&&!q.w){q.w=true;q.t=Date.now();changed=true}}if(changed)HOME.put(h);if(rainSaid!==today()&&M.kind==='town'&&performance.now()>9000&&!PAUSE){rainSaid=today();say(t('rainDay'))}}

// ---- fishing (Stardew-style reel for grown-ups, one tap for kids) ----
// [rarity 0-4, min cm, max cm, hours ok (null = any), price, exp, colour]
const FISH=[[0,5,9,null,3,4,'#bfe8ff'],[0,18,32,[6,18],5,5,'#8aa0b8'],[1,12,24,[5,11],9,8,'#ffd23f'],[1,30,60,[18,5],10,9,'#6b5a4a'],[0,3,6,null,3,4,'#e8f0f0'],[1,6,12,[16,20],8,8,'#a8683a'],
  [2,40,80,[17,20],20,16,'#3a4a5a'],[2,10,20,[12,17],18,15,'#e0c060'],[2,25,50,[20,4],22,18,'#8a7a9a'],[2,12,20,[6,10],25,20,'#6fae5a'],[3,15,30,'light',45,35,'#5fe0ff'],[4,60,120,[22,4],120,80,'#fff3c0']];
const FW=[[0,4],[1,5],[4,4],[2,2],[3,2],[5,2],[6,1],[7,1],[8,1],[9,.7],[10,.6],[11,.15]];const fwNow=()=>isRainy()?FW.map(([i,w])=>[i,[3,6,8].includes(i)?w*2.5:w]):FW;
const hourOk=(h,r)=>!r?true:r==='light'?LIGHT>=.7:r[0]<r[1]?h>=r[0]&&h<r[1]:h>=r[0]||h<r[1];
function rollFish(){const h=new Date().getHours(),pool=fwNow().filter(([i])=>hourOk(h,FISH[i][3]));const tot=pool.reduce((a,[,w])=>a+w,0);let r=Math.random()*tot;for(const [i,w] of pool){if((r-=w)<=0)return i}return 0}
const FISHING={on:false,st:'idle',t:0,fish:0,hold:false,zy:40,zv:0,fy:60,fv:0,ft:0,prog:.3};
function fishArt(i){const c=FISH[i][6];return pix(20,12,g=>{g.fillStyle=c;g.fillRect(3,3,12,6);g.fillRect(5,2,8,8);g.fillRect(15,2,3,8);g.fillStyle='rgba(255,255,255,.5)';g.fillRect(5,3,6,1);g.fillStyle='#1b1330';g.fillRect(5,5,1,1)})}
function fishNear(){return M&&M.fishSpot&&Math.hypot(P.x-M.fishSpot.x,P.y-M.fishSpot.y)<30}
function fishAct(){if(!FISHING.on){if(!fishNear())return;FISHING.on=true;FISHING.st='idle'}const F=FISHING;
  if(F.st==='idle'){F.st='wait';F.t=1.5+Math.random()*3.5;F.fish=rollFish();sfx('shoot');say(t('wait'))}
  else if(F.st==='bite'){if(isKid())catchFish();else{F.st='reel';F.prog=.25;F.zy=50;F.zv=0;F.fy=60;F.fv=0;say(t('reelTip'))}}
  else if(F.st==='wait'){F.st='idle';say(t('lost'))}}
function fishUpdate(dt){const F=FISHING;if(!F.on)return;if(!fishNear()){F.on=false;F.st='idle';return}F.t-=dt;
  if(F.st==='wait'&&F.t<=0){F.st='bite';F.t=isKid()?1.4:.9;sfx('warp');say('❗ '+t('bite'))}
  else if(F.st==='bite'&&F.t<=0){F.st='idle';say(t('lost'))}
  else if(F.st==='reel'){const H=120,zh=36-FISH[F.fish][0]*3,diff=1+FISH[F.fish][0]*.6;F.zv+=(F.hold?-300:240)*dt;F.zy+=F.zv*dt;if(F.zy<0){F.zy=0;F.zv*=-.3}if(F.zy>H-zh){F.zy=H-zh;F.zv*=-.3}
    F.ft-=dt;if(F.ft<=0){F.ft=.35+Math.random()*(1.1-FISH[F.fish][0]*.15);F.ftg=4+Math.random()*H*.72}const want=(F.ftg??60)-F.fy;F.fv+=(Math.sign(want)*90*diff-F.fv*1.5)*dt;F.fy+=F.fv*dt;if(F.fy<4){F.fy=4;F.fv=Math.abs(F.fv)}if(F.fy>H-4){F.fy=H-4;F.fv=-Math.abs(F.fv)}
    const inZ=F.fy>F.zy&&F.fy<F.zy+zh;F.prog+=(inZ?.2:-.2*Math.min(1.4,.8+diff*.25))*dt;if(F.prog>=1)catchFish();else if(F.prog<=0){F.st='idle';say(t('lost'))}}}
function catchFish(){const F=FISHING,f=FISH[F.fish],len=Math.round((f[1]+(f[2]-f[1])*Math.pow(Math.random(),1.6))*10)/10;F.st='idle';S.fish=S.fish||{};S.fishBag=S.fishBag||[];
  const rec=S.fish[F.fish];const isNew=!rec;if(!rec||len>rec)S.fish[F.fish]=len;S.fishBag.push(F.fish);bump('fish');gainExp(f[5]);mission('fish');sfx('right');
  const msg=`🐟 ${t('caught')} ${t('f'+F.fish)} ${len} ${t('cm')}${isNew?' · '+t('newFish'):(len>rec?' · '+t('record'):'')}`;say(msg);msgT=4;FX.push({k:'splash',x:M.fishSpot.wx,y:M.fishSpot.wy,t:0,life:.6});for(let i=0;i<10;i++)FX.push({k:'spark',x:M.fishSpot.wx,y:M.fishSpot.wy-6,vx:(rnd()-.5)*60,vy:-40-rnd()*40,t:0,life:.8});save()}

// ---- weapon specials ----
const SKILL={sw:{cd:6},bow:{cd:6},staff:{cd:8},dag:{cd:5}};
function useSkill(){if(!S||P.dead||PAUSE)return;const w=weapon(),k=SKILL[w.type];if((P.skCd||0)>0){say(t('skWait')+' '+Math.ceil(P.skCd)+'s');return}
  const alive=MONS.filter(o=>!o.happy).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y));const tgt=(P.target&&!P.target.happy)?P.target:alive[0];const pow=atkPow();
  if(w.type==='sw'){const near=alive.filter(o=>Math.hypot(o.x-P.x,o.y-P.y)<44);for(const o of near)monHit(o,critHit(pow*1.6,o),undefined,'sw');for(let i=0;i<16;i++)FX.push({k:'slash',x:P.x+Math.cos(i/16*6.28)*18,y:P.y-14+Math.sin(i/16*6.28)*10,t:0,life:.3,a:i/16*6.28})}
  else if(!tgt||Math.hypot(tgt.x-P.x,tgt.y-P.y)>190){say(t('noHit'));return}
  else if(w.type==='bow'){alive.filter(o=>Math.hypot(o.x-P.x,o.y-P.y)<190).slice(0,3).forEach(o=>SHOTS.push({k:'bow',x:P.x,y:P.y-26,tx:o,sp:300,dmg:critHit(pow*1.2,o),from:'p',type:'bow'}))}
  else if(w.type==='staff'){SHOTS.push({k:'staff',x:P.x,y:P.y-26,tx:tgt,sp:150,dmg:critHit(pow*2.2,tgt),from:'p',big:1,type:'staff'})}
  else{const a=Math.atan2(tgt.y-P.y,tgt.x-P.x),d=Math.max(0,Math.hypot(tgt.x-P.x,tgt.y-P.y)-18);for(let i=0;i<8;i++){const nx=P.x+Math.cos(a)*d*i/8,ny=P.y+Math.sin(a)*d*i/8;if(blockedAt(M,nx,ny))break;FX.push({k:'dust',x:nx,y:ny-20,vx:0,vy:-5,t:0,life:.4});P.x=nx;P.y=ny}monHit(tgt,critHit(pow*.9,tgt),undefined,'dag');setTimeout(()=>{if(!tgt.happy)monHit(tgt,critHit(pow*.9,tgt),undefined,'dag')},160)}
  P.skCd=k.cd*cdrMul();P.atkAnim=.25;sfx('lvl');say('✨ '+t('sk_'+w.type))}

// ---- crystals & quiz ----
let QBANK=[];async function loadQuestions(){const fb=__FALLBACK_Q__;if(window.EMBED_Q){QBANK=window.EMBED_Q;return}try{const idx=await (await fetch('questions-index.json',{cache:'no-cache'})).json();const parts=await Promise.all(idx.files.map(f=>fetch(f.f).then(r=>r.json()).then(j=>j.questions||j).catch(()=>[])));QBANK=parts.flat();if(!QBANK.length)QBANK=fb}catch(e){QBANK=fb}}
// adaptive questions: wrong ones come back (Leitner boxes), weak subjects more often, difficulty follows recent results, parents choose subjects
const BOX_MIN=[2,10,1440,4320,10080];let lastQ=null;
function recentAcc(){const r=(S.recent||[]).slice(-10);return r.length<5?null:r.filter(Boolean).length/r.length}
function pickQuestion(){const baseAge=Math.max(6,Math.min(8,S.age>=12?8:S.age||7)),acc=recentAcc(),off=S.subOff||{};
  const age=Math.max(6,Math.min(8,baseAge+(acc!==null&&acc>=.8?1:acc!==null&&acc<.5?-1:0))),lvMax=acc===null?2:acc>=.8?3:acc<.5?1:2;
  const okQ=q=>q[LANG]&&!(LANG==='en'&&q.subject==='thai')&&!off[q.subject];
  const now=Date.now(),QR=S.qr||{};const due=QBANK.filter(q=>{const r=QR[q.id];return r&&r.box<3&&now>=r.due&&okQ(q)});
  if(due.length&&Math.random()<.4){const q=due[Math.floor(Math.random()*due.length)];q._review=1;lastQ=q.id;return q}
  let pool=QBANK.filter(q=>okQ(q)&&Math.abs(q.age-age)<=1&&(q.level||1)<=lvMax&&!QR[q.id]&&q.id!==lastQ);if(pool.length<5)pool=QBANK.filter(q=>okQ(q)&&q.id!==lastQ);if(!pool.length)pool=QBANK.filter(q=>q[LANG]);
  const qs=S.qs||{},w=q=>{const v=qs[q.subject];if(!v||v.ok+v.no<3)return 1;return 1+2*(1-v.ok/(v.ok+v.no))};let tot=0;for(const q of pool)tot+=w(q);let r=Math.random()*tot,q=pool[0];for(const x of pool){r-=w(x);if(r<=0){q=x;break}}
  q._review=0;lastQ=q.id;S.asked=S.asked||[];return q}
function qResult(q,firstOk){S.qr=S.qr||{};const r=S.qr[q.id]||{box:0,n:0};r.n++;r.box=firstOk?Math.min(4,(q._review||S.qr[q.id]?r.box+1:2)):0;r.due=Date.now()+BOX_MIN[r.box]*60000;S.qr[q.id]=r;S.recent=(S.recent||[]).concat(firstOk?1:0).slice(-20);
  const ids=Object.keys(S.qr);if(ids.length>600){ids.sort((a,b)=>S.qr[a].due-S.qr[b].due).slice(0,ids.length-600).forEach(k=>delete S.qr[k])}}
function openQuiz(c){if(c.awake)return;const q=pickQuestion(),L=q[LANG]||q.th;let tries=0;PAUSE=true;
  const body=`<h2>${t('wake')}${q._review?' · 🔁 '+t('review'):''}${(S.combo||0)>=2?' · 🔥 ×'+S.combo:''}</h2><div class="qz">${L.q}</div><div class="ch">${L.choices.map((c2,i)=>`<button data-i="${i}">${c2}</button>`).join('')}</div><p class="note" id="qfb"></p>`;
  let first=true;const qs=()=>{S.qs=S.qs||{};const k=q.subject||'general';return S.qs[k]=S.qs[k]||{ok:0,no:0}};
  modal(body+`<p><button id="qSay">${t('readAgain')}</button></p>`,false);const readQ=f=>speak(L.q+'. '+L.choices.map((c2,i)=>(i+1)+'. '+c2).join(', '),f);readQ();$('qSay').onclick=()=>readQ(1);document.querySelectorAll('.ch button').forEach(b=>b.onclick=()=>{const i=+b.dataset.i;if(b.disabled)return;
    if(i===q.answer){b.classList.add('ok');sfx('right');bookAdd(q);speak(t('right'));if(first){qs().ok++;dayStat('q',1);qResult(q,true);mission('quiz');S.combo=(S.combo||0)+1;if(S.combo>=3){const b2=Math.min(10,S.combo);S.coins+=b2;setTimeout(()=>{say('🔥 '+t('combo')+' ×'+S.combo+' +'+b2+'🪙');sfx('lvl')},700)}}first=false;wakeCrystal(c,tries===0);setTimeout(()=>{closeModal();say(t('right'))},650)}
    else{tries++;sfx('wrong');b.classList.add('no');if(first){qs().no++;dayStat('q',1);qResult(q,false);S.combo=0}first=false;b.disabled=true;const fbEl=document.getElementById('qfb')||{};
      if(tries>=2){bookAdd(q);speak(t('answer')+' '+L.choices[q.answer]+'. '+(L.explain||''));document.querySelectorAll('.ch button')[q.answer].classList.add('ok');fbEl.textContent=t('answer')+' '+L.choices[q.answer]+(L.explain?' · '+L.explain:'');wakeCrystal(c,false);setTimeout(()=>{closeModal()},2600)}
      else{fbEl.textContent=t('wrong');speak(t('wrong'))}}})}
function dimToday(id,aw){const out=new Set();if(aw.length<3)return out;const sorted=[...aw].sort(),r=seeded(Math.floor(Date.now()/864e5)*13+id.length*101+id.charCodeAt(id.length-1));const n=Math.min(3,aw.length-1);while(out.size<n)out.add(sorted[Math.floor(r()*sorted.length)]);return out}
function wakeCrystal(c,full){if((S.crystals[M.id]||[]).includes(c.id)){c.awake=true;if(!S.rewake||S.rewake.date!==today())S.rewake={date:today(),ids:[]};S.rewake.ids.push(c.id);mission('wake');bump('wake');S.coins+=full?5:2;gainExp(full?10:5);setTimeout(()=>sfx('wake'),300);for(let i=0;i<30;i++)FX.push({k:'spark',x:c.x,y:c.y-12,vx:(rnd()-.5)*70,vy:-30-rnd()*70,t:0,life:1});hud();save();return}
  c.awake=true;setTimeout(()=>{if(totalCrystals()===1)playScene('first');else if((M.crystals||[]).every(x=>x.awake))playScene('floor')},1400);bump('wake');mission('wake');S.pts=(S.pts||0)+1;Net.addPoints(1);if(!S.peb){S.peb=true;PEB.on=true;PEB.x=P.x;PEB.y=P.y;setTimeout(()=>{say('🪨 '+t('pebJoin'));msgT=5},1600)}setTimeout(()=>sfx('wake'),300);setTimeout(()=>{const f=M.crystals||[];if(f.length&&f.every(x=>x.awake)){say(t('floorDone'));for(let i=0;i<50;i++)FX.push({k:'spark',x:P.x+(rnd()-.5)*80,y:P.y-30+(rnd()-.5)*50,vx:(rnd()-.5)*60,vy:-40-rnd()*50,t:0,life:1.3})}},900);(S.crystals[M.id]||(S.crystals[M.id]=[])).push(c.id);S.coins+=full?5:2;gainExp(full?10:5);setLight();for(let i=0;i<30;i++)FX.push({k:'spark',x:c.x,y:c.y-12,vx:(rnd()-.5)*70,vy:-30-rnd()*70,t:0,life:1});hud();save()}
const totalCrystals=()=>Object.values(S.crystals).reduce((a,b)=>a+b.length,0);
function setLight(){LIGHT=S.boss?1:Math.min(1,.35+.65*totalCrystals()/12)}
// digging: a quick timing game (Trickster drill feel). Gold = rare finds incl. fossils. Kids get a wider gold zone.
const FOSSIL_W=[20,18,16,14,12,9,7,4];let DIG=null;
function doDig(d){if(d.done||DIG)return;d.done=true;(S.digs[M.id]||(S.digs[M.id]=[])).push(d.id);const g=isKid()?.24:.14;DIG={d,t:0,c:.2+Math.random()*.6,g,done:false};PAUSE=true;sfx('dig');say('⛏️ '+t('digTap'));save()}
function digUpdate(dt){if(!DIG||DIG.done)return;DIG.t+=dt;if(DIG.t>3.2)digHit()}
const digNeedle=()=>{const x=(DIG.t*1.25)%2;return x<1?x:2-x};
function digHit(){if(!DIG||DIG.done)return;DIG.done=true;const d=DIG.d,n=digNeedle(),dist=Math.abs(n-DIG.c),tier=DIG.t>3.2?1:dist<=DIG.g/2?3:dist<=DIG.g/2+.18?2:1;
  bump('dig');mission('dig');P.atkAnim=.6;for(let i=0;i<14;i++)FX.push({k:'dirt',x:d.x,y:d.y,vx:(rnd()-.5)*60,vy:-40-rnd()*40,t:0,life:.7});
  if(hasSk('dig2'))DROPS.push({k:'coin',n:3+Math.floor(Math.random()*8),x:d.x+8,y:d.y});
  if(tier===3){const r=Math.random();if(r<.35){const tot=FOSSIL_W.reduce((a,b)=>a+b,0);let x=Math.random()*tot,f=0;for(let i=0;i<8;i++){if((x-=FOSSIL_W[i])<=0){f=i;break}}S.fossils=S.fossils||{};const isNew=!S.fossils[f];S.fossils[f]=(S.fossils[f]||0)+1;say('🦴 '+t('fo'+f)+(isNew?' · '+t('fossilNew'):''));sfx('wake')}
    else if(r<.65){DROPS.push({k:'gem',x:d.x,y:d.y});DROPS.push({k:'coin',n:12,x:d.x+8,y:d.y});say('✨ '+t('digGold'))}else{DROPS.push({k:'item',item:mkItem(['sw','bow','staff','dag'][Math.floor(Math.random()*4)],Math.random()<.4?2:1),x:d.x,y:d.y});say('✨ '+t('digGold'))}sfx('lvl')}
  else if(tier===2){DROPS.push(Math.random()<.5?{k:'gem',x:d.x,y:d.y}:{k:'coin',n:6+Math.floor(Math.random()*6),x:d.x,y:d.y});if(Math.random()<.2)DROPS.push({k:'potion',x:d.x+8,y:d.y});say('⛏️ '+t('digGood'));sfx('coin')}
  else{DROPS.push({k:'coin',n:2+Math.floor(Math.random()*3),x:d.x,y:d.y});say('⛏️ '+t('digMeh'))}
  setTimeout(()=>{DIG=null;PAUSE=false},450);hud();save()}

// ---- travel between maps ----
const fadeEl=document.getElementById('fade');function fadeTo(fn){fadeEl.style.opacity=1;setTimeout(()=>{fn();setTimeout(()=>fadeEl.style.opacity=0,80)},360)}
function sealPockets(m){const W=m.w,seen=new Set(),[sx,sy]=[Math.floor(m.spawnDefault[0]/T),Math.floor(m.spawnDefault[1]/T)],q=[[sx,sy]];seen.add(key(sx,sy));
  while(q.length){const [x,y]=q.pop();for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){if(!dx&&!dy)continue;const nx=x+dx,ny=y+dy,k=key(nx,ny);if(seen.has(k)||!walkable(m,nx,ny))continue;if(dx&&dy&&(!walkable(m,x+dx,y)||!walkable(m,x,y+dy)))continue;seen.add(k);q.push([nx,ny])}}
  let n=0;for(let y=0;y<m.h;y++)for(let x=0;x<W;x++){const k=key(x,y);if(!m.SOLID.has(k)&&!seen.has(k)){m.SOLID.add(k);n++}}m.sealed=n}
// phones have little memory: keep full pictures only for the map you are on, and at most 3 maps built at all
const CACHE_ORDER=[];function trimCache(cur){const i=CACHE_ORDER.indexOf(cur);if(i>=0)CACHE_ORDER.splice(i,1);CACHE_ORDER.push(cur);
  for(const [id,m] of Object.entries(CACHE))if(id!==cur&&m.shadow){m.shadow=null;m.shadowSC=0}
  while(CACHE_ORDER.length>3){const old=CACHE_ORDER.shift();if(old!==cur)delete CACHE[old]}}
function getMap(id){if(!CACHE[id]){if(!MAPS[id]&&id.startsWith('dream'))dreamCfg(+id.slice(5));const m=MAPS[id]();sealPockets(m);m.objs.forEach(measure);buildGround(m);CACHE[id]=m}return CACHE[id]}
function goMap(id,exitId,atStone){if(id.startsWith('dream')){const n=+id.slice(5);if(n>(S.dreamBest||0)){S.dreamBest=n;mission('dream')}}if(id==='home'&&VISIT){VISIT=null;resetRooms()}if(id==='room'){const h=HOME.get();if(!h.furnInit){h.furnInit=1;h.furn=Object.assign({bed:1,plant:1,rug:1},h.furn||{});HOME.put(h)}if(CACHE.room&&CACHE.room.visiting&&!goMap.keepVisit)delete CACHE.room}const m=getMap(id);trimCache(id);M=m;m.shadowSC=0;
  {const aw=S.crystals[id]||[],dim=dimToday(id,aw),rw=S.rewake&&S.rewake.date===today()?S.rewake.ids:[];let dimmedNow=0;(m.crystals||[]).forEach(c=>{c.awake=aw.includes(c.id)&&!(dim.has(c.id)&&!rw.includes(c.id));if(aw.includes(c.id)&&!c.awake)dimmedNow++});if(dimmedNow&&m.kind==='cave')setTimeout(()=>say('🌙 '+t('dimmed')),2600)}(m.digs||[]).forEach(d=>d.done=(S.digs[id]||[]).includes(d.id));m.stones.forEach(s=>s.awake=S.stones.includes(s.id));
  let p=m.spawnDefault;if(exitId){const e=m.exits.find(e=>e.id===exitId);if(e){const cx=m.w*T/2,cy=m.h*T/2,dx=cx-e.x,dy=cy-e.y,d=Math.hypot(dx,dy)||1;p=[e.x+dx/d*30,e.y+dy/d*30];if(m.kind==='cave')p=[e.x,e.y+34]}}
  if(atStone){const s=m.stones[0];if(s)p=[s.x,s.y+26]}
  if(blockedAt(m,p[0],p[1])){const q=findPath(m,m.spawnDefault[0],m.spawnDefault[1],p[0],p[1]);p=q?q[q.length-1]:m.spawnDefault}
  (m.chests||[]).forEach(c=>c.open=(S.chests||[]).includes(c.id));P.x=p[0];P.y=p[1];P.path=null;P.target=null;P.act=null;setTimeout(()=>Net.enterMap(id),0);PEB.x=P.x+18;PEB.y=P.y-24;if(id==='cave3'&&S.peb&&!S.boss)setTimeout(()=>{say('🪨 '+t('n_peb')+': '+t('s_peb'));msgT=5},2400);spawnMonsters();makeMinimap(m);showCard(t(m.nameKey),t('town'));setLight();hud();save()}
function useExit(e){if(e.locked){say(t('soon'));return}sfx('warp');fadeTo(()=>goMap(e.to,e.toExit))}
