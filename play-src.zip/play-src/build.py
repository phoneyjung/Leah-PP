import json,base64,os,glob
import os
HERE=os.path.dirname(os.path.abspath(__file__));S=os.path.join(HERE,'src')+'/';O=os.path.join(HERE,'..')+'/'  # repo root: play.html goes there, pictures are read from there
head=open(S+'00_head.html',encoding='utf-8').read()
js=''.join(open(S+f,encoding='utf-8').read()+'\n' for f in ['10_assets.js','20_engine.js','30_maps.js','40_game.js','45_net.js','50_ui.js','60_render.js'])
js=js.replace('__WANG__',open(S+'wang.json').read()).replace('__MRECTS__',open(S+'mrects.json').read()).replace('__CRECTS__',open(S+'crects.json').read()).replace('__FRECTS__',open(S+'frects.json').read()).replace('__DRECTS__',open(S+'drects.json').read()).replace('__FALLBACK_Q__',open(S+'fallback_q.json',encoding='utf-8').read())
page=head+'<script>\n'+js+'</script></body></html>\n'
open(O+'play.html','w',encoding='utf-8').write(page)
# single-file preview: every picture and the question bank inline
import re
files=re.findall(r"'([a-z0-9\-]+\.png)'",js)
kids=[k for k in ['kid-braids','kid-ponytail','kid-bob','kid-curly2','kid-blond','kid-spiky']]
need=set(files)|{f'{k}-{t}.png' for k in kids for t in ['idle','stand','walk']}
emb={}
for f in sorted(need):
    p=O+f
    if os.path.exists(p): emb[f]='data:image/png;base64,'+base64.b64encode(open(p,'rb').read()).decode()
q=[]
for f in sorted(glob.glob(O+'q-*.json')):
    d=json.load(open(f,encoding='utf-8'));q+=d['questions']
pre='<script>window.EMBED_ASSETS='+json.dumps(emb)+';window.EMBED_Q='+json.dumps(q,ensure_ascii=False)+';</script>\n'
prev=page.replace('<script>\n',pre+'<script>\n',1)
open(os.path.join(HERE,'play-preview.html'),'w',encoding='utf-8').write(prev)
print('play.html',len(page),'| preview',len(prev),'| embedded images',len(emb),'missing',sorted(need-set(emb)),'| questions',len(q))
