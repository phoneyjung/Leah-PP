import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=25;S.hp=hpMax();setChap(2);hud()")
        c0=await pg.evaluate("totalCrystals()")
        await pg.evaluate("goMap('trial','up')");await pg.wait_for_timeout(900)
        # 1) crystals from the trial must not count as cave crystals / light
        await pg.evaluate("GAME.M.crystals.forEach(c=>wakeCrystal(c,true))");await pg.wait_for_timeout(300)
        print('1 totalCrystals before/after trial phase 1:',c0,await pg.evaluate("totalCrystals()"),'| S.crystals.trial:',await pg.evaluate("JSON.stringify((S.crystals||{}).trial||null)"))
        # 2) leave in the middle of phase 3 and come back: fresh start, no leftover monsters
        await pg.evaluate("TRIAL.plates.forEach(p=>p.glow=12)");await pg.wait_for_timeout(400);await pg.wait_for_timeout(3500)
        r1=await pg.evaluate("({phase:TRIAL.phase,mons:GAME.MONS.filter(m=>m.trial&&!m.happy).length})")
        await pg.evaluate("goMap('plaza')");await pg.wait_for_timeout(700);r2=await pg.evaluate("({trial:!!TRIAL,mons:GAME.MONS.length})")
        await pg.evaluate("goMap('trial','up')");await pg.wait_for_timeout(900);r3=await pg.evaluate("({phase:TRIAL&&TRIAL.phase,awake:GAME.M.crystals.filter(c=>c.awake).length,mons:GAME.MONS.length})")
        print('2 mid-trial',r1,'-> left',r2,'-> back',r3)
        # 3) auto must not run inside the trial (it would play the guard phase for you)
        await pg.evaluate("GAME.M.crystals.forEach(c=>c.awake=true)");print('3 auto allowed in trial:',await pg.evaluate("mapCleared()"))
        # 4) same day second clear: no x2
        print('4 errors',errs[:3]);await br.close()
asyncio.run(main())
