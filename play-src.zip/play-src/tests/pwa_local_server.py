# run from the repo folder:  python3 -m http.server 8765  (then run this test)
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390});pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('http://localhost:8765/play.html#x');await pg.wait_for_timeout(2500)
        print('play.html redirected to:',pg.url.replace('http://localhost:8765',''))
        print('title:',await pg.title())
        r=await pg.evaluate("""(async()=>{const m=await (await fetch(document.querySelector('link[rel=manifest]').href)).json();const reg=await navigator.serviceWorker.ready;await new Promise(r=>setTimeout(r,1500));
          const icons=await Promise.all(m.icons.map(async i=>{const b=await (await fetch(i.src)).blob();const im=await createImageBitmap(b);return i.src+' '+im.width+'x'+im.height+' '+i.purpose}));
          const cache=await caches.open((await caches.keys())[0]);const keys=(await cache.keys()).map(k=>k.url.replace(location.origin,''));
          return{name:m.name,short:m.short_name,start:m.start_url,display:m.display,icons,sw:!!reg.active,controlled:!!navigator.serviceWorker.controller,cacheName:(await caches.keys()).join(','),cached:keys.length,hasIndex:keys.includes('/index.html'),hasQ:keys.filter(k=>k.startsWith('/q-')).length,apple:!!document.querySelector('link[rel=apple-touch-icon]')}})()""")
        for k,v in r.items():print(' ',k,':',v)
        await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1500)
        print('game running:',await pg.evaluate("!!(GAME.M&&GAME.M.id)"))
        await pg.evaluate("GAME.S.seen={intro:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');openSettings()");await pg.wait_for_timeout(200);print('install button:',await pg.evaluate("!!document.getElementById('instBtn')"))
        await pg.click('#instBtn');await pg.wait_for_timeout(200);print('install help:',(await pg.evaluate("(document.querySelector('#modal .pn')||document.querySelector('.modal .pn')||{}).innerText||''"))[:80])
        await ctx.set_offline(True);await pg.reload();await pg.wait_for_timeout(2500)
        print('offline reload title:',await pg.title(),'| canvas:',await pg.evaluate("!!document.querySelector('canvas')"),'| save kept:',await pg.evaluate("!!localStorage.getItem('leahpp2d-slots')"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
