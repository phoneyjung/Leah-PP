import asyncio,json
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
SIM="""(lv)=>{const S=GAME.S,res={};const plan={sw:['str','str','vit'],dag:['agi','str','dex'],bow:['dex','dex','agi'],staff:['int','int','vit']};
  const J={sword:{w:'sw',sk:['bash','provoke']},archer:{w:'bow',sk:['shower','evade']},mage:{w:'staff',sk:['fire','bolt']},hunter:{w:'dag',sk:['steal','dash']}};
  const MULT={bash:[2.8,1,1],shower:[1.3,5,1],fire:[1.8,3,1],bolt:[1.4,3,1],ice:[1.2,1,1]};const WS={sw:[1.6,4],bow:[1.2*3,1],staff:[2.2,1.3],dag:[.9*2,1]};
  for(const [job,c] of Object.entries(J)){S.lv=lv;S.st={str:1,agi:1,vit:1,int:1,dex:1};let i=0;while(spLeft()>=statCost(S.st[plan[c.w][i%3]])){S.st[plan[c.w][i%3]]++;i++;if(i>600)break}
    S.inv=[mkItem(c.w,2)];S.inv[0].aff=[];S.inv[0].cards=[];S.eq=0;S.eqA=-1;S.eqC=-1;S.job=job;S.learn=JOBS[job].sk.slice();S.carry=null;S.buff=null;S.buff2=null;S.pets=[];
    const pow=atkPow(),cr=critCh(),cm=job==='hunter'?1.65:1.5,crit=1+cr*(cm-1),hitCd=WEP[c.w].cd/(S.inv[0].spd||1)/aspdMul();
    let single=pow*crit/hitCd,group=single*(c.w==='staff'?1.6:1);const [wm,wt]=WS[c.w],wcd=SKILL[c.w].cd*cdrMul();single+=pow*crit*wm/wcd;group+=pow*crit*wm*wt/wcd;
    for(const k of c.sk){const m=MULT[k];if(!m)continue;const cd=SK[k][1]*cdrMul();single+=pow*crit*m[0]/cd;group+=pow*crit*m[0]*Math.min(5,m[1])/cd}
    res[job]={single:Math.round(single),group:Math.round(group),hp:hpMax(),pow,crit:+cr.toFixed(2)}}
  const sv=Object.values(res).map(r=>r.single),gv=Object.values(res).map(r=>r.group);res.spreadSingle=Math.round(100*(Math.max(...sv)/Math.min(...sv)-1))+'%';res.spreadGroup=Math.round(100*(Math.max(...gv)/Math.min(...gv)-1))+'%';return res}"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page()
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        for lv in [30,60]:
            r=await pg.evaluate(f"({SIM})({lv})");print('Lv',lv,json.dumps(r,ensure_ascii=False))
        await br.close()
asyncio.run(main())
