import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required']);pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');setChap(5);S.lv=20;hud()")
        # music modes per zone + the motif notes get scheduled
        out={}
        for mid in ['plaza','beach','falls','cave1','forest1','desert1','trial']:
            await pg.evaluate(f"goMap('{mid}','up')");await pg.wait_for_timeout(900);await pg.evaluate("while(DLG)nextLine();LEVT=null")
            out[mid]=await pg.evaluate("(()=>{MUS=true;SND=true;setMusic(M.kind!=='cave'?'town':'cave');return BGM.mode})()")
        print('music mode per map:',out)
        r=await pg.evaluate("""new Promise(res=>{let n=0;const _t=tone;window.tone=tone=function(f,t0,d,type,v){if(type==='sine'&&v===.014)n++;return _t.apply(this,arguments)};AC&&AC.resume&&AC.resume();BGM.step=20;setTimeout(()=>res({motifNotes:n,acState:AC&&AC.state}),5000)})""")
        print('lantern motif:',r)
        # monster dust + signals: screenshot in the forest
        await pg.evaluate("goMap('forest1','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine();LEVT=null")
        await pg.evaluate("(()=>{const m=GAME.MONS.filter(o=>!o.happy)[0];GAME.P.x=m.x-50;GAME.P.y=m.y})()");await pg.wait_for_timeout(700)
        await pg.screenshot(path='/home/claude/chunks/artdir.png')
        print('dust on monsters:',await pg.evaluate("GAME.MONS.filter(m=>!m.happy&&m.dust).length"),'of',await pg.evaluate("GAME.MONS.filter(m=>!m.happy).length"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
