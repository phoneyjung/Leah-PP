import asyncio,sys
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1,L5in:1,L6in:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');setChap(7)")
        for land in ['sky']:
            await pg.evaluate(f"goMap('{land}1','up')");await pg.wait_for_timeout(2600);await pg.evaluate("while(DLG)nextLine()")
            started=await pg.evaluate("!!LEVT")
            if not started:print(land,'no event');continue
            if land=='desert':await pg.wait_for_timeout(200);await pg.screenshot(path='/home/claude/chunks/lev_desert.png')
            # a kid walks at walking speed toward the nearest item (no teleporting); fish only count mid-jump
            r=await pg.evaluate("""new Promise(res=>{const t0=performance.now();const iv=setInterval(()=>{const e=LEVT;if(performance.now()-t0>50000||!e||e.done){clearInterval(iv);res({got:e?e.got:'?',of:e?e.items.length:'?',secs:((performance.now()-t0)/1000).toFixed(1),timeLeft:e?Math.max(0,e.left).toFixed(0):'?'});return}
               const it=e.items.filter(i=>!i.got).sort((a,b)=>Math.hypot(a.x-GAME.P.x,a.y-GAME.P.y)-Math.hypot(b.x-GAME.P.x,b.y-GAME.P.y))[0];if(!it)return;const path=GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,it.x,it.y);if(path){GAME.P.path=path;GAME.P.target=null}},300)})""")
            print(land,r)
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
