import asyncio,json,sys
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
RATE=int(sys.argv[1]) if len(sys.argv)>1 else 4
ECO='true' if len(sys.argv)>2 else 'false'
REC="""(ms)=>new Promise(r=>{const d=[];let last=performance.now();let lt=0;const obs=new PerformanceObserver(l=>{for(const e of l.getEntries())if(e.duration>50)lt++});try{obs.observe({entryTypes:['longtask']})}catch(e){}
  const t0=performance.now();const f=n=>{d.push(n-last);last=n;if(performance.now()-t0<ms)requestAnimationFrame(f);else{obs.disconnect();d.sort((a,b)=>a-b);const q=p=>Math.round(d[Math.floor(d.length*p)]*10)/10;r({fps:Math.round(1000*d.length/ms),p50:q(.5),p95:q(.95),max:Math.round(d[d.length-1]),longtasks:lt})}};requestAnimationFrame(f)})"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=3,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        cdp=await ctx.new_cdp_session(pg);await cdp.send('Emulation.setCPUThrottlingRate',{'rate':RATE})
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(3000);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(2500)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');GAME.S.lv=25;GAME.S.st={str:40,agi:20,vit:30,int:10,dex:20};GAME.S.hp=hpMax();GAME.S.boss=true;GAME.S.eco=false;LITE="+ECO+";window.__rec="+REC)
        out={}
        await pg.evaluate("GAME.P.path=GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,GAME.P.x,GAME.P.y+300)");out['plaza walk']=await pg.evaluate("__rec(4000)")
        await pg.evaluate("GAME.goMap('cave2','up')");await pg.wait_for_timeout(1500)
        await pg.evaluate("setInterval(()=>{const a=GAME.MONS.filter(o=>!o.happy);if(a[0]){GAME.P.target=a[0];if(Math.hypot(a[0].x-GAME.P.x,a[0].y-GAME.P.y)>150){GAME.P.x=a[0].x+25;GAME.P.y=a[0].y}}GAME.S.hp=hpMax()},400)")
        out['cave fight']=await pg.evaluate("__rec(5000)")
        out['map change ms']=await pg.evaluate("(async()=>{const t=[];for(const id of ['plaza','lake','cave1','home','market']){const t0=performance.now();GAME.goMap(id);render(performance.now()/1000);t.push(Math.round(performance.now()-t0))}return t})()")
        print('rate',RATE,'eco',ECO,json.dumps(out,ensure_ascii=False),'errors',errs[:3]);await br.close()
asyncio.run(main())
