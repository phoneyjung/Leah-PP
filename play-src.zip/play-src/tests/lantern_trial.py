import asyncio,sys
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def run(age,solve):
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click(f'#ca button[data-a="{age}"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=20;S.hp=hpMax();setChap(2);hud()")
        await pg.evaluate("openWarp()");await pg.wait_for_timeout(200)
        print(f'age {age}: trial in map menu:',await pg.evaluate("!!document.querySelector('[data-land=\"trial\"]')&&!document.querySelector('[data-land=\"trial\"]').disabled"))
        await pg.evaluate("document.querySelector('[data-land=\"trial\"]').click()");await pg.wait_for_timeout(1400)
        r=await pg.evaluate("({map:GAME.M.id,phase:TRIAL&&TRIAL.phase,crystals:GAME.M.crystals.length,plates:TRIAL.plates.length,spawns:TRIAL.spawns.length,reach:[...GAME.M.crystals.map(c=>!!GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,c.x,c.y)),...TRIAL.plates.map(p=>!!GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,p.x,p.y)),!!GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,TRIAL.lantern.x,TRIAL.lantern.y)].every(Boolean)})")
        print('  setup',r)
        await pg.screenshot(path=f'/home/claude/chunks/trial{age}_1.png')
        # phase 1: answer the 3 crystals for real (click the right answer)
        for i in range(3):
            await pg.evaluate(f"openQuiz(GAME.M.crystals[{i}])");await pg.wait_for_timeout(250)
            await pg.evaluate("(()=>{const bs=[...document.querySelectorAll('.ch button')];for(const b of bs){b.click();if(b.classList.contains('ok'))break}})()");await pg.wait_for_timeout(900)
        await pg.wait_for_timeout(300);print('  after quiz phase:',await pg.evaluate("TRIAL.phase"))
        # phase 2: walk (teleport-step) from plate A to plate B like a solo player
        r=await pg.evaluate("""new Promise(res=>{const [a,b]=TRIAL.plates;GAME.P.x=a.x;GAME.P.y=a.y;setTimeout(()=>{const d=Math.hypot(a.x-b.x,a.y-b.y);GAME.P.x=b.x;GAME.P.y=b.y;setTimeout(()=>res({phase:TRIAL.phase,plateDistTiles:(d/32).toFixed(1)}),400)},400)})""")
        print('  plates',r)
        await pg.evaluate(f"window.SLOPPY={solve};GAME.P.x=TRIAL.lantern.x+26;GAME.P.y=TRIAL.lantern.y");await pg.wait_for_timeout(8000)
        await pg.screenshot(path=f'/home/claude/chunks/trial{age}_3.png')
        # phase 3: the player just shines every 5 s (kid) or shines + fights (adult)
        r=await pg.evaluate("""new Promise(res=>{let shines=0;const iv=setInterval(()=>{if(TRIAL.phase!==3){clearInterval(iv);return}GAME.P.x=TRIAL.lantern.x+26;GAME.P.y=TRIAL.lantern.y;if(TRIAL.shineCd<=0&&(!window.SLOPPY||Math.random()<.13)){trialShine();shines++}else if(!isKid()){const m=GAME.MONS.filter(o=>!o.happy).sort((a,b)=>Math.hypot(a.x-TRIAL.lantern.x,a.y-TRIAL.lantern.y)-Math.hypot(b.x-TRIAL.lantern.x,b.y-TRIAL.lantern.y))[0];if(m)monHit(m,9999)}},250);
          const done=()=>{if(TRIAL.phase>=4||performance.now()-t0>70000){clearInterval(iv);res({phase:TRIAL.phase,fails:TRIAL.fails,lanternHp:Math.round(TRIAL.lantern.hp),shines,best:S.trialBest,coins:S.coins})}else setTimeout(done,500)};const t0=performance.now();done()})""")
        print('  guard',r,'| errors',errs[:3]);await br.close()
asyncio.run(run(int(sys.argv[1]),int(sys.argv[2]) if len(sys.argv)>2 else 0))
