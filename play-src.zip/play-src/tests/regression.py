import asyncio,json
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def mk(pg,kid,house,age,name):
    await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(2200)
    await pg.click(f'#ck .opt:nth-child({kid})');await pg.click(f'#ch .opt:nth-child({house})');await pg.click(f'#ca button[data-a="{age}"]');await pg.fill('#cname',name);await pg.click('#cgo');await pg.wait_for_timeout(1500)
    await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};if(typeof DLG!=='undefined'&&DLG){DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')}")
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.wait_for_timeout(2000);await pg.screenshot(path='b_creator.png')
        # --- KID ---
        await mk(pg,1,1,7,'มะปราง')
        # pathfinding: 60 random walkable targets on every map
        r=await pg.evaluate("""(()=>{const out={};for(const id of ['plaza','mountain','cave1','cave2','cave3']){const m=GAME.getMap(id);let ok=0,n=0,s=m.spawnDefault;const cells=[];for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++)if(!m.SOLID.has(x+','+y))cells.push([x,y]);
            for(let i=0;i<60;i++){const c=cells[Math.floor(Math.random()*cells.length)];const p=GAME.findPath(m,s[0],s[1],c[0]*32+16,c[1]*32+16);n++;if(p&&Math.hypot(p[p.length-1][0]-(c[0]*32+16),p[p.length-1][1]-(c[1]*32+16))<2)ok++}out[id]=ok+'/'+n}return out})()""");print('path found',r)
        # real walking by taps: 12 taps in plaza, count arrivals
        arr=0
        for i in range(12):
            tgt=await pg.evaluate("""(()=>{const m=GAME.M;for(let k=0;k<200;k++){const x=Math.floor(Math.random()*m.w),y=Math.floor(Math.random()*m.h);if(!m.SOLID.has(x+','+y)&&Math.hypot(x*32-GAME.P.x,y*32-GAME.P.y)<260)return [x*32+16,y*32+16]}})()""")
            sc=await pg.evaluate(f"(()=>{{const c=document.getElementById('c'),r=c.getBoundingClientRect();return [({tgt[0]}-window.__cx)/1,0]}})()") if False else None
            await pg.evaluate(f"GAME.P.path=GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,{tgt[0]},{tgt[1]})")
            await pg.wait_for_timeout(3600)
            d=await pg.evaluate(f"Math.hypot(GAME.P.x-{tgt[0]},GAME.P.y-{tgt[1]})");arr+= d<6
        print('walked to target',arr,'/12')
        # quiz: go to cave1, open quiz on first crystal, answer by trying buttons
        await pg.evaluate("GAME.goMap('cave1','up')");await pg.wait_for_timeout(900)
        before=await pg.evaluate("GAME.M.crystals.filter(c=>c.awake).length")
        await pg.evaluate("GAME.openQuiz(GAME.M.crystals[0])");await pg.wait_for_timeout(300);await pg.screenshot(path='b_quiz.png')
        for i in range(4):
            vis=await pg.evaluate("!document.getElementById('modal').classList.contains('hide')")
            if not vis: break
            bs=await pg.query_selector_all('.ch button:not([disabled])')
            if not bs: break
            await bs[0].click();await pg.wait_for_timeout(700)
        await pg.wait_for_timeout(2800)
        after=await pg.evaluate("GAME.M.crystals.filter(c=>c.awake).length");print('crystals awake',before,'->',after)
        # kid safety: park the kid next to monsters for 6 s
        hits=await pg.evaluate("""new Promise(r=>{const m=GAME.MONS[0];GAME.P.x=m.x+10;GAME.P.y=m.y;const t0=Date.now();const st=GAME.S.hp;setTimeout(()=>r({chasing:GAME.MONS.filter(o=>o.st==='chase').length,hp:GAME.S.hp,start:st}),6000)})""");print('kid next to monster 6s',hits)
        # dig
        dg=await pg.evaluate("GAME.M.digs.length");print('digs cave1',dg)
        await pg.screenshot(path='b_cave_kid.png')
        # --- ADULT ---
        await mk(pg,4,4,30,'พ่อโฟ')
        await pg.evaluate("GAME.goMap('cave1','up')");await pg.wait_for_timeout(800)
        res=await pg.evaluate("""new Promise(r=>{const S=GAME.S;const lv0=S.lv;let n=0;const tick=()=>{const alive=GAME.MONS.filter(o=>!o.happy);if(!alive.length||n>50){r({lv0,lv:S.lv,exp:S.exp,hp:S.hp,coins:S.coins,inv:S.inv.length,left:alive.length,potions:S.potions});return}const m=alive[0];if(Math.hypot(m.x-GAME.P.x,m.y-GAME.P.y)>200){GAME.P.x=m.x+30;GAME.P.y=m.y}GAME.P.target=m;n++;setTimeout(tick,1500)};tick()})""");print('adult fight cave1',res)
        await pg.screenshot(path='b_adult_fight.png')
        # death -> respawn at light stone
        d=await pg.evaluate("""new Promise(r=>{GAME.S.hp=1;GAME.goMap('cave2','up');setTimeout(()=>{const m=GAME.MONS.find(o=>!o.happy);GAME.P.x=m.x+8;GAME.P.y=m.y;GAME.P.target=null;setTimeout(()=>r({map:GAME.M.id,hp:GAME.S.hp,last:GAME.S.lastStone}),6000)},900)})""");print('after fainting',d)
        # boss
        b=await pg.evaluate("""new Promise(r=>{GAME.S.lv=14;GAME.S.hp=40+8*13;GAME.goMap('cave3','up');setTimeout(()=>{const B=GAME.M.boss;GAME.P.x=B.x-40;GAME.P.y=B.y+10;const t0=Date.now();const k=()=>{if(!B||B.happy||Date.now()-t0>40000){r({boss:GAME.S.boss,t:(Date.now()-t0)/1000,hp:GAME.S.hp,drops:0});return}if(GAME.S.hp<60)GAME.S.hp=150;GAME.P.target=B;setTimeout(k,500)};k()},900)})""");print('boss',b)
        await pg.wait_for_timeout(800);await pg.screenshot(path='b_boss.png')
        # save / reload
        await pg.reload();await pg.wait_for_timeout(2000);s=await pg.evaluate("({name:GAME.S.name,lv:GAME.S.lv,map:GAME.M.id,boss:GAME.S.boss})");print('after reload',s)
        print('errors',errs[:6]);await br.close()
asyncio.run(main())
