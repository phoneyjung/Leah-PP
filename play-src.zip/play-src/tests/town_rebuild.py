import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
REACH="""(()=>{const m=GAME.M,s=m.spawnDefault;const res={};res.exits=m.exits.filter(e=>!e.locked).map(e=>e.id+':'+(!!GAME.findPath(m,s[0],s[1],e.x,Math.max(8,Math.min(e.y,m.h*32-12)))));
  let free=0,ok=0;const unreach=[];for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){const k=x+','+y;if(m.SOLID.has(k))continue;free++;if(GAME.findPath(m,s[0],s[1],x*32+16,y*32+16))ok++;else unreach.push(k)}res.reach=ok+'/'+free;
  res.npcs=(m.npcs||[]).map(n=>n.npc+':'+(!!GAME.findPath(m,s[0],s[1],n.x,n.y+20)));res.stones=m.stones.map(st=>st.id+':'+(!!GAME.findPath(m,s[0],s[1],st.x,st.y+24)));if(m.board)res.board=!!GAME.findPath(m,s[0],s[1],m.board.x,m.board.y+24);return res})()"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'dusk'")
        for mid in ['plaza','mountain','home','market','lake']:
            await pg.evaluate(f"goMap('{mid}')");await pg.wait_for_timeout(900)
            print(mid,await pg.evaluate(REACH))
        # screenshots: plaza from a few spots, mountain academy
        await pg.evaluate("goMap('plaza')");await pg.wait_for_timeout(2600)
        for name,(x,y) in {'plaza_center':(18,11),'plaza_west':(9,12),'plaza_north':(18,6)}.items():
            await pg.evaluate(f"GAME.P.x={x}*32+16;GAME.P.y={y}*32+16;GAME.P.path=null");await pg.wait_for_timeout(500);await pg.screenshot(path=f'/home/claude/chunks/town_{name}.png')
        await pg.evaluate("goMap('mountain')");await pg.wait_for_timeout(2600);await pg.evaluate("GAME.P.x=9*32+16;GAME.P.y=11*32");await pg.wait_for_timeout(500);await pg.screenshot(path='/home/claude/chunks/town_mountain.png')
        await pg.evaluate("goMap('home')");await pg.wait_for_timeout(2400);await pg.evaluate("GAME.P.x=10*32+16;GAME.P.y=12*32");await pg.wait_for_timeout(400);await pg.screenshot(path='/home/claude/chunks/town_home.png')
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
