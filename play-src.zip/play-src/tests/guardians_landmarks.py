import asyncio,base64
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1,L5in:1,L6in:1,L3boss:1,L4boss:1,L5boss:1,L6boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=40;S.hp=hpMax();setChap(7);hud()")
        # boss art sheet
        await pg.evaluate("bossArt()")
        data=await pg.evaluate("(()=>{const c=document.createElement('canvas');c.width=72*8;c.height=72;const g=c.getContext('2d');let i=0;for(const k of ['mushking','sphinx','turtle','mist'])for(const h of [0,1]){g.drawImage(BOSS_ART[k][h][0],i*72,0);i++}return c.toDataURL()})()")
        open('/home/claude/chunks/bosses.png','wb').write(base64.b64decode(data.split(',')[1]))
        # landmarks: placed, reachable map unchanged
        for th in ['forest','desert','ulake','sky']:
            await pg.evaluate(f"goMap('{th}1','up')");await pg.wait_for_timeout(1100);await pg.evaluate("while(DLG)nextLine();LEVT=null")
            r=await pg.evaluate("""(()=>{const lm=GAME.M.objs.find(o=>o.lm);if(!lm)return{placed:false};const s=GAME.M.spawnDefault;let free=0,ok=0;for(const k of GAME.M.FLOOR){if(GAME.M.SOLID.has(k))continue;free++;const [x,y]=k.split(',').map(Number);if(GAME.findPath(GAME.M,s[0],s[1],x*32+16,y*32+16))ok++}return{placed:true,reach:ok+'/'+free,exitsOk:GAME.M.exits.every(e=>!!GAME.findPath(GAME.M,s[0],s[1],e.x,Math.min(e.y,GAME.M.h*32-20)))}})()""")
            print(th,'landmark:',r)
            if r.get('placed'):
                await pg.evaluate("(()=>{const lm=GAME.M.objs.find(o=>o.lm);GAME.P.x=lm.x+10;GAME.P.y=lm.y+50})()");await pg.wait_for_timeout(500);await pg.screenshot(path=f'/home/claude/chunks/lm_{th}.png')
        # boss floor: drawn with its own art without errors
        await pg.evaluate("goMap('desert2','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine();LEVT=null;(()=>{const b=GAME.M.boss;GAME.P.x=b.x-60;GAME.P.y=b.y})()");await pg.wait_for_timeout(600)
        await pg.screenshot(path='/home/claude/chunks/boss_sphinx.png');print('boss name:',await pg.evaluate("GAME.M.bossName"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
