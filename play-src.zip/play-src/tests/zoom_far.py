import asyncio
from playwright.async_api import async_playwright
MEAS="""()=>new Promise(res=>{let n=0,t0=performance.now();function f(){n++;GAME.P.path=[[GAME.P.x+30,GAME.P.y]];if(performance.now()-t0<2500)requestAnimationFrame(f);else res(Math.round(n/2.5))}requestAnimationFrame(f)})"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=3,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///home/claude/play/play-preview.html');await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'dusk'")
        for mid in ['capital','plaza','cave1']:
            await pg.evaluate(f"goMap('{mid}','up')");await pg.wait_for_timeout(1500);await pg.evaluate("while(DLG)nextLine()")
            for z in [1,.55,.4]:
                await pg.evaluate(f"setZoom({z},true)");await pg.wait_for_timeout(700)
                v=await pg.evaluate("[(VW/32).toFixed(1),(VH/32).toFixed(1)]");f=await pg.evaluate(MEAS)
                print(mid,'zoom',z,'view tiles',v,'fps',f)
            if mid=='capital':await pg.evaluate("GAME.P.x=48*32;GAME.P.y=33*32");await pg.wait_for_timeout(900);await pg.screenshot(path='/home/claude/chunks/zoom40_capital.png')
        # pinch can reach the new minimum
        await pg.evaluate("setZoom(.3,true)");print('lowest allowed zoom',await pg.evaluate("ZOOM"))
        await pg.evaluate("openSettings()");await pg.wait_for_timeout(200);print('settings row:',await pg.evaluate("document.getElementById('zoomRow').innerText.replace(/\\n/g,' ')"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
