import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def run(age,job):
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click(f'#ca button[data-a="{age}"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate(f"GAME.S.seen={{intro:1,first:1,floor:1,boss:1,L3in:1}};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=20;S.hp=hpMax();{'S.job=\"'+job+'\";' if job else ''}setChap(4);hud()")
        tot={}
        for mid in ['cave1','cave2','forest1','forest2','desert1']:
            await pg.evaluate(f"goMap('{mid}','up')");await pg.wait_for_timeout(1100);await pg.evaluate("while(DLG)nextLine();LEVT=null")
            r=await pg.evaluate("(M.fa||[]).map(o=>({k:o.k,reach:!!GAME.findPath(GAME.M,GAME.M.spawnDefault[0],GAME.M.spawnDefault[1],o.x,o.y+(o.k==='hole'?26:14))}))")
            for o in r:tot.setdefault(o['k'],[0,0]);tot[o['k']][0]+=1;tot[o['k']][1]+=o['reach']
        print(f'age {age} job {job}: kinds over 5 floors (count, reachable):',tot)
        # act on every spot on this floor: walk there by tapping it on screen, like a player
        r=await pg.evaluate("""new Promise(async res=>{const out=[];GAME.MONS.length=0;window.__said=[];const _s=say;say=function(m){window.__said.push(m);return _s.apply(this,arguments)};for(const o of GAME.M.fa){if(o.k==='trace'&&!faCan('trace')){out.push(o.k+':hidden');continue}const c0=S.coins;GAME.P.x=o.x;GAME.P.y=o.y+(o.k==='hole'?26:14);autoAct();await new Promise(r=>setTimeout(r,150));out.push(o.k+':'+(o.done?'done +'+(S.coins-c0):'no ('+(window.__said[window.__said.length-1]||'').slice(0,42)+')'))}res(out)})""")
        print('   actions',r)
        # tap test: tap an undone spot on screen -> player walks there and acts
        r=await pg.evaluate("(()=>{const o=GAME.M.fa.find(f=>!f.done&&(f.k!=='trace'||faCan('trace')));if(!o)return null;GAME.P.x=GAME.M.spawnDefault[0];GAME.P.y=GAME.M.spawnDefault[1];return{x:(o.x-camX)*SC/(devicePixelRatio||1),y:(o.y-12-camY)*SC/(devicePixelRatio||1),k:o.k}})()")
        if r:
            await pg.wait_for_timeout(400)
            r=await pg.evaluate("(()=>{const o=GAME.M.fa.find(f=>!f.done&&(f.k!=='trace'||faCan('trace')));camX=o.x-VW/2;camY=o.y-VH/2;return{x:(o.x-camX)*SC/(devicePixelRatio||1),y:(o.y-12-camY)*SC/(devicePixelRatio||1),k:o.k}})()")
            await pg.mouse.click(r['x'],r['y']);await pg.wait_for_timeout(200)
            print('   tap on',r['k'],'-> walking there:',await pg.evaluate("!!GAME.P.faGo||!!(GAME.P.path&&GAME.P.path.length)"))
        await pg.screenshot(path=f'/home/claude/chunks/fa_{age}.png')
        print('   errors',errs[:3]);await br.close()
async def main():
    await run(7,None);await run(30,'archer');await run(30,'hunter')
asyncio.run(main())
