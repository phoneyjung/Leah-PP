import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')+'?rank=1'
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1500)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1,L5in:1,L6in:1};for(let n=2;n<=10;n++)GAME.S.seen['rank'+n]=1;DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        # class 1: no door, no pages
        await pg.evaluate("goMap('plaza')");await pg.wait_for_timeout(700);print('class 1 door:',await pg.evaluate("!!GAME.M.door"))
        await pg.evaluate("S.rank=3;goMap('plaza')");await pg.wait_for_timeout(700)
        r=await pg.evaluate("(()=>{const d=GAME.M.door;return d?{door:true,reach:!!GAME.findPath(GAME.M,GAME.M.spawnDefault[0],GAME.M.spawnDefault[1],d.x,d.y+16)}:{door:false}})()");print('class 3 door:',r)
        await pg.evaluate("GAME.P.x=GAME.M.door.x;GAME.P.y=GAME.M.door.y+16;autoAct()");await pg.wait_for_timeout(200);print('  tap at class 3:',await pg.evaluate("document.getElementById('msg').textContent.slice(0,50)"))
        # diary pages: class 5 -> page in cave1, walk onto it
        await pg.evaluate("S.rank=5;goMap('cave1','up')");await pg.wait_for_timeout(1000);await pg.evaluate("while(DLG)nextLine()")
        r=await pg.evaluate("(()=>{const p=GAME.M.page;return p?{page:p.i,reach:!!GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,p.x,p.y)}:null})()");print('cave1 page:',r)
        await pg.evaluate("GAME.P.x=GAME.M.page.x;GAME.P.y=GAME.M.page.y");await pg.wait_for_timeout(500)
        print('  page read:',await pg.evaluate("(document.querySelector('#modal .pn,.modal .pn')||{}).innerText"),'| diary',await pg.evaluate("JSON.stringify(S.diary)"))
        await pg.screenshot(path='/home/claude/chunks/diary.png');await pg.evaluate("closeModal()")
        await pg.evaluate("goMap('cave1','up')");await pg.wait_for_timeout(900);print('  page again after taking it:',await pg.evaluate("!!GAME.M.page"))
        # every page location builds a reachable page
        r=await pg.evaluate("""(()=>{S.rank=10;const out={};for(const [id] of DIARY){try{const m=getMap(id);const keep=M;M=m;M.page=null;const had=S.diary;S.diary=[];diarySpawn();out[id]=M.page?!!GAME.findPath(m,m.spawnDefault[0],m.spawnDefault[1],M.page.x,M.page.y):'none';S.diary=had;M=keep}catch(e){out[id]='err '+e.message}}return out})()""")
        print('pages reachable per map:',r)
        # rooms at class 7 with offerings
        await pg.evaluate("S.rank=7;goMap('plaza')");await pg.wait_for_timeout(700)
        await pg.evaluate("S.fishBag=[0,3,12];S.gems=6;const h=HOME.get();h.pantry={car:1,tom:1,cab:1};HOME.put(h);GAME.P.x=GAME.M.door.x;GAME.P.y=GAME.M.door.y+16;autoAct()");await pg.wait_for_timeout(300)
        for k in ['water','earth','stone']:
            await pg.evaluate(f"document.querySelector('[data-room=\"{k}\"]').click()");await pg.wait_for_timeout(250)
        print('rooms done:',await pg.evaluate("JSON.stringify(S.rooms)"),'| fish left',await pg.evaluate("JSON.stringify(S.fishBag)"),'| gems',await pg.evaluate("S.gems"),'| light room button disabled:',await pg.evaluate("document.querySelector('[data-room=\"light\"]').disabled"))
        await pg.screenshot(path='/home/claude/chunks/rooms.png');await pg.evaluate("closeModal()")
        # shadow at night (force)
        await pg.evaluate("S.rank=3;SHT=0;window.dayPhase=()=>'night'");await pg.wait_for_timeout(600)
        r=await pg.evaluate("new Promise(res=>{SHT=0;setTimeout(()=>{const s=SHADOW;if(!s){res('no shadow');return}GAME.P.x=s.x;GAME.P.y=s.y;setTimeout(()=>res({seen:S.shadowSeen}),400)},600)})")
        print('shadow:',r)
        # map pieces from digging in a land
        await pg.evaluate("S.rank=8;setChap(4);goMap('forest1','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine();LEVT=null")
        r=await pg.evaluate("(()=>{let tries=0;const d=GAME.M.digs[0];for(let i=0;i<20;i++){if((S.mapFrag||{})[3])break;DIG=null;d.done=false;doDig(d);tries++;DIG=null}return{tries,frag:JSON.stringify(S.mapFrag||{})}})()")
        print('map piece from digging:',r)
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
