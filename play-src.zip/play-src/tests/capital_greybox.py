import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MEAS="""()=>new Promise(res=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<2500)requestAnimationFrame(f);else res(Math.round(n/2.5))}requestAnimationFrame(f)})"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=3,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'dusk'")
        await pg.evaluate("openSettings()");await pg.wait_for_timeout(300);print('settings button:',await pg.evaluate("document.getElementById('capGo')&&document.getElementById('capGo').innerText"))
        await pg.click('#capGo');await pg.wait_for_timeout(2500)
        print('map',await pg.evaluate("GAME.M.id"),'| size',await pg.evaluate("[GAME.M.w,GAME.M.h]"),'| walkers',await pg.evaluate("GAME.M.walkers.length"),'| standing+walking objs',await pg.evaluate("GAME.M.objs.filter(o=>o.walker).length"))
        r=await pg.evaluate("""(()=>{const m=GAME.M,s=m.spawnDefault;let free=0,ok=0;for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){const k=x+','+y;if(m.SOLID.has(k))continue;free++;if(GAME.findPath(m,s[0],s[1],x*32+16,y*32+16))ok++}
          return{reach:ok+'/'+free,exits:m.exits.map(e=>e.id+':'+!!GAME.findPath(m,s[0],s[1],e.x,Math.max(8,Math.min(e.y,m.h*32-12)))),board:!!GAME.findPath(m,s[0],s[1],m.board.x,m.board.y+20)}})()""")
        print(r)
        p0=await pg.evaluate("GAME.M.walkers.map(w=>[Math.round(w.o.x),Math.round(w.o.y)])");await pg.wait_for_timeout(3000);p1=await pg.evaluate("GAME.M.walkers.map(w=>[Math.round(w.o.x),Math.round(w.o.y)])")
        print('walkers moved:',sum(1 for a,b in zip(p0,p1) if a!=b),'of',len(p0))
        # are walkers always on walkable tiles?
        print('walkers on solid tiles:',await pg.evaluate("GAME.M.walkers.filter(w=>GAME.M.SOLID.has(Math.floor(w.o.x/32)+','+Math.floor((w.o.y-2)/32))).length"))
        for z in [1,.65]:
            await pg.evaluate(f"setZoom({z},true);GAME.P.x=48.67*32;GAME.P.y=40*32;GAME.P.path=null");await pg.wait_for_timeout(1200)
            print('zoom',z,'view tiles',await pg.evaluate("[(VW/32).toFixed(1),(VH/32).toFixed(1)]"),'fps',await pg.evaluate(MEAS));await pg.screenshot(path=f'/home/claude/chunks/grey_{int(z*100)}.png')
        # walk out of each gate
        for ex,to in [('w','home'),('e','market'),('n','mountain'),('s','lake')]:
            await pg.evaluate("goMap('capital')");await pg.wait_for_timeout(600)
            await pg.evaluate(f"(()=>{{const e=GAME.M.exits.find(e=>e.id==='{ex}');GAME.P.x=e.x+(e.x<50?20:e.x>3000?-20:0);GAME.P.y=Math.max(20,Math.min(e.y,GAME.M.h*32-14))+(e.y<50?18:0);GAME.P.path=[[e.x,e.y]]}})()");await pg.wait_for_timeout(1800)
            print('gate',ex,'->',await pg.evaluate("GAME.M.id"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
