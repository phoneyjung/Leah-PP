import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.coins=9999")
        # old save with many items (more than fit) -> nothing lost
        r=await pg.evaluate("""(()=>{for(let i=0;i<25;i++)S.inv.push(Math.random()<.3?randItem(1):mkItem(['sw','bow','staff','dag'][i%4],i%3));const total=S.inv.length;gridFix();const onGrid=S.inv.filter((w,i)=>!isWorn(i)&&w.gx!=null).length;return{total,bag:S.inv.length,onGrid,store:S.store.length,sumKept:S.inv.length+S.store.length}})()""")
        print('migration (nothing lost):',r)
        # overlap check: no two items share a cell
        r=await pg.evaluate("""(()=>{const occ={};let clash=0;S.inv.forEach((w,i)=>{if(isWorn(i)||w.gx==null)return;const [a,b]=ISIZE(w);for(let y=w.gy;y<w.gy+b;y++)for(let x=w.gx;x<w.gx+a;x++){const k=x+','+y;if(occ[k])clash++;occ[k]=1}});return{clash,rows:bagRows()}})()""")
        print('no overlaps:',r)
        await pg.evaluate("openBag()");await pg.wait_for_timeout(300)
        print('grid bag shown:',await pg.evaluate("!!document.querySelector('[data-grid=\"bag\"]')"),'| items drawn:',await pg.evaluate("document.querySelectorAll('.gbIt').length"))
        await pg.screenshot(path='/home/claude/chunks/gridbag.png')
        # real drag with the mouse: move the first item to an empty spot
        r=await pg.evaluate("""(()=>{const occ=gridOcc(bagList(),bagRows());for(let y=0;y<bagRows();y++)for(let x=GCOLS-1;x>=0;x--){if(occ[y][x]===-1)return{x,y}}return null})()""")
        el=await pg.query_selector('.gbIt');box=await el.bounding_box();g=await (await pg.query_selector('[data-grid="bag"]')).bounding_box()
        i0=int(await el.get_attribute('data-i'));before=await pg.evaluate(f"[S.inv[{i0}].gx,S.inv[{i0}].gy]")
        # find a free spot that fits this item
        spot=await pg.evaluate(f"(()=>{{const w=S.inv[{i0}];for(let x=GCOLS-1;x>=0;x--)for(let y=0;y<bagRows();y++)if((x!==w.gx||y!==w.gy)&&fits(bagList(),bagRows(),w,x,y,{i0}))return[x,y];return null}})()")
        C=await pg.evaluate("parseFloat(document.querySelector('[data-grid=\"bag\"]').style.width)/10")
        if spot:
            await pg.mouse.move(box['x']+5,box['y']+5);await pg.mouse.down();await pg.mouse.move(g['x']+spot[0]*C+5,g['y']+spot[1]*C+5,steps=8);await pg.mouse.up();await pg.wait_for_timeout(300)
            print('drag move:',before,'->',await pg.evaluate(f"[S.inv[{i0}].gx,S.inv[{i0}].gy]"),'target',spot)
        # drag a weapon onto the weapon slot -> equipped, old weapon back on the grid
        r=await pg.evaluate("(()=>{const i=S.inv.findIndex((w,k)=>!isWorn(k)&&!w.slot&&w.gx!=null);return i})()")
        el=await pg.query_selector(f'.gbIt[data-src="bag"][data-i="{r}"]');box=await el.bounding_box();slot=await (await pg.query_selector('[data-eqslot="weapon"]')).bounding_box()
        old=await pg.evaluate("S.eq")
        await pg.mouse.move(box['x']+4,box['y']+4);await pg.mouse.down();await pg.mouse.move(slot['x']+10,slot['y']+10,steps=8);await pg.mouse.up();await pg.wait_for_timeout(300)
        print('equip by drag: eq',old,'->',await pg.evaluate("S.eq"),'| old weapon back on grid:',await pg.evaluate(f"S.inv[{old}].gx!=null"))
        # sell zone
        n0=await pg.evaluate("S.inv.length");el=await pg.query_selector('.gbIt[data-src="bag"]');box=await el.bounding_box();sz=await (await pg.query_selector('[data-sellzone]')).bounding_box()
        await pg.mouse.move(box['x']+4,box['y']+4);await pg.mouse.down();await pg.mouse.move(sz['x']+10,sz['y']+10,steps=8);await pg.mouse.up();await pg.wait_for_timeout(300)
        print('sell by drag: items',n0,'->',await pg.evaluate("S.inv.length"))
        # storage: open, drag into it
        await pg.click('#gbStore');await pg.wait_for_timeout(300);s0=await pg.evaluate("S.store.length")
        el=await pg.query_selector('.gbIt[data-src="bag"]');box=await el.bounding_box();st=await (await pg.query_selector('[data-grid="store"]')).bounding_box()
        i1=int(await el.get_attribute('data-i'));spot=await pg.evaluate(f"(()=>{{const w=S.inv[{i1}];for(let y=0;y<storeRows();y++)for(let x=0;x<GCOLS;x++)if(fits(S.store,storeRows(),w,x,y))return[x,y];return null}})()")
        await pg.mouse.move(box['x']+4,box['y']+4);await pg.mouse.down();await pg.mouse.move(st['x']+spot[0]*C+4,st['y']+spot[1]*C+4,steps=8);await pg.mouse.up();await pg.wait_for_timeout(300)
        print('drag into storage:',s0,'->',await pg.evaluate("S.store.length"))
        await pg.screenshot(path='/home/claude/chunks/gridbag2.png')
        # full-bag pickup uses the grid
        r=await pg.evaluate("(()=>{closeModal();let n=0;while(firstFit(bagList(),bagRows(),mkItem('bow',0))&&n<80){const it=mkItem('bow',0);const p=firstFit(bagList(),bagRows(),it);it.gx=p[0];it.gy=p[1];S.inv.push(it);n++}const d={k:'item',item:mkItem('bow',1),x:0,y:0};pickUp(d);return{filled:n,leftOnGround:!d.taken}})()")
        print('grid-full pickup:',r)
        await pg.evaluate("save()");await pg.reload();await pg.wait_for_timeout(2500)
        print('after reload positions kept:',await pg.evaluate("S&&S.inv.filter(w=>w.gx!=null).length>0&&S.store.every(w=>w.gx!=null)"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
