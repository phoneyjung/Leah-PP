import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1,L5in:1,L6in:1,L3boss:1,L4boss:1,L5boss:1,L6boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');setChap(7);S.lv=30;window.dayPhase=()=>'day'")
        print('tilesets loaded:',await pg.evaluate("['forest','desert','ulake','sky'].map(t=>t+':'+(!!IMG['t_'+t]))"))
        for mid in ['forest1','desert1','ulake1','sky1','forest2']:
            await pg.evaluate(f"goMap('{mid}','up')");await pg.wait_for_timeout(1500);await pg.evaluate("while(DLG)nextLine();LEVT=null");await pg.wait_for_timeout(2400)
            print(mid,'own tiles:',await pg.evaluate("!!GAME.M._tiled"))
            await pg.screenshot(path=f'/home/claude/chunks/tile_{mid}.png')
        # fallback: pretend the forest file is missing
        await pg.evaluate("delete IMG.t_forest;delete CACHE.forest1;delete CACHE['forest1'];goMap('forest1','up')");await pg.wait_for_timeout(1200)
        print('missing file -> fallback ok, tiled:',await pg.evaluate("!!GAME.M._tiled"),'| ground:',await pg.evaluate("!!GAME.M.ground"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
