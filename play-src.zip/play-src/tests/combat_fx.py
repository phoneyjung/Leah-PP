import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=30;S.job='mage';S.learn=['fire','ice','bolt'];S.slots=['fire','bolt'];hud();LIGHT=1")
        await pg.evaluate("goMap('forest1','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
        await pg.evaluate("(()=>{const m=GAME.MONS.filter(o=>!o.happy);const a=m[0];GAME.P.x=a.x-60;GAME.P.y=a.y;m.slice(0,4).forEach((o,i)=>{o.x=a.x+(i%2)*40;o.y=a.y+Math.floor(i/2)*30-15;o.hp=o.max=99999})})()");await pg.wait_for_timeout(300)
        # hit a few times (one crit), then fire + bolt
        r=await pg.evaluate("""(()=>{const mo=GAME.MONS.filter(o=>!o.happy)[0];const n0=FX.length;monHit(mo,120,undefined,'sw');const n1=FX.length;TXT.push({x:mo.x,y:mo.y-40,s:t('crit'),c:'#ffb13b',t:0,big:1});monHit(mo,300,undefined,'sw');const hs=HITSTOP;useJob('fire');const n2=FX.length;JCD.bolt=0;useJob('bolt');return{fxPerHit:n1-n0,hitstop:+hs.toFixed(3),fxAfterSkills:FX.length,skillAdded:FX.length-n2,kinds:[...new Set(FX.map(f=>f.k))].join(',')}})()""")
        print('adult hits/skills',r)
        await pg.wait_for_timeout(120);await pg.screenshot(path='/home/claude/chunks/vfx1.png')
        await pg.wait_for_timeout(250);await pg.screenshot(path='/home/claude/chunks/vfx2.png')
        # FPS while spamming effects
        fps=await pg.evaluate("""new Promise(res=>{let n=0,t0=performance.now(),worst=0,last=t0;const iv=setInterval(()=>{const mo=GAME.MONS.filter(o=>!o.happy)[0];if(mo){monHit(mo,50,undefined,'staff');JCD.fire=0;useJob('fire')}},120);function f(){const now=performance.now();worst=Math.max(worst,now-last);last=now;n++;if(now-t0<3000)requestAnimationFrame(f);else{clearInterval(iv);res({fps:Math.round(n/3),worstFrameMs:Math.round(worst),fxCount:FX.length})}}requestAnimationFrame(f)})""")
        print('stress',fps)
        # chapter card celebration
        await pg.evaluate("celebrate()");await pg.wait_for_timeout(500);print('celebration fx',await pg.evaluate("FX.filter(f=>f.k==='confetti'||f.k==='rays').length"))
        await pg.screenshot(path='/home/claude/chunks/vfx3.png')
        # kid version
        await pg.evaluate("closeModal&&closeModal();S.age=7;goMap('cave1','up')");await pg.wait_for_timeout(1000);await pg.evaluate("while(DLG)nextLine()")
        r=await pg.evaluate("(()=>{const mo=GAME.MONS[0];const n0=FX.length;monHit(mo,5,undefined,'sw');return{kidKinds:[...new Set(FX.slice(n0).map(f=>f.k))].join(',')}})()")
        print('kid hit',r,'errors',errs[:3]);await br.close()
asyncio.run(main())
