import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page()
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1000)
        r=await pg.evaluate("""(()=>{let bad=[],lostFloor=0,n=0;for(let f=1;f<=60;f++){dreamCfg(f);const m=buildCave('dream'+f);n++;const s=m.spawnDefault;for(const e of m.exits)if(!GAME.findPath(m,s[0],s[1],e.x,e.y))bad.push('dream'+f+':'+e.id);if(m.crystals.length<3)bad.push('dream'+f+':crystals '+m.crystals.length)}return{floors:n,bad}})()""")
        print('60 Dream Cave floors:',r);await br.close()
asyncio.run(main())
