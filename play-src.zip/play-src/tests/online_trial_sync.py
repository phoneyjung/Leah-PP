import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MOCK=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'mock_firebase.txt')).read().split('MOCK=r"""')[1].split('"""')[0]
async def setup(pg,other_id,age=30):
    await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click(f'#ca button[data-a="{age}"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
    await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L3boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=20;S.hp=hpMax();setChap(4)")
    await pg.evaluate(MOCK+";Net.loadScript=async()=>{};");await pg.evaluate("window.FB_CONFIG={apiKey:'x'};Net.join('fam1')");await pg.wait_for_timeout(400)
    await pg.evaluate("goMap('trial','up')");await pg.wait_for_timeout(900)
    await pg.evaluate(f"__mock.setp('rooms/FAM1/players/{other_id}',{{n:'อีกคน',k:0,h:0,a:0,lv:10,m:'trial',x:GAME.P.x+40,y:GAME.P.y,r:0,w:0,z:0}})");await pg.wait_for_timeout(600)
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();errs=[]
        # HOST (our uid is smaller than 'zzz')
        pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        await setup(pg,'zzz_other')
        print('host?',await pg.evaluate("Net.isHost()"),'coop?',await pg.evaluate("Net.coop()"),'layout crystals',await pg.evaluate("GAME.M.crystals.map(c=>c.tx+','+c.ty).join(' ')"))
        await pg.evaluate("__mock.setp('rooms/FAM1/maps/trial/ev/e1',{u:'zzz_other',t:Date.now(),k:'tc',i:0})");await pg.wait_for_timeout(400)
        print('host got crystal event -> crystal0 awake:',await pg.evaluate("GAME.M.crystals[0].awake"))
        await pg.wait_for_timeout(500);print('host publishes state:',await pg.evaluate("JSON.stringify(__mock.get('rooms/FAM1/maps/trial/trial'))"))
        await pg.evaluate("GAME.M.crystals.forEach(c=>c.awake=true)");await pg.wait_for_timeout(300);await pg.evaluate("TRIAL.plates.forEach(p=>p.glow=12)");await pg.wait_for_timeout(3500)
        await pg.evaluate("(()=>{const L=TRIAL.lantern;GAME.MONS.filter(m=>m.trial&&!m.happy).forEach(m=>{m.x=L.x+40;m.y=L.y})})()")
        n0=await pg.evaluate("GAME.MONS.filter(m=>m.trial&&!m.happy).length")
        await pg.evaluate("__mock.setp('rooms/FAM1/maps/trial/ev/e2',{u:'zzz_other',t:Date.now(),k:'ts',c:1})");await pg.wait_for_timeout(400)
        print('host got kid shine: monsters near lantern',n0,'->',await pg.evaluate("GAME.MONS.filter(m=>m.trial&&!m.happy).length"))
        await pg.close()
        # CLIENT (other uid is smaller)
        pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        await setup(pg,'000_host',7)
        print('client host?',await pg.evaluate("Net.isHost()"),'same layout:',await pg.evaluate("GAME.M.crystals.map(c=>c.tx+','+c.ty).join(' ')"))
        await pg.evaluate("__mock.setp('rooms/FAM1/maps/trial/trial',{p:2,l:40,h:100,g:[0,0],a:[1,1,1],t:Date.now()})");await pg.wait_for_timeout(400)
        print('client mirrors phase:',await pg.evaluate("TRIAL.phase"),'crystals awake:',await pg.evaluate("GAME.M.crystals.filter(c=>c.awake).length"))
        await pg.evaluate("__mock.setp('rooms/FAM1/maps/trial/trial',{p:3,l:30,h:80,g:[12,12],a:[1,1,1],t:Date.now()})");await pg.wait_for_timeout(400)
        await pg.evaluate("GAME.P.x=TRIAL.lantern.x+20;GAME.P.y=TRIAL.lantern.y;trialShine()");await pg.wait_for_timeout(300)
        evs=await pg.evaluate("Object.values(__mock.get('rooms/FAM1/maps/trial/ev')||{}).map(e=>e.k).join(',')");print('client shine sent event:',evs,'| client did not spawn its own monsters:',await pg.evaluate("GAME.MONS.filter(m=>m.trial).length===0"))
        c0=await pg.evaluate("S.coins");await pg.evaluate("__mock.setp('rooms/FAM1/maps/trial/trial',{p:4,l:0,h:60,g:[0,0],a:[1,1,1],t:Date.now()})");await pg.wait_for_timeout(600)
        print('client win on host signal: coins',c0,'->',await pg.evaluate("S.coins"),'| trialN',await pg.evaluate("S.trialN"))
        # kid crystals calm on a boss floor as client -> event, not an oversized hit
        await pg.evaluate("goMap('forest2','up')");await pg.wait_for_timeout(900);await pg.evaluate("while(DLG)nextLine()")
        await pg.evaluate("__mock.setp('rooms/FAM1/players/000_host/m','forest2')");await pg.wait_for_timeout(300)
        await pg.evaluate("kidCrystals().forEach(c=>c.awake=true)");await pg.wait_for_timeout(600)
        print('kid calm as client sent:',await pg.evaluate("Object.values(__mock.get('rooms/FAM1/maps/forest2/ev')||{}).map(e=>e.k).join(',')"),'| hits over 500:',await pg.evaluate("Object.values(__mock.get('rooms/FAM1/maps/forest2/hits')||{}).filter(h=>h.d>500).length"))
        print('KNAME online codes:',await pg.evaluate("KNAME.join(',')"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
