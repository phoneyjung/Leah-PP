import asyncio,re,json
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','src','65_more.js'),encoding='utf-8').read()
KEYS=sorted(set(re.findall(r"t\('([A-Za-z0-9_]+)'\)",src))|{'n_mushking','n_sphinx','n_turtle','n_mist','forest1','desert1','ulake1','sky1','forest2','desert2','ulake2','sky2','beach','falls'}|{f'f{i}' for i in range(24)}|{f's{c}{x}' for c in range(3,7) for x in 'abcdefg'}|{'e1','e2','e3','e4'})
async def newgame(pg,age,name='ทดสอบ'):
    await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800)
    await pg.click(f'#ca button[data-a="{age}"]');await pg.fill('#cname',name);await pg.click('#cgo');await pg.wait_for_timeout(1200)
    await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
async def hudcheck(pg,label):
    r=await pg.evaluate("""(()=>{const bs=[...document.querySelectorAll('button')].filter(b=>{const r=b.getBoundingClientRect();const st=getComputedStyle(b);return r.width>0&&r.height>0&&st.display!=='none'&&st.visibility!=='hidden'&&!b.closest('#modal')&&!b.closest('.modal')&&r.top>200});
      const rects=bs.map(b=>[b.id||b.textContent.trim().slice(0,6),b.getBoundingClientRect()]);let over=[];for(let i=0;i<rects.length;i++)for(let j=i+1;j<rects.length;j++){const a=rects[i][1],c=rects[j][1];if(a.left<c.right-2&&c.left<a.right-2&&a.top<c.bottom-2&&c.top<a.bottom-2)over.push(rects[i][0]+'×'+rects[j][0])}
      const off=rects.filter(([n,r])=>r.left<0||r.right>innerWidth+1||r.bottom>innerHeight+1).map(x=>x[0]);return{n:rects.length,names:rects.map(x=>x[0]),overlap:over,offscreen:off}})()""")
    print(label,'HUD buttons',r['n'],r['names'],'| overlap',r['overlap'],'| offscreen',r['offscreen'])
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await newgame(pg,7,'ลีอา')
        miss=await pg.evaluate(f"(()=>{{const k={json.dumps(KEYS)};return{{th:k.filter(x=>!TX.th[x]),en:k.filter(x=>!TX.en[x])}}}})()")
        print('A. text keys missing',miss)
        await pg.evaluate("openBag()");await pg.wait_for_timeout(200)
        print('A. kid weapon after bag/migration:',await pg.evaluate("JSON.stringify({eq:GAME.S.eq,inv:GAME.S.inv.length,w:weapon().type})"),'| gift',await pg.evaluate("GIFT.get().length"))
        await pg.evaluate("closeModal()");await hudcheck(pg,'A. kid (kid mode)')
        # kid: beach fishing loop, 3 catches
        await pg.evaluate("goMap('beach','w')");await pg.wait_for_timeout(900)
        r=await pg.evaluate("""new Promise(res=>{const s=GAME.M.fishSpot;GAME.P.x=s.x;GAME.P.y=s.y;let n=0;const xp0=S.life.fish.xp+S.life.fish.lv*1000;const bag0=(S.fishBag||[]).length;
          const step=()=>{const F=FISHING;if(F.st==='idle'){fishAct();F.t=.05}else if(F.st==='bite'){fishAct();n++}if(n<3)setTimeout(step,120);else res({catches:n,bag:(S.fishBag||[]).length-bag0,xpGain:S.life.fish.xp+S.life.fish.lv*1000-xp0,species:Object.keys(S.fish||{})})};step()})""")
        print('A. kid beach fishing',r)
        # kid: dig + quiz in cave1
        await pg.evaluate("goMap('cave1','up')");await pg.wait_for_timeout(900);await pg.evaluate("while(DLG)nextLine()")
        r=await pg.evaluate("""new Promise(res=>{const d=GAME.M.digs[0];const x0=S.life.dig.xp;doDig(d);setTimeout(()=>{digHit();const x1=S.life.dig.xp;setTimeout(()=>{closeModal();PAUSE=false;const c=GAME.M.crystals[0];const k0=S.life.know.xp;openQuiz(c);setTimeout(()=>{const bs=[...document.querySelectorAll('.ch button')];bs.forEach(b=>b.click());setTimeout(()=>res({digXp:x1-x0,knowXp:S.life.know.xp-k0,crystalAwake:c.awake}),900)},300)},400)},300)})""")
        print('A. kid dig/quiz',r)
        # B. adult
        await newgame(pg,30,'พ่อ')
        await pg.evaluate("GAME.S.lv=40;GAME.S.job='sword';GAME.S.slots=['bash','guard'];GAME.S.learn=['bash','guard'];GAME.S.potions=3;hud()")
        await pg.evaluate("goMap('beach','w')");await pg.wait_for_timeout(900);await pg.evaluate("GAME.P.x=GAME.M.fishSpot.x;GAME.P.y=GAME.M.fishSpot.y;hud()");await pg.wait_for_timeout(300)
        await hudcheck(pg,'B. adult at fishing spot');await pg.screenshot(path='/home/claude/chunks/qa_hud_adult.png')
        # kills inflation
        await pg.evaluate("goMap('cave1','up')");await pg.wait_for_timeout(900);await pg.evaluate("while(DLG)nextLine()")
        r=await pg.evaluate("(()=>{S.tq={on:2,kills:0};const m=GAME.MONS[0];m.hp=1;m.hitByMe=1;monHit(m,999);const a=S.tq.kills;monHit(m,5);monHit(m,5);return{after1:a,afterExtraHits:S.tq.kills}})()")
        print('B. promotion kill count',r)
        # auto uses potions + meditate stands up when hit
        r=await pg.evaluate("""new Promise(res=>{GAME.M.crystals.forEach(c=>c.awake=true);S.hp=Math.round(hpMax()*.2);const p0=S.potions;AUTO.on=true;setTimeout(()=>{const p1=S.potions;AUTO.on=false;P.sit=1;hurtPlayer(1);res({potionsUsed:p0-p1,hpPct:Math.round(S.hp/hpMax()*100),sitAfterHit:P.sit})},1500)})""")
        print('B. auto potion / sit',r)
        # EN texts in new panels
        await pg.evaluate("LANG='en';openStats()");await pg.wait_for_timeout(200)
        print('B. EN detail',await pg.evaluate("document.getElementById('stDetail').innerText.replace(/\\n/g,' | ').slice(0,200)"))
        await pg.evaluate("closeModal();openQi()");await pg.wait_for_timeout(150);print('B. EN qi',await pg.evaluate("document.querySelector('#modal,.modal').innerText.slice(0,120).replace(/\\n/g,' | ')"))
        await pg.evaluate("closeModal();LANG='th'")
        # C. story: second win no scene; reload inside a land
        await pg.evaluate("setChap(4);goMap('forest2','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
        for k in [1,2]:
            await pg.evaluate("GAME.M.landDone=0;GAME.M.boss.happy=0;GAME.M.boss.hp=1;GAME.M.boss.hitByMe=1;monHit(GAME.M.boss,99999)");await pg.wait_for_timeout(2400)
            print(f'C. forest boss win #{k}: scene',await pg.evaluate("DLG?DLG.lines[0][1]:'none'"));await pg.evaluate("while(DLG)nextLine();closeModal&&closeModal()")
        await pg.evaluate("save()");await pg.reload();await pg.wait_for_timeout(2500)
        print('C. reload inside land ->',await pg.evaluate("GAME.M&&GAME.M.id"),'themed',await pg.evaluate("!!(GAME.M&&GAME.M._themed)"))
        t0=await pg.evaluate("performance.now()");await pg.evaluate("goMap('sky1','up')");print('C. first entry to sky1 ms',round(await pg.evaluate("performance.now()")-t0))
        print('errors',errs[:4]);await br.close()
asyncio.run(main())
