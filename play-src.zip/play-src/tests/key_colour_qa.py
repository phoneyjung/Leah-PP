# Key-colour QA: every check must print 0 before a key-colour character ships.
# green/teal = key colour left over after recolouring · whiteChanged = white/near-white pixels (shirt, eye sparkle) that changed
import asyncio,os
from playwright.async_api import async_playwright
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page()
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800)
        r=await pg.evaluate("""(()=>{const out=[];for(const k of KIDS.filter(x=>x[3]).map(x=>x[0]))for(const key of ['s_','w_','i_']){const src=IMG[key+k];if(!src)continue;const o=toCanvas(src).getContext('2d').getImageData(0,0,src.width,src.height).data;
          for(let h=0;h<4;h++)for(const [hc,ec] of [[4,3],[0,0],[2,2],[6,4]]){const d=keyFirst(src,hc,ec,HOUSES[h].h,[[0,1]]).getContext('2d').getImageData(0,0,src.width,src.height).data;let green=0,teal=0,white=0;
            for(let i=0;i<d.length;i+=4){if(d[i+3]<60)continue;const [hh,s,l]=hslOf(d[i]/255,d[i+1]/255,d[i+2]/255),cc=(Math.max(d[i],d[i+1],d[i+2])-Math.min(d[i],d[i+1],d[i+2]))/255;
              if(h!==2&&hc!==7&&ec!==2&&cc>.06&&hh>=45&&hh<=170&&s>.12&&l>.06)green++;if(h!==1&&cc>.08&&hh>=150&&hh<=215&&s>.15&&l>.15&&ec!==3)teal++;
              const mx=Math.max(o[i],o[i+1],o[i+2]),mn=Math.min(o[i],o[i+1],o[i+2]),[h0]=hslOf(o[i]/255,o[i+1]/255,o[i+2]/255);if(mx>200&&mx-mn<20&&!(h0>=130&&h0<=230)&&(d[i]!==o[i]||d[i+1]!==o[i+1]||d[i+2]!==o[i+2]))white++}
            out.push([k,key,HOUSES[h].id,hc,ec,green,teal,white])}}return out})()""")
        bad=[x for x in r if x[5] or x[6] or x[7]]
        print('checked',len(r),'combinations | failing',len(bad));[print('  ',x) for x in bad[:10]]
        await br.close()
asyncio.run(main())
