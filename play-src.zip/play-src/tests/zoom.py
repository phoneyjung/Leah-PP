import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MEAS="""()=>new Promise(res=>{let n=0,t0=performance.now();function f(){n++;GAME.P.path=[[GAME.P.x+30,GAME.P.y]];if(performance.now()-t0<2500)requestAnimationFrame(f);else res(Math.round(n/2.5))}requestAnimationFrame(f)})"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=3,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'day';goMap('plaza')");await pg.wait_for_timeout(1500)
        for z in [1,.8,.65]:
            await pg.evaluate(f"setZoom({z},true)");await pg.wait_for_timeout(700)
            info=await pg.evaluate("({SC,VW,VH,tilesW:(VW/32).toFixed(1),tilesH:(VH/32).toFixed(1)})")
            fps=await pg.evaluate(MEAS)
            await pg.evaluate("GAME.P.x=18*32;GAME.P.y=12*32;GAME.P.path=null");await pg.wait_for_timeout(500);await pg.screenshot(path=f'/home/claude/chunks/zoom_{int(z*100)}.png')
            # tap conversion still lands where we tap: tap the shrine on screen
            print('zoom',z,info,'fps',fps)
        # tap-to-walk works at far zoom
        r=await pg.evaluate("(()=>{const x=(GAME.P.x+100-camX)*SC/(devicePixelRatio||1),y=(GAME.P.y-camY)*SC/(devicePixelRatio||1);return{x,y}})()")
        await pg.mouse.click(r['x'],r['y']);await pg.wait_for_timeout(600)
        print('tap at far zoom moved player:',await pg.evaluate("Math.round(GAME.P.x/32)"))
        await pg.evaluate("goMap('cave1','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
        print('cave at far zoom fps',await pg.evaluate(MEAS))
        await pg.evaluate("openSettings()");await pg.wait_for_timeout(200);print('settings zoom row:',await pg.evaluate("document.getElementById('zoomRow').innerText.replace(/\\n/g,' ')"))
        await pg.reload();await pg.wait_for_timeout(2600);print('zoom kept after reload:',await pg.evaluate("ZOOM"),await pg.evaluate("SC"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
