import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');GAME.S.lv=34;GAME.S.job='sword';GAME.S.tier=1;GAME.S.chap=3;GAME.S.coins=5000")
        r=await pg.evaluate("""(()=>{const o={hp0:hpMax(),atk0:atkPow()};S.qi={hp:10,cdmg:10,combo:5};o.hp1=hpMax();o.critMul=critMul();o.qiLeft=qiTotal()-qiSpent();return o})()""")
        print('qi effects',r)
        await pg.evaluate("openJobs()");await pg.wait_for_timeout(300)
        print('promo panel:',await pg.evaluate("!!document.getElementById('tqStart')"),'qi button',await pg.evaluate("!!document.getElementById('qiOpen')"))
        await pg.click('#tqStart');await pg.wait_for_timeout(200)
        await pg.evaluate("GAME.S.tq.kills=60;closeModal();openJobs()");await pg.wait_for_timeout(200)
        await pg.click('#tqDone');await pg.wait_for_timeout(200)
        print('after promotion tier',await pg.evaluate("GAME.S.tier"),'| title',await pg.evaluate("tierName()"),'| hp now',await pg.evaluate("hpMax()"),'atk',await pg.evaluate("atkPow()"))
        await pg.evaluate("closeModal();openStats()");await pg.wait_for_timeout(200)
        print('detail panel',await pg.evaluate("document.getElementById('stDetail')&&document.getElementById('stDetail').innerText.split('\\n').slice(0,11).join(' | ')"))
        await pg.evaluate("closeModal()")
        # miss rate at cave1 for a fresh-level player vs lv34
        r=await pg.evaluate("""(()=>{GAME.goMap('cave1','up');const mo=GAME.MONS[0];const out={};for(const lv of [1,10,34]){S.lv=lv;let h=0;for(let i=0;i<4000;i++)if(Math.random()<=hitCh(mo))h++;out['lv'+lv]=(h/4000*100).toFixed(1)+'%'}S.lv=34;return out})()""")
        print('hit rate in cave1',r)
        # auto: not allowed until cleared; then allowed and attacks
        await pg.wait_for_timeout(600)
        r=await pg.evaluate("""new Promise(res=>{const before=mapCleared();GAME.M.crystals.forEach(c=>c.awake=true);const after=mapCleared();AUTO.on=true;const hp0=GAME.MONS.filter(m=>!m.happy).length;setTimeout(()=>res({clearedBefore:before,clearedAfter:after,autoOn:AUTO.on,target:!!(GAME.P.target),calmedIn6s:hp0-GAME.MONS.filter(m=>!m.happy).length}),6000)})""")
        print('auto',r)
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
