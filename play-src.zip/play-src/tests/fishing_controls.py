import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        for mid in ['beach','falls','lake','mountain']:
            r=await pg.evaluate(f"""(()=>{{delete CACHE['{mid}'];const m=GAME.getMap('{mid}');const s=m.spawnDefault;let free=0,ok=0;for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){{if(m.SOLID.has(x+','+y))continue;free++;if(GAME.findPath(m,s[0],s[1],x*32+16,y*32+16))ok++}}
              const ex=m.exits.filter(e=>!e.locked).map(e=>[e.id,e.to,!!GAME.findPath(m,s[0],s[1],e.x,Math.min(e.y,m.h*32-20))]);const fs=m.fishSpot?!!GAME.findPath(m,s[0],s[1],m.fishSpot.x,m.fishSpot.y):null;return{{reach:ok+'/'+free,exits:ex,fishSpot:fs}}}})()""")
            print(mid,r)
        # fish per place: roll 3000 times each
        for mid in ['lake','beach','falls']:
            r=await pg.evaluate(f"""(()=>{{GAME.goMap('{mid}');const c={{}};for(let i=0;i<3000;i++){{const f=rollFish();c[f]=(c[f]||0)+1}}return c}})()""")
            await pg.wait_for_timeout(300);print('fish in',mid,dict(sorted(r.items(),key=lambda x:int(x[0]))))
        await pg.evaluate("GAME.goMap('falls','w')");await pg.wait_for_timeout(900);await pg.screenshot(path='/home/claude/chunks/falls.png')
        await pg.evaluate("GAME.goMap('beach','w')");await pg.wait_for_timeout(900);await pg.evaluate("GAME.P.x=GAME.M.fishSpot.x;GAME.P.y=GAME.M.fishSpot.y-10");await pg.wait_for_timeout(600);await pg.screenshot(path='/home/claude/chunks/beach.png')
        # controls: dash moves, meditation heals, number keys
        r=await pg.evaluate("""new Promise(res=>{GAME.goMap('plaza');setTimeout(()=>{const x0=GAME.P.x;lastMove.x=1;lastMove.y=0;doDash();setTimeout(()=>{const moved=Math.round(GAME.P.x-x0);GAME.S.hp=5;toggleSit();setTimeout(()=>res({dashMoved:moved,sit:!!GAME.P.sit,hpAfter2s:GAME.S.hp,max:hpMax()}),2100)},400)},700)})""")
        print('controls',r)
        print('buttons',await pg.evaluate("[!!document.getElementById('bDash'),!!document.getElementById('bSit')]"),'errors',errs[:3]);await br.close()
asyncio.run(main())
