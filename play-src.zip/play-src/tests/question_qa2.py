import json,glob,re,collections
QS=[]
for f in sorted(glob.glob(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'..','..','q-*.json'))):
    for q in json.load(open(f,encoding='utf-8'))['questions']:q['_f']=f.split('/')[-1];QS.append(q)
fb=json.load(open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'..','src','fallback_q.json'),encoding='utf-8'));print('fallback questions',len(fb) if isinstance(fb,list) else type(fb))
def num(s):
    s=str(s).replace(',','').strip()
    m=re.fullmatch(r'-?\d+(\.\d+)?',s);return float(s) if m else None
bad=collections.defaultdict(list)
OPS={'+':lambda a,b:a+b,'-':lambda a,b:a-b,'−':lambda a,b:a-b,'×':lambda a,b:a*b,'x':lambda a,b:a*b,'÷':lambda a,b:a/b if b else None}
for q in QS:
    th=q['th'];cor=th['choices'][q['answer']]
    # 1) every equation written in an explanation must be arithmetically right
    for L in ['th','en']:
        for m in re.finditer(r'(\d+)\s*([+\-−×x÷])\s*(\d+)\s*=\s*(\d+)',q[L]['explain']):
            a,op,b,c=int(m.group(1)),m.group(2),int(m.group(3)),int(m.group(4));v=OPS[op](a,b)
            if v is None or abs(v-c)>1e-9:bad['explain_equation_wrong'].append((q['id'],L,m.group(0)))
    # 2) math: the last number in the explanation should be the correct answer when the answer is a number
    if q['subject']=='math' and num(cor) is not None:
        nums=re.findall(r'\d+(?:\.\d+)?',th['explain'].replace(',',''))
        if nums and num(nums[-1])!=num(cor) and str(cor).strip() not in th['explain']:bad['math_explain_not_answer'].append((q['id'],th['q'][:60],cor,th['explain'][:70]))
    # 3) english rhymes: exactly one choice may share the target's ending
    m=re.search(r'สัมผัสเสียงเดียวกับ\s*"([a-z]+)"',th['q'])
    if m:
        tg=m.group(1);end=tg[-2:] if tg[-1] not in 'e' else tg[-3:]
        hits=[c for c in th['choices'] if c.lower().endswith(end) and c.lower()!=tg]
        if len(hits)!=1 or cor not in hits:bad['rhyme_check'].append((q['id'],tg,th['choices'],cor))
    # 4) "starts with which letter": the answer letter must be the first letter of the word named in the explanation
    if 'starts with which letter' in q['en']['q'] or 'ขึ้นต้นด้วยตัวอักษร' in th['q']:
        w=re.search(r'\b([A-Za-z]{2,})\b',q['en']['explain'])
        if w and w.group(1)[0].lower()!=cor.strip()[0].lower():bad['first_letter'].append((q['id'],q['en']['explain'][:60],cor))
    # 5) odd/even wording vs explanation
    if 'เลขคี่' in th['q'] and 'เลขคี่' not in th['explain']:bad['odd_even_explain'].append((q['id'],th['q'][:50],th['explain'][:60]))
    if 'เลขคู่' in th['q'] and 'เลขคู่' not in th['explain']:bad['odd_even_explain'].append((q['id'],th['q'][:50],th['explain'][:60]))
    # 6) the correct choice should appear in (or be consistent with) the explanation for non-math subjects
    if q['subject'] in('general','thai','chinese') and cor.strip() and cor.strip() not in th['explain'] and len(cor)<=12:bad['explain_skips_answer'].append((q['id'],q['subject'],th['q'][:50],cor,th['explain'][:60]))
# exact duplicates (same text and same correct answer)
seen=collections.defaultdict(list)
for q in QS:seen[(q['_f'],q['th']['q'].strip(),q['th']['choices'][q['answer']].strip())].append(q['id'])
bad['exact_duplicates']=[v for v in seen.values() if len(v)>1]
for k,v in bad.items():
    print(f'## {k}: {len(v)}');[print('   ',x) for x in v[:8]]
