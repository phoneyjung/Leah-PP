import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MOCK=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'mock_firebase.txt')).read().split('MOCK=r"""')[1].split('"""')[0]
# extend the stand-in database: time queries, remove, .info/connected
MOCK=MOCK.replace("transaction:f=>setp(p,f(get(p)))}}","transaction:f=>setp(p,f(get(p))),once:async()=>({val:()=>JSON.parse(JSON.stringify(get(p)||null))}),orderByChild:()=>({endAt:c=>({limitToFirst:n=>({ref:ref(p),once:async()=>({val:()=>{const v=get(p)||{},o={};for(const [k,x] of Object.entries(v))if(x&&x.t<=c)o[k]=x;return o}})})})}),remove:()=>setp(p,null)}}")
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        # 1) Firebase unreachable: friendly message, keeps retrying, game keeps running
        await pg.evaluate("window.FB_CONFIG={apiKey:'x'};Net.init=async()=>false;Net.autoJoin('FAM1')");await pg.wait_for_timeout(300)
        print('offline message:',await pg.evaluate("document.getElementById('msg').textContent"),'| still playing (not paused):',not await pg.evaluate("PAUSE"))
        # 2) sweeping old records (fresh page so Firebase is not stubbed out)
        await pg.reload();await pg.wait_for_timeout(1800);await pg.evaluate("GAME.S&&(GAME.S.seen={intro:1})");await pg.wait_for_timeout(300)
        await pg.evaluate(MOCK+";Net.loadScript=async()=>{};");await pg.evaluate("Net.join('fam1')");await pg.evaluate("GAME.goMap('cave1','up')");await pg.wait_for_timeout(400)
        await pg.evaluate("const n=Date.now();for(let i=0;i<5;i++)__mock.setp('rooms/FAM1/maps/cave1/hits/old'+i,{i:0,d:1,u:'x',t:n-120000});__mock.setp('rooms/FAM1/maps/cave1/hits/new1',{i:0,d:1,u:'x',t:n});for(let i=0;i<3;i++)__mock.setp('rooms/FAM1/emotes/e'+i,{u:'x',e:'❤️',t:n-90000})")
        print('debug:',await pg.evaluate("(async()=>{try{const q=Net.mref.child('hits');const s=await q.orderByChild('t').endAt(Date.now()-45000).limitToFirst(60).once('value');return {online:Net.online,hasRef:!!Net.ref,host:Net.isHost(),found:Object.keys(s.val()||{})}}catch(e){return 'ERR '+e.message}})()"))
        await pg.evaluate("Net.sweep()");await pg.wait_for_timeout(500)
        print('hits left after sweep:',await pg.evaluate("Object.keys(__mock.get('rooms/FAM1/maps/cave1/hits')||{})"),'| emotes left:',len(await pg.evaluate("Object.keys(__mock.get('rooms/FAM1/emotes')||{})")))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
