import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('file:///home/claude/play/play-preview.html');await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');goMap('capital')");await pg.wait_for_timeout(1500)
        r=await pg.evaluate("""(()=>{const m=GAME.M,c=document.createElement('canvas');c.width=m.w*32;c.height=m.h*32;const g=c.getContext('2d');g.drawImage(m.ground,0,0);const d=g.getImageData(0,0,c.width,c.height).data;
          const col=(x,y)=>{const i=((y*32+16)*c.width+x*32+8)*4;return[d[i],d[i+1],d[i+2]]};
          // what the picture shows at each tile vs. what blocks: grass/road/zone colours must be walkable, water/wall/building/bush must block
          const walkCols=new Set(['111,154,82','106,149,78','232,220,192','239,228,200','205,184,143','241,230,204','140,106,74','240,220,174','234,220,196','243,230,204','184,134,46','154,111,176','200,106,138','79,154,216','201,160,216','217,160,192','154,107,63','107,74,42','242,227,179','224,122,95']),skip=new Set(['20,14,36','255,231,176','140,122,90','58,30,63']);
          let mism=[],solid=0;for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){const k=x+','+y,s=m.SOLID.has(k);if(s)solid++;const cc=col(x,y).join(',');if(skip.has(cc))continue;const w=walkCols.has(cc);if(w===s)mism.push(k+'('+cc+(s?' solid':' walk')+')')}
          const s0=m.spawnDefault;let free=0,ok=0;for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){if(m.SOLID.has(x+','+y))continue;free++;if(GAME.findPath(m,s0[0],s0[1],x*32+16,y*32+16))ok++}
          return{solid,mismatch:mism.length,sample:mism.slice(0,8),reach:ok+'/'+free,exits:m.exits.map(e=>e.id+':'+!!GAME.findPath(m,s0[0],s0[1],e.x,Math.max(8,Math.min(e.y,m.h*32-12)))),walkers:m.walkers.length}})()""")
        print(r)
        # walk each diagonal end to end and across every bridge
        for name,(a,b) in {'NW diag':((44,30),(18,13)),'NE diag':((53,30),(78,13)),'SW diag to promenade':((44,37),(39,48)),'SE diag':((53,37),(74,49)),'W avenue bridge':((36,33),(24,33)),'promenade bridge':((42,50),(30,50)),'NW bridge':((29,20),(24,18)),'north gate road':((48,30),(48,1)),'orchard':((48,10),(31,6)),'playground':((70,50),(86,56)),'pavilion':((30,50),(6,57))}.items():
            ok=await pg.evaluate(f"!!GAME.findPath(GAME.M,{a[0]}*32+16,{a[1]}*32+16,{b[0]}*32+16,{b[1]}*32+16)")
            print(f'{name:18s} walkable end to end: {ok}')
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
