import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        r=await pg.evaluate("""(()=>{const o={};fixLife();o.bite0=fishBiteMul();o.dig0=digMul();o.farm0=farmMul();
          for(let i=0;i<40;i++)lifeXp('fish',30);for(let i=0;i<10;i++)lifeXp('dig',30);o.fishLv=lifeLv('fish');o.digLv=lifeLv('dig');o.bite1=fishBiteMul();o.wait1=fishWaitMul();o.dig1=digMul();
          GAME.S.coins=2000;return o})()""")
        print('life skills:',r)
        await pg.evaluate("openBag()");await pg.wait_for_timeout(300)
        print('kid bag opened:',await pg.evaluate("!!document.querySelector('[data-tool]')"),'| tool buttons',await pg.evaluate("document.querySelectorAll('[data-tool]').length"))
        await pg.click('[data-tool="rod"]');await pg.wait_for_timeout(200)
        print('rod after upgrade:',await pg.evaluate("tool('rod')"),'coins',await pg.evaluate("GAME.S.coins"),'| bite mul',await pg.evaluate("fishBiteMul().toFixed(2)"))
        await pg.screenshot(path='/home/claude/chunks/kb.png')
        await pg.evaluate("closeModal()")
        # kid picks a weapon drop -> family box
        await pg.evaluate("pickUp({k:'item',item:mkItem('sw',2),x:GAME.P.x,y:GAME.P.y})")
        print('gift box after kid pickup:',await pg.evaluate("GIFT.get().length"),'| kid inv size',await pg.evaluate("(GAME.S.inv||[]).length"))
        # quiz hint (knowledge 3+)
        await pg.evaluate("for(let i=0;i<12;i++)lifeXp('know',40)")
        print('know lv',await pg.evaluate("lifeLv('know')"))
        await pg.evaluate("GAME.goMap('cave1','up')");await pg.wait_for_timeout(800)
        await pg.evaluate("(()=>{const c=GAME.M.crystals[0];openQuiz(c)})()");await pg.wait_for_timeout(400)
        print('hint button:',await pg.evaluate("!!document.getElementById('qHint')"))
        await pg.click('#qHint');await pg.wait_for_timeout(100)
        print('wrong choices disabled by hint:',await pg.evaluate("document.querySelectorAll('.ch button[disabled]').length"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
