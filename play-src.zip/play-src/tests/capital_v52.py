import asyncio,json
from playwright.async_api import async_playwright
URL='file:///home/claude/play/play-preview.html'
MEAS="""()=>new Promise(res=>{let n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<2500)requestAnimationFrame(f);else res(Math.round(n/2.5))}requestAnimationFrame(f)})"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=3,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'dusk';goMap('capital')");await pg.wait_for_timeout(2000)
        r=await pg.evaluate("""(()=>{const m=GAME.M,s=m.spawnDefault;const ok=(x,y)=>!!GAME.findPath(m,s[0],s[1],x,y);let free=0,rc=0;for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){if(m.SOLID.has(x+','+y))continue;free++;if(ok(x*32+16,y*32+16))rc++}
          const doors=Object.entries(m.capDoors).map(([n,[x,y]])=>n+':'+ok(x*32,y*32));
          return{reach:rc+'/'+free,exits:m.exits.map(e=>e.id+':'+ok(e.x,Math.max(8,Math.min(e.y,m.h*32-12)))),board:ok(m.board.x,m.board.y+8),doors,routes:m.routesOk,spawnSolid:m.SOLID.has(Math.floor(s[0]/32)+','+Math.floor(s[1]/32))}})()""")
        print(json.dumps(r,ensure_ascii=False))
        # terrace logic: from the lakeside you can only reach the upper terrace through stairs (count distinct crossings of each wall row)
        p0=await pg.evaluate("GAME.M.walkers.map(w=>[Math.round(w.o.x),Math.round(w.o.y)])");await pg.wait_for_timeout(3000);p1=await pg.evaluate("GAME.M.walkers.map(w=>[Math.round(w.o.x),Math.round(w.o.y)])")
        print('walkers moving',sum(1 for a,b in zip(p0,p1) if a!=b),'/',len(p0),'| on solid',await pg.evaluate("GAME.M.walkers.filter(w=>GAME.M.SOLID.has(Math.floor(w.o.x/32)+','+Math.floor((w.o.y-2)/32))).length"))
        for z in [1,.4]:
            await pg.evaluate(f"setZoom({z},true);GAME.P.x=48*32;GAME.P.y=38*32;GAME.P.path=null");await pg.wait_for_timeout(1200)
            print('zoom',z,'fps',await pg.evaluate(MEAS));await pg.screenshot(path=f'/home/claude/chunks/g52_{int(z*100)}.png')
        for ex,to in [('w','home'),('e','market'),('n','mountain'),('s','lake')]:
            await pg.evaluate("goMap('capital')");await pg.wait_for_timeout(600)
            await pg.evaluate(f"(()=>{{const e=GAME.M.exits.find(e=>e.id==='{ex}');GAME.P.x=Math.max(20,Math.min(e.x,GAME.M.w*32-20));GAME.P.y=Math.max(24,Math.min(e.y,GAME.M.h*32-14));GAME.P.path=[[e.x,e.y]]}})()");await pg.wait_for_timeout(1800)
            print('gate',ex,'->',await pg.evaluate("GAME.M.id"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
