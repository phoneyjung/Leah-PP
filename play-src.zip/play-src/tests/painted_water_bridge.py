import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');goMap('plaza')");await pg.wait_for_timeout(1200)
        # every walkable tile: how much water colour does it contain? (should be ~none, except the bridge deck)
        r=await pg.evaluate("""(()=>{const m=GAME.M,c=document.createElement('canvas');c.width=m.w*32;c.height=m.h*32;const g=c.getContext('2d');g.drawImage(m.ground,0,0);const d=g.getImageData(0,0,c.width,c.height).data;
          const isW=(r,gg,b)=>(b>r+25&&b>gg+5&&b>70)||(b>r+10&&b>=gg&&b<90&&b>40);const wet=[];
          for(let ty=0;ty<m.h;ty++)for(let tx=0;tx<m.w;tx++){const k=tx+','+ty;if(m.SOLID.has(k))continue;let w=0,n=0;for(let oy=1;oy<32;oy+=3)for(let ox=1;ox<32;ox+=3){n++;const i=((ty*32+oy)*c.width+tx*32+ox)*4;if(isW(d[i],d[i+1],d[i+2]))w++}if(w/n>.25)wet.push(k+':'+Math.round(w/n*100)+'%')}
          const s=m.spawnDefault;return{water:m.WATER.size,walkableWet:wet,bridge:!!GAME.findPath(m,4*32,10*32+16,13*32,10*32+16),exits:m.exits.filter(e=>!e.locked).map(e=>e.id+':'+!!GAME.findPath(m,s[0],s[1],e.x,Math.max(8,Math.min(e.y,m.h*32-12))))}})()""")
        print(r)
        # walk across the bridge from the west and watch feet y on the deck
        await pg.evaluate("GAME.P.x=4*32;GAME.P.y=11*32;GAME.P.path=GAME.findPath(GAME.M,GAME.P.x,GAME.P.y,13*32,11*32)");ys=[]
        for i in range(12):
            await pg.wait_for_timeout(250);ys.append(await pg.evaluate("[Math.round(GAME.P.x/32*10)/10,Math.round(GAME.P.y/32*10)/10]"))
        print('crossing (tile x,y):',ys)
        await pg.evaluate("GAME.P.x=9*32;GAME.P.y=10*32+16;GAME.P.path=null");await pg.wait_for_timeout(900);await pg.screenshot(path='/home/claude/chunks/bridge_fix.png')
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
