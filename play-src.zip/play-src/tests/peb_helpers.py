import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MOCK=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'mock_firebase.txt')).read().split('MOCK=r"""')[1].split('"""')[0]
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        print('peb sheet:',await pg.evaluate("[IMG.npc_peb.width,IMG.npc_peb.height,!!IMG.npc_peb_old]"))
        # save the sheet to look at it
        data=await pg.evaluate("IMG.npc_peb.toDataURL()");import base64;open('/home/claude/chunks/peb_sheet.png','wb').write(base64.b64decode(data.split(',')[1]))
        # Peb in the world: cave 3 (Peb follows there) 
        await pg.evaluate("S.peb=true;PEB.on=true;goMap('cave1','up')");await pg.wait_for_timeout(900);await pg.evaluate("while(DLG)nextLine();PEB.on=true;PEB.x=GAME.P.x+30;PEB.y=GAME.P.y")
        await pg.wait_for_timeout(400);await pg.screenshot(path='/home/claude/chunks/peb_world.png')
        # walk to goal by tapping the goal line
        r=await pg.evaluate("new Promise(res=>{const x0=GAME.P.x,y0=GAME.P.y;document.getElementById('goal').click();setTimeout(()=>res({path:!!(GAME.P.path&&GAME.P.path.length)||Math.hypot(GAME.P.x-x0,GAME.P.y-y0)>5,modal:!!document.querySelector('#modal:not(.hide) h2')}),700)})")
        print('tap goal -> walking:',r)
        await br.close()
        # adult: loot filter + follow
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        r=await pg.evaluate("(()=>{S.lootMin=1;const a={k:'item',item:mkItem('sw',0),x:0,y:0},b={k:'item',item:mkItem('sw',1),x:0,y:0},c={k:'coin',n:5,x:0,y:0};pickUp(a);pickUp(b);pickUp(c);return{plainLeft:!a.taken,blueTaken:!!b.taken,coinTaken:!!c.taken}})()")
        print('loot filter blue+:',r)
        await pg.evaluate("openSettings()");await pg.wait_for_timeout(200);print('filter in settings:',await pg.evaluate("!!document.getElementById('lootMin')"));await pg.evaluate("closeModal()")
        await pg.evaluate(MOCK+";Net.loadScript=async()=>{};");await pg.evaluate("window.FB_CONFIG={apiKey:'x'};Net.join('fam1')");await pg.wait_for_timeout(400)
        await pg.evaluate("__mock.setp('rooms/FAM1/players/kid9',{n:'ลีอา',k:0,h:0,a:1,lv:3,m:GAME.M.id,x:GAME.P.x+200,y:GAME.P.y,r:0,w:0,z:0})");await pg.wait_for_timeout(700)
        await pg.evaluate("hud()");print('follow button visible:',await pg.evaluate("getComputedStyle(document.getElementById('bFollow')).display!=='none'"))
        r=await pg.evaluate("new Promise(res=>{const d0=Math.hypot(Net.others.kid9.p.x-GAME.P.x,Net.others.kid9.p.y-GAME.P.y);followFamily();setTimeout(()=>res({following:FOLLOW,d0:Math.round(d0),d1:Math.round(Math.hypot(Net.others.kid9.p.x-GAME.P.x,Net.others.kid9.p.y-GAME.P.y))}),3000)})")
        print('follow:',r)
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
