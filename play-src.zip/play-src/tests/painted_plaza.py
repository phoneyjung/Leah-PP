import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'day';goMap('plaza')");await pg.wait_for_timeout(1200)
        print('painted:',await pg.evaluate("GAME.M.painted"),'| water tiles',await pg.evaluate("GAME.M.WATER.size"),'| solids',await pg.evaluate("GAME.M.SOLID.size"))
        print(await pg.evaluate("""(()=>{const m=GAME.M,s=m.spawnDefault;const r={};r.exits=m.exits.filter(e=>!e.locked).map(e=>e.id+':'+(!!GAME.findPath(m,s[0],s[1],e.x,Math.max(8,Math.min(e.y,m.h*32-12)))));
          let free=0,ok=0;for(let y=0;y<m.h;y++)for(let x=0;x<m.w;x++){const k=x+','+y;if(m.SOLID.has(k))continue;free++;if(GAME.findPath(m,s[0],s[1],x*32+16,y*32+16))ok++}r.reach=ok+'/'+free;
          r.leah=(m.npcs||[]).map(n=>!!GAME.findPath(m,s[0],s[1],n.x,n.y+24));r.stone=!!GAME.findPath(m,s[0],s[1],m.stones[0].x,m.stones[0].y+20);r.board=!!GAME.findPath(m,s[0],s[1],m.board.x,m.board.y+20);return r})()"""))
        # walk from home side: enter plaza from the west gate and check where we stand
        await pg.evaluate("goMap('home');");await pg.wait_for_timeout(700);await pg.evaluate("goMap('plaza','w')");await pg.wait_for_timeout(900)
        print('arrive from home at tile',await pg.evaluate("[Math.floor(GAME.P.x/32),Math.floor(GAME.P.y/32),GAME.M.SOLID.has(Math.floor(GAME.P.x/32)+','+Math.floor(GAME.P.y/32))]"))
        # water tile overlay screenshot for review
        await pg.evaluate("GAME.P.x=18*32;GAME.P.y=14*32");await pg.wait_for_timeout(2600);await pg.screenshot(path='/home/claude/chunks/paint_center.png')
        await pg.evaluate("GAME.P.x=5*32;GAME.P.y=6*32");await pg.wait_for_timeout(500);print('behind NW house -> see-through:',await pg.evaluate("behindOcc(GAME.P.x,GAME.P.y)"));await pg.screenshot(path='/home/claude/chunks/paint_behind.png')
        await pg.evaluate("GAME.P.x=9*32;GAME.P.y=11*32");await pg.wait_for_timeout(500);await pg.screenshot(path='/home/claude/chunks/paint_bridge.png')
        # map of solids over painting
        import base64
        data=await pg.evaluate("""(()=>{const m=GAME.M,c=document.createElement('canvas');c.width=m.w*32;c.height=m.h*32;const g=c.getContext('2d');g.drawImage(m.ground,0,0);g.fillStyle='rgba(255,0,80,.35)';for(const k of m.SOLID){const [x,y]=k.split(',').map(Number);g.fillRect(x*32,y*32,32,32)}g.strokeStyle='rgba(255,255,0,.8)';for(const r of m.occ){g.strokeRect(r[0]*32,r[1]*32,(r[2]-r[0])*32,(r[3]-r[1])*32)}return c.toDataURL()})()""")
        open('/home/claude/chunks/paint_solids.png','wb').write(base64.b64decode(data.split(',')[1]))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
