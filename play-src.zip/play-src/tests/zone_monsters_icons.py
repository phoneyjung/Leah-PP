import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1,L5in:1,L6in:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=20;S.potions=3;setChap(7);hud()")
        await pg.wait_for_timeout(400)
        print('pixel icons:',await pg.evaluate("[...document.querySelectorAll('img.pxi')].map(i=>i.dataset.k).join(',')"))
        print('potion count kept:',await pg.evaluate("document.getElementById('bPot')&&document.getElementById('bPot').innerText.trim()"))
        await pg.screenshot(path='/home/claude/chunks/icons.png')
        out={}
        for mid,kind in [('forest1','moth'),('desert1','scarab'),('ulake1','crab'),('sky1','puff')]:
            await pg.evaluate(f"goMap('{mid}','up')");await pg.wait_for_timeout(1100);await pg.evaluate("while(DLG)nextLine();LEVT=null")
            r=await pg.evaluate(f"(()=>{{const m=GAME.MONS.filter(o=>o.kind==='{kind}');return{{n:m.length,art:!!MON_ART['{kind}0']}}}})()")
            out[mid]=r
            if mid=='desert1':
                await pg.evaluate(f"(()=>{{const m=GAME.MONS.find(o=>o.kind==='{kind}');if(m){{GAME.P.x=m.x-40;GAME.P.y=m.y}}}})()");await pg.wait_for_timeout(600);await pg.screenshot(path='/home/claude/chunks/scarab.png')
        print('signature monsters:',out)
        # calm one: card/pet paths use the base kind without errors
        r=await pg.evaluate("(()=>{const m=GAME.MONS.find(o=>o.kind==='puff');for(let i=0;i<40&&!m.happy;i++)monHit(m,999);for(let i=0;i<30;i++)drop(m);tryPet('puff');return{calmed:!!m.happy,cardsKinds:[...new Set((S.cards||[]).concat(DROPS.filter(d=>d.k==='card').map(d=>d.mon)))].join(',')}})()")
        print('calm + drops:',r)
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
