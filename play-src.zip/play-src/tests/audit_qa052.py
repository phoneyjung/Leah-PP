import asyncio,base64,io
from playwright.async_api import async_playwright
from PIL import Image
import numpy as np
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
SIG=np.array([[255,200,87],[127,224,255]]);FAM=np.array([[75,63,114],[58,30,63],[243,227,195],[27,19,48]])
def classify(img):
    a=np.asarray(img.convert('RGB').resize((img.width//4,img.height//4)),dtype=float).reshape(-1,3)
    dS=np.min(np.linalg.norm(a[:,None,:]-SIG[None],axis=2),axis=1);dF=np.min(np.linalg.norm(a[:,None,:]-FAM[None],axis=2),axis=1)
    # dark pixels (night/cave darkness) count as LA family (the dusk shadow), signal needs to be close and bright
    lum=a.mean(axis=1);sig=(dS<60);fam=(~sig)&((dF<45)|(lum<38));zone=~(sig|fam);n=len(a)
    return round(zone.sum()/n*100),round(fam.sum()/n*100),round(sig.sum()/n*100)
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page()
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L4in:1,L5in:1,L6in:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');setChap(7);S.lv=30")
        rows=[]
        for mid,ph in [('plaza','day'),('plaza','night'),('lake','night'),('beach','day'),('cave1',None),('forest1',None),('desert1',None),('ulake1',None),('sky1',None),('trial',None)]:
            await pg.evaluate(f"window.dayPhase=()=>'{ph or 'day'}';goMap('{mid}','up')");await pg.wait_for_timeout(1500);await pg.evaluate("while(DLG)nextLine();LEVT=null;msgT=0")
            await pg.wait_for_timeout(2600)  # let the map-name card fade
            data=await pg.evaluate("document.getElementById('c').toDataURL()");img=Image.open(io.BytesIO(base64.b64decode(data.split(',')[1])))
            z,f,s=classify(img);rows.append((mid+(' '+ph if ph else ''),z,f,s))
        print('map · zone% · LA family% · signal%');[print(f'  {r[0]:14s} {r[1]:3d} {r[2]:3d} {r[3]:3d}') for r in rows]
        await br.close()
asyncio.run(main())
