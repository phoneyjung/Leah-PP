import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        t0=await pg.evaluate("performance.now()") if False else 0
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(2200)
        r=await pg.evaluate("({plummed:PLUMMED.size,sample:Object.keys(IMG).filter(k=>IMG[k]&&IMG[k]._plum).slice(0,6).map(k=>k+':'+IMG[k]._plum),kidSheet:Object.keys(IMG).filter(k=>/^i_/.test(k)).map(k=>k+':'+(IMG[k]._plum||0)).slice(0,3),tilesUntouched:!IMG.ground._plum})")
        print('plum outlines:',r)
        await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');window.dayPhase=()=>'night';hud()")
        await pg.evaluate("goMap('plaza')");await pg.wait_for_timeout(2500)
        print('lanna strings:',await pg.evaluate("lannaPairs().length"),'| yi peng floating:',await pg.evaluate("YIPENG.length"))
        await pg.screenshot(path='/home/claude/chunks/lanterns_plaza.png')
        await pg.evaluate("goMap('lake','n')");await pg.wait_for_timeout(1500)
        print('krathongs:',await pg.evaluate("(GAME.M._kr||[]).length"),'| all on water:',await pg.evaluate("(GAME.M._kr||[]).every(k=>GAME.M.WATER.has(Math.floor(k.x/32)+','+Math.floor(k.y/32)))"))
        await pg.evaluate("(()=>{const k=GAME.M._kr&&GAME.M._kr[0];if(k){GAME.P.x=k.x;GAME.P.y=k.y-90}})()");await pg.wait_for_timeout(700);await pg.screenshot(path='/home/claude/chunks/lanterns_lake.png')
        await pg.evaluate("goMap('cave1','up')");await pg.wait_for_timeout(900);await pg.evaluate("while(DLG)nextLine()")
        print('decor crystals recoloured:',await pg.evaluate("(()=>{const o=GAME.M.objs.filter(o=>['dCyan','dShards'].includes(o.dk));return o.length+' objects, atlas '+[...new Set(o.map(x=>x.img))].join(',')})()"))
        await pg.evaluate("goMap('forest1','up')");await pg.wait_for_timeout(900);print('forest decor atlas:',await pg.evaluate("[...new Set(GAME.M.objs.filter(o=>['dCyan','dShards'].includes(o.dk)).map(x=>x.img))].join(',')"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
