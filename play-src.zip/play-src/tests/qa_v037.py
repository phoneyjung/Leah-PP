import asyncio,json,re
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MOCK=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'mock_firebase.txt')).read().split('MOCK=r"""')[1].split('"""')[0]
MODALS=['openBag','openStats','openJobs','openQi','openAuto','openWarp','openFishBook','openKitchen','openShop','openBoard','openWheel','openBackup','openDeco','openPets','openAch','openFossils','openSettings']
BAD=re.compile(r'undefined|NaN|\[object|\bnull\b|\$\{')
CAMEL=re.compile(r'(?<![A-Za-z])[a-z]{2,}[A-Z][A-Za-z]{2,}(?![A-Za-z])')
async def fresh(pg,age,lv=40):
    await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click(f'#ca button[data-a="{age}"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
    await pg.evaluate(f"GAME.S.seen={{intro:1,first:1,floor:1,boss:1}};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv={lv};if(!isKid()){{S.job='archer';S.slots=['shower','evade'];S.learn=['shower','evade'];S.coins=999;S.potions=2}}hud()")
async def scan_modals(pg,label):
    out=[]
    for lang in ['th','en']:
        await pg.evaluate(f"LANG='{lang}'")
        for fn in MODALS:
            try:
                await pg.evaluate(f"closeModal();try{{{fn}()}}catch(e){{window.__err=e.message}}");await pg.wait_for_timeout(120)
                r=await pg.evaluate("""(()=>{const m=document.querySelector('#modal')||document.querySelector('.modal');const e=window.__err;window.__err=null;if(!m||getComputedStyle(m).display==='none')return{open:false,err:e};
                  const txt=m.innerText;const st=getComputedStyle(m);const r=m.getBoundingClientRect();return{open:true,err:e,txt:txt.slice(0,4000),tall:m.scrollHeight>innerHeight+2,scrollable:['auto','scroll'].includes(st.overflowY)||m.scrollHeight<=m.clientHeight+2,wide:r.right>innerWidth+2}})()""")
                if r.get('err'):out.append((lang,fn,'ERROR',r['err'][:80]))
                if r.get('open'):
                    bad=BAD.findall(r['txt']);cam=[c for c in CAMEL.findall(r['txt']) if c not in ('phoneyjung',)]
                    if bad:out.append((lang,fn,'badtext',bad[:3]))
                    if cam:out.append((lang,fn,'rawkey?',cam[:4]))
                    if r['wide']:out.append((lang,fn,'too wide'))
                    if r['tall'] and not r['scrollable']:out.append((lang,fn,'tall not scrollable'))
            except Exception as e:out.append((lang,fn,'EXC',str(e)[:60]))
        await pg.evaluate("closeModal()")
    await pg.evaluate("LANG='th'")
    print(label,'modal issues:',out if out else 'none')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();errs=[]
        for vw,vh in [(844,390),(740,360),(1024,768)]:
            ctx=await br.new_context(viewport={'width':vw,'height':vh});pg=await ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
            await fresh(pg,30)
            await scan_modals(pg,f'adult {vw}x{vh}')
            r=await pg.evaluate("""(()=>{const bs=[...document.querySelectorAll('button')].filter(b=>{const r=b.getBoundingClientRect();return r.width>0&&!b.closest('#modal')&&!b.closest('.modal')});const off=bs.filter(b=>{const r=b.getBoundingClientRect();return r.left<-1||r.right>innerWidth+1||r.top<-1||r.bottom>innerHeight+1}).map(b=>b.id||b.textContent.trim().slice(0,8));return off})()""")
            print(f'adult {vw}x{vh} HUD offscreen:',r)
            if (vw,vh)==(844,390):
                await fresh(pg,7,3);await scan_modals(pg,'kid 844x390')
            await ctx.close()
        # old save migration
        ctx=await br.new_context(viewport={'width':844,'height':390});pg=await ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1500)
        await pg.evaluate("""(()=>{const s=newSave({name:'เก่า',kid:0,house:2,age:30});s.lv=22;s.boss=true;s.map='cave3';s.job='mage';s.inv=[mkItem('staff',1),mkItem('sw',2)];s.eq=0;delete s.life;delete s.tools;delete s.chap;delete s.qi;delete s.tier;const d=Store.all();d.slots=[s];d.cur=0;Store.put(d)})()""")
        await pg.reload();await pg.wait_for_timeout(2500)
        print('old save:',await pg.evaluate("({map:GAME.M&&GAME.M.id,chap:chap(),town:t('town'),lifeOk:!!(S.life&&S.life.fish),tier:S.tier,qiLeft:qiTotal()-qiSpent(),hp:S.hp+'/'+hpMax()})"))
        # second player on the same device + gift box shared
        await pg.evaluate("GIFT.add(mkItem('bow',2),'ลีอา')")
        await pg.evaluate("(()=>{const s=newSave({name:'น้อง',kid:3,house:1,age:7});s.hc=4;s.ec=3;const d=Store.all();d.slots.push(s);d.cur=-1;Store.put(d)})()");await pg.reload();await pg.wait_for_timeout(2200)
        print('picker shown:',await pg.evaluate("!!document.getElementById('pk')"),'slots',await pg.evaluate("document.querySelectorAll('#pk .pn').length"))
        await pg.evaluate("document.querySelectorAll('#pk .pn')[1].click()");await pg.wait_for_timeout(1800)
        await pg.evaluate("while(DLG)nextLine();PAUSE=false")
        print('switched to kid:',await pg.evaluate("({name:S.name,kid:isKid(),chap:chap(),town:t('town'),gift:GIFT.get().length,weapon:weapon().type})"))
        # hint daily reset, gift cap 40
        r=await pg.evaluate("(()=>{for(let i=0;i<50;i++)GIFT.add(mkItem('sw',0),'x');S.hintDay='old';S.hintN=3;const day=new Date().toDateString();return{giftCap:GIFT.get().length}})()")
        print('gift cap',r)
        # online mock: another player with hair/eye colours in a land, plus auto in co-op
        await pg.evaluate(MOCK+";Net.loadScript=async()=>{};");await pg.evaluate("window.FB_CONFIG={apiKey:'x'};Net.join('fam1')");await pg.wait_for_timeout(300)
        await pg.evaluate("setChap(4);goMap('forest1','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
        await pg.evaluate("__mock.setp('rooms/FAM1/players/other1',{n:'พ่อ',k:3,h:2,a:0,lv:30,m:Net.mapKey?Net.mapKey():'forest1',x:GAME.P.x+60,y:GAME.P.y,r:0,w:0,hc:4,ec:2,z:0})");await pg.wait_for_timeout(800)
        print('online other with colours:',await pg.evaluate("({others:Object.keys(Net.others||{}).length,drawn:!!document.querySelector('canvas')})"))
        await pg.evaluate("Net.leave&&Net.leave()")
        print('errors',errs[:5]);await br.close()
asyncio.run(main())
