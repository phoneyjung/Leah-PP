import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MOCK=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'mock_firebase.txt')).read().split('MOCK=r"""')[1].split('"""')[0]
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L3boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        await pg.evaluate(MOCK+";Net.loadScript=async()=>{};");await pg.evaluate("window.FB_CONFIG={apiKey:'x'};Net.join('fam1')");await pg.wait_for_timeout(300)
        await pg.evaluate("setChap(3);goMap('forest2','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
        # pretend another (older) player is host: add a player with a smaller uid so we are not host
        await pg.evaluate("__mock.setp('rooms/FAM1/players/000host',{n:'พ่อ',k:0,h:0,a:0,lv:30,m:Net.mapKey?Net.mapKey():'forest2',x:100,y:100,r:0,w:0,z:0})");await pg.wait_for_timeout(600)
        r=await pg.evaluate("""new Promise(res=>{const host=Net.isHost();const b=GAME.M.boss;kidCrystals().forEach(c=>c.awake=true);setTimeout(()=>{const hits=__mock.get('rooms/FAM1/maps/forest2/hits')||{};res({weAreHost:host,bossHappyLocal:!!b.happy,eventSent:Object.values(__mock.get('rooms/FAM1/maps/forest2/ev')||{}).some(e=>e.k==='kc'),noOversizedHit:!Object.values(hits).some(h=>h.d>500)})},900)})""")
        print(r,'errors',errs[:2]);await br.close()
asyncio.run(main())
