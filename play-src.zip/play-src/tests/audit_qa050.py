import asyncio,json,re
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
MOCK=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'mock_firebase.txt')).read().split('MOCK=r"""')[1].split('"""')[0]
MODALS=['openBag','openStore','openStats','openJobs','openQi','openAuto','openWarp','openFishBook','openKitchen','openShop','openFishSell','openBoard','openWheel','openBackup','openDeco','openPets','openAch','openFossils','openSettings','openRank','diaryRead','openRooms','openKidBag','openGiftBox']
BAD=re.compile(r'undefined|NaN|\[object|\bnull\b|\$\{')
CAMEL=re.compile(r'(?<![A-Za-z])[a-z]{2,}[A-Z][A-Za-z]{2,}(?![A-Za-z])')
async def fresh(pg,age,lv=40):
    await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click(f'#ca button[data-a="{age}"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
    await pg.evaluate(f"GAME.S.seen={{intro:1,first:1,floor:1,boss:1}};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv={lv};if(!isKid()){{S.job='archer';S.slots=['shower','evade'];S.learn=['shower','evade'];S.coins=999;S.potions=2;S.rank=10;S.diary=[0,1];setChap(7)}}hud()")
async def scan_modals(pg,label):
    out=[]
    for lang in ['th','en']:
        await pg.evaluate(f"LANG='{lang}'")
        for fn in MODALS:
            try:
                await pg.evaluate(f"closeModal();try{{{fn}()}}catch(e){{window.__err=e.message}}");await pg.wait_for_timeout(120)
                r=await pg.evaluate("""(()=>{const m=document.querySelector('#modal')||document.querySelector('.modal');const e=window.__err;window.__err=null;if(!m||getComputedStyle(m).display==='none')return{open:false,err:e};
                  const txt=m.innerText;const st=getComputedStyle(m);const r=m.getBoundingClientRect();return{open:true,err:e,txt:txt.slice(0,4000),tall:m.scrollHeight>innerHeight+2,scrollable:['auto','scroll'].includes(st.overflowY)||m.scrollHeight<=m.clientHeight+2,wide:r.right>innerWidth+2}})()""")
                if r.get('err'):out.append((lang,fn,'ERROR',r['err'][:80]))
                if r.get('open'):
                    bad=BAD.findall(r['txt']);cam=[c for c in CAMEL.findall(r['txt']) if c not in ('phoneyjung',)]
                    if bad:out.append((lang,fn,'badtext',bad[:3]))
                    if cam:out.append((lang,fn,'rawkey?',cam[:4]))
                    if r['wide']:out.append((lang,fn,'too wide'))
                    if r['tall'] and not r['scrollable']:out.append((lang,fn,'tall not scrollable'))
            except Exception as e:out.append((lang,fn,'EXC',str(e)[:60]))
        await pg.evaluate("closeModal()")
    await pg.evaluate("LANG='th'")
    print(label,'modal issues:',out if out else 'none')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();errs=[]
        for vw,vh in [(844,390),(740,360)]:
            ctx=await br.new_context(viewport={'width':vw,'height':vh});pg=await ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
            await fresh(pg,30)
            await scan_modals(pg,f'adult {vw}x{vh}')
            r=await pg.evaluate("""(()=>{const bs=[...document.querySelectorAll('button')].filter(b=>{const r=b.getBoundingClientRect();return r.width>0&&!b.closest('#modal')&&!b.closest('.modal')});const off=bs.filter(b=>{const r=b.getBoundingClientRect();return r.left<-1||r.right>innerWidth+1||r.top<-1||r.bottom>innerHeight+1}).map(b=>b.id||b.textContent.trim().slice(0,8));return off})()""")
            print(f'adult {vw}x{vh} HUD offscreen:',r)
            if (vw,vh)==(844,390):
                await fresh(pg,7,3);await scan_modals(pg,'kid 844x390')
            await ctx.close()
        print('errors',errs[:5]);await br.close()
asyncio.run(main())
