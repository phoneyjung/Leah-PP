import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')+'?rank=1'
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1500)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');hud()");await pg.wait_for_timeout(1300)
        vis=lambda: pg.evaluate("[...document.querySelectorAll('button')].filter(b=>{const r=b.getBoundingClientRect();return r.width>0&&!b.closest('#modal')&&!b.closest('.modal')&&getComputedStyle(b).display!=='none'&&!b.classList.contains('hide')}).map(b=>b.id).filter(Boolean)")
        print('class',await pg.evaluate("rank()"),'| visible buttons',await vis(),'| goal:',await pg.evaluate("document.getElementById('goal').textContent"))
        r=await pg.evaluate("(()=>{const e=GAME.M.exits.find(x=>x.to==='market');const m0=GAME.M.id;useExit(e);return{blocked:GAME.M.id===m0,msg:document.getElementById('msg').textContent}})()")
        print('market exit at class 1:',r)
        # play: wake 3 crystals in cave 1 -> class 2 scene
        await pg.evaluate("goMap('cave1','up')");await pg.wait_for_timeout(1000);await pg.evaluate("while(DLG)nextLine()")
        print('dig at class 1:',await pg.evaluate("(()=>{const d=GAME.M.digs[0];doDig(d);return !DIG})()"))
        await pg.evaluate("GAME.M.crystals.slice(0,3).forEach(c=>wakeCrystal(c,true))");await pg.wait_for_timeout(1800)
        print('after 3 crystals -> scene:',await pg.evaluate("DLG&&DLG.lines.map(l=>l[1]).join(',')"));await pg.evaluate("while(DLG)nextLine()");await pg.wait_for_timeout(300)
        print('class',await pg.evaluate("rank()"),'| compass button visible:',await pg.evaluate("getComputedStyle(document.getElementById('bCmp')).display!=='none'"),'| glowing:',await pg.evaluate("document.getElementById('bCmp').classList.contains('laNew')"))
        # walk the whole ladder quickly with the real triggers
        steps=["GAME.M.crystals.forEach(c=>wakeCrystal(c,true))","plotAct&&(()=>{const h=HOME.get();h.plots={0:{crop:'car',t:Date.now()}};HOME.put(h);S.planted=1})()","S.fishCaught=2","(S.crystals.cave2=['a','b','c'])","S.boss=true","S.trialN=1","setChap(4)","setChap(5)"]
        for s in steps:
            await pg.evaluate(s);await pg.wait_for_timeout(1400);sc=await pg.evaluate("DLG?DLG.lines[0][1]:'-'");await pg.evaluate("while(DLG)nextLine()");await pg.wait_for_timeout(200)
            print('  ',s[:34].ljust(34),'-> class',await pg.evaluate("rank()"),'scene',sc)
        await pg.evaluate("openRank()");await pg.wait_for_timeout(200);print('panel rows:',await pg.evaluate("document.querySelectorAll('#modal .pn,.modal .pn').length"))
        await pg.evaluate("closeModal()")
        # old save (no class yet) -> placed automatically
        await pg.evaluate("(()=>{const d=Store.all();const s=d.slots[d.cur];delete s.rank;s.boss=true;s.chap=3;s.fishCaught=0;d.slots[d.cur]=s;Store.put(d)})()");await pg.reload();await pg.wait_for_timeout(2600)
        print('old save with guardian done -> class',await pg.evaluate("S&&rank()"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
