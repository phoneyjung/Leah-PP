import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        await pg.evaluate("S.fishBag=[0,3,12,13,13,18,20];S.fish={0:10,3:30,12:14,13:9,18:12,20:50};const h=HOME.get();h.pantry.tom=2;HOME.put(h)")
        print('kinds',await pg.evaluate("[fishType(0),fishType(12),fishType(18),fishCount('sfish'),fishCount('ffish'),fishCount('fish')]"))
        await pg.evaluate("openFishBook()");await pg.wait_for_timeout(200)
        print('fish book top:',await pg.evaluate("document.getElementById('fbUse').innerText"))
        print('book entries:',await pg.evaluate("[...document.querySelectorAll('[data-f]')].slice(0,1).concat([...document.querySelectorAll('[data-f]')].slice(12,13)).map(s=>s.parentNode.innerText.replace(/\\n/g,' | '))"))
        await pg.screenshot(path='/home/claude/chunks/fishbook.png')
        await pg.evaluate("closeModal();openKitchen()");await pg.wait_for_timeout(200)
        print('kitchen:',await pg.evaluate("(document.querySelector('#modal .note')||document.querySelector('.modal .note')).innerText"),'| tomyum enabled',await pg.evaluate("!document.querySelector('[data-ck=\"tomyum\"]').disabled"),'| congee enabled',await pg.evaluate("!document.querySelector('[data-ck=\"congee\"]').disabled"))
        r=await pg.evaluate("(()=>{const a=cookDish('tomyum');const b=cookDish('congee');return{tomyum:a,congee:b,left:S.fishBag.slice(),sea:fishCount('sfish'),fresh:fishCount('ffish')}})()")
        print('cooked',r)
        await pg.evaluate("closeModal();openShop()");await pg.wait_for_timeout(200);await pg.click('#fsBtn');await pg.wait_for_timeout(200)
        c0=await pg.evaluate("S.coins");await pg.click('[data-sellall]');await pg.wait_for_timeout(200)
        print('sold: coins',c0,'->',await pg.evaluate("S.coins"),'| bag',await pg.evaluate("S.fishBag"))
        print('texts',await pg.evaluate("[t('coralSoon'),t('goalDone'),t('ch1done'),t('ch1next')]"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
