# run from the repo folder:  python3 -m http.server 8765  (then run this test)
import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto('http://localhost:8765/?title=1');await pg.wait_for_timeout(3500)
        print('title screen:',await pg.evaluate("!!document.getElementById('title')"),'| creator hidden until tap:',await pg.evaluate("document.getElementById('cr').classList.contains('hide')"))
        await pg.screenshot(path='/home/claude/chunks/title.png')
        await pg.click('#tGo',force=True);await pg.wait_for_timeout(900)
        print('after tap -> creator shown:',await pg.evaluate("!document.getElementById('cr').classList.contains('hide')"),'| title removed:',await pg.evaluate("!document.getElementById('title')"))
        r=await pg.evaluate("(async()=>{await navigator.serviceWorker.ready;await new Promise(r=>setTimeout(r,1200));const c=await caches.open((await caches.keys())[0]);const k=(await c.keys()).map(x=>x.url.split('/').pop());return{cache:(await caches.keys()).join(','),art:k.includes('title-art.jpg'),logo:k.includes('logo.png'),n:k.length}})()")
        print('cache',r)
        # missing pictures -> old flow, no white screen
        await pg.route('**/title-art.jpg',lambda route:route.abort());await pg.evaluate("caches.keys().then(ks=>Promise.all(ks.map(k=>caches.delete(k))))");await pg.evaluate("navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister()))")
        await pg.reload();await pg.wait_for_timeout(3500)
        print('art missing -> title skipped:',await pg.evaluate("!document.getElementById('title')"),'| creator shown:',await pg.evaluate("!document.getElementById('cr').classList.contains('hide')"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
