import asyncio,random,json,sys
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
CHECK="""(()=>{const bad=[];const S=GAME.S,P=GAME.P,M=GAME.M;if(!isFinite(P.x)||!isFinite(P.y))bad.push('player NaN');else if(blockedAt(M,P.x,P.y)&&!P.dead)bad.push('player inside wall '+M.id+' '+Math.round(P.x)+','+Math.round(P.y));
  if(!isFinite(S.coins)||S.coins<0)bad.push('coins '+S.coins);if(S.age>=12&&(!isFinite(S.hp)||S.hp<0||S.hp>hpMax()+1))bad.push('hp '+S.hp+'/'+hpMax());if(!isFinite(S.exp)||S.exp<0)bad.push('exp '+S.exp);
  for(const m of GAME.MONS)if(!isFinite(m.x)||!isFinite(m.y)||!isFinite(m.hp)){bad.push('monster NaN '+m.kind);break}
  const modalOpen=!document.getElementById('modal').classList.contains('hide');if(PAUSE&&!modalOpen&&!DLG&&!(FISHING.on&&FISHING.st==='reel'))bad.push('stuck pause');
  if(document.querySelectorAll('#modal').length!==1)bad.push('modal dup');return bad})()"""
ACTIONS=["tap","tap","tap","tap","bag","map","book","set","stats","board","wheel","quiz","goto","goto","fish","skill","dlg","close","close","back"]
MAPS=['plaza','home','market','lake','mountain','cave1','cave2','cave3','room','dream1','dream2']
async def main(age,secs,seed):
    random.seed(seed)
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click(f'#ca button[data-a="{age}"]');await pg.click('#cgo');await pg.wait_for_timeout(1500)
        await pg.evaluate("window.confirm=()=>true;GAME.S.coins=3000;GAME.S.lv="+("15" if age>=12 else "5")+";GAME.S.boss=true")
        found={};n=0;import time;t0=time.time()
        while time.time()-t0<secs:
            a=random.choice(ACTIONS);n+=1
            try:
                if a=="tap": await pg.touchscreen.tap(random.randint(20,824),random.randint(60,370))
                elif a in ("bag","map","book","set","stats"):
                    b={"bag":"#bBag","map":"#bMap","book":"#bBook","set":"#bSet","stats":"#bStat"}[a]
                    if await pg.evaluate(f"!document.querySelector('{b}').classList.contains('hide')&&document.getElementById('modal').classList.contains('hide')&&!DLG"): await pg.click(b)
                elif a=="board": await pg.evaluate("if(document.getElementById('modal').classList.contains('hide')&&!DLG)openBoard()")
                elif a=="wheel": await pg.evaluate("if(document.getElementById('modal').classList.contains('hide')&&!DLG)openWheel()")
                elif a=="quiz":
                    bs=await pg.query_selector_all('#mBody .ch button:not([disabled]), #mBody .it, #mBody [data-i]:not([disabled])')
                    if bs: await random.choice(bs).click()
                elif a=="goto": m=random.choice(MAPS);await pg.evaluate(f"if(document.getElementById('modal').classList.contains('hide')&&!DLG)GAME.goMap('{m}')")
                elif a=="fish": await pg.evaluate("if(GAME.M.fishSpot){GAME.P.x=GAME.M.fishSpot.x;GAME.P.y=GAME.M.fishSpot.y;fishAct()}")
                elif a=="skill": await pg.evaluate("if(!PAUSE){useSkill()}")
                elif a=="dlg": await pg.evaluate("if(DLG)nextLine()")
                elif a in ("close","back"): await pg.evaluate("if(!DLG&&!document.getElementById('modal').classList.contains('hide')&&document.getElementById('mX'))closeModal()")
            except Exception as e: found.setdefault('action error '+a,0);found['action error '+a]+=1
            await pg.wait_for_timeout(random.randint(80,400))
            if n%5==0:
                for b in await pg.evaluate(CHECK): found[b]=found.get(b,0)+1
        print('age',age,'seconds',secs,'actions',n,'| problems',json.dumps(found,ensure_ascii=False),'| page errors',len(errs),errs[:3]);await br.close()
asyncio.run(main(int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3])))
