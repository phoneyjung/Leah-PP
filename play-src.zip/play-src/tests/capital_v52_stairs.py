import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page()
        await pg.goto('file:///home/claude/play/play-preview.html');await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;goMap('capital')");await pg.wait_for_timeout(1200)
        # every walk that changes terrace must pass over a stair or bridge tile (no climbing a stone face)
        r=await pg.evaluate("""(()=>{const m=GAME.M,T=32;const tiers=(x,y)=>y;const pairs=[[[20,56],[20,15]],[[70,56],[80,14]],[[88,50],[60,16]],[[8,50],[40,16]],[[48,60],[48,4]],[[30,33],[12,15]],[[70,33],[88,56]]];
          return pairs.map(([a,b])=>{const p=GAME.findPath(m,a[0]*T+16,a[1]*T+16,b[0]*T+16,b[1]*T+16);if(!p)return 'no path';let len=0,prev=[a[0]*T+16,a[1]*T+16];for(const q of p){const Q=Array.isArray(q)?q:[q.x,q.y];len+=Math.hypot(Q[0]-prev[0],Q[1]-prev[1]);prev=Q}
            return a+'→'+b+' '+Math.round(len/32)+' tiles (straight '+Math.round(Math.hypot(a[0]-b[0],a[1]-b[1]))+')'})})()""")
        for x in r:print(x)
        await br.close()
asyncio.run(main())
