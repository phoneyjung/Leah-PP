import json,glob,re,collections,sys
QS=[]
for f in sorted(glob.glob(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(__file__)),'..','..','q-*.json'))):
    d=json.load(open(f,encoding='utf-8'))
    for q in d['questions']:q['_f']=f.split('/')[-1];QS.append(q)
issues=collections.defaultdict(list)
TH=re.compile(r'[\u0E00-\u0E7F]');LAT=re.compile(r'[A-Za-z]{3,}')
def num(s):
    s=s.replace(',','').strip()
    try:return float(s)
    except:return None
for q in QS:
    qid=q['id'];a=q['answer']
    for L in ['th','en']:
        x=q.get(L)
        if not x:issues['missing_lang'].append((qid,L));continue
        ch=x['choices']
        if not(0<=a<len(ch)):issues['answer_out_of_range'].append((qid,L))
        if len(set(c.strip() for c in ch))<len(ch):issues['duplicate_choices'].append((qid,L,ch))
        if any(not c.strip() for c in ch):issues['empty_choice'].append((qid,L))
        if L=='en' and TH.search(x['q']+''.join(ch)) and q['subject']!='thai':issues['thai_in_en'].append((qid,x['q'][:60]))
        if not x.get('explain'):issues['no_explain'].append((qid,L))
    if q.get('th') and q.get('en') and len(q['th']['choices'])!=len(q['en']['choices']):issues['choice_count_mismatch'].append(qid)
    # math: the numbers in the choices should match between languages and the arithmetic must be right
    if q['subject']=='math':
        th,en=q['th'],q['en']
        if [num(c) for c in th['choices']]!=[num(c) for c in en['choices']] and all(num(c) is not None for c in th['choices']):issues['math_choices_differ'].append(qid)
        m=re.fullmatch(r'\s*(\d+)\s*([+\-×x*÷/])\s*(\d+)\s*=\s*\?\s*',th['q'])
        if m:
            A,op,B=int(m.group(1)),m.group(2),int(m.group(3))
            val={'+':A+B,'-':A-B,'×':A*B,'x':A*B,'*':A*B,'÷':A/B if B else None,'/':A/B if B else None}[op]
            got=num(th['choices'][q['answer']])
            if got is None or val is None or abs(got-val)>1e-9:issues['MATH_WRONG'].append((qid,th['q'],th['choices'],q['answer'],val))
            if sum(1 for c in th['choices'] if num(c)==val)>1:issues['MATH_TWO_CORRECT'].append(qid)
        m2=re.fullmatch(r'\s*(\d+)\s*([+\-])\s*\?\s*=\s*(\d+)\s*',th['q']) or re.fullmatch(r'\s*\?\s*([+\-])\s*(\d+)\s*=\s*(\d+)\s*',th['q'])
        # explanation should mention the correct answer, not another choice
        cor=th['choices'][q['answer']].strip()
        if cor and re.search(r'\d',cor) and cor not in th['explain']:
            others=[c for i,c in enumerate(th['choices']) if i!=q['answer'] and c.strip() and c.strip() in th['explain']]
            if others:issues['explain_mentions_wrong_choice'].append((qid,th['q'][:50],cor,others,th['explain'][:80]))
    if q['th']['choices'][q['answer']].strip() in ('ทั้งหมด','ถูกทุกข้อ','ไม่มีข้อใดถูก'):issues['all_of_above_style'].append(qid)
    if q['age']<=6 and len(q['th']['q'])>90:issues['long_for_age6'].append((qid,len(q['th']['q'])))
    if max(len(c) for c in q['th']['choices'])>40:issues['long_choice'].append((qid,max(q['th']['choices'],key=len)))
# duplicates and answer-position bias
dups=collections.Counter((q['_f'],q['th']['q'].strip()) for q in QS);issues['duplicate_question']=[k for k,v in dups.items() if v>1]
pos=collections.defaultdict(collections.Counter)
for q in QS:pos[q['_f']][q['answer']]+=1
print('questions',len(QS))
for k,v in issues.items():
    if v:print(f'## {k}: {len(v)}');[print('   ',x) for x in v[:6]]
print('## answer position share (A/B/C/D) per file');[print('   ',f,dict(sorted(c.items()))) for f,c in pos.items()]
