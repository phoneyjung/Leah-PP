import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();ctx=await br.new_context(viewport={'width':844,'height':390},device_scale_factor=3,is_mobile=True,has_touch=True);pg=await ctx.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(''+URL+'?capital');await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800)
        await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(4000)
        print('new player with ?capital lands on:',await pg.evaluate("GAME.M.id"),'| dialog open:',await pg.evaluate("!!DLG"))
        for _ in range(6):
            if not await pg.evaluate("!!DLG"):break
            await pg.click('#dlg');await pg.wait_for_timeout(300)
        x0=await pg.evaluate("GAME.P.x");r=await pg.evaluate("(()=>({x:(GAME.P.x+150-camX)*SC/(devicePixelRatio||1),y:(GAME.P.y-camY)*SC/(devicePixelRatio||1)}))()")
        await pg.touchscreen.tap(r['x'],r['y']);await pg.wait_for_timeout(2500);print('tap ground after closing dialogs: moved',round(await pg.evaluate("GAME.P.x")-x0),'px')
        await pg.evaluate("GAME.save&&GAME.save()");await pg.wait_for_timeout(300)
        await pg.goto(''+URL+'');await pg.wait_for_timeout(3500);print('normal link afterwards lands on:',await pg.evaluate("GAME.M.id"))
        await pg.goto(''+URL+'?capital');await pg.wait_for_timeout(3500);print('?capital link again lands on:',await pg.evaluate("GAME.M.id"))
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
