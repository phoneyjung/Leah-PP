import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1,L3boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        for mid in ['cave3','forest2']:
            await pg.evaluate(f"setChap(3);goMap('{mid}','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
            r=await pg.evaluate("""new Promise(res=>{const kc=kidCrystals();const b=GAME.M.boss;const s=GAME.M.spawnDefault;const reach=kc.map(c=>!!GAME.findPath(GAME.M,s[0],s[1],c.x,c.y));kc.forEach(c=>c.awake=true);GAME.P.x=b.x-40;GAME.P.y=b.y;setTimeout(()=>res({kidCrystals:kc.length,reachable:reach,bossHappy:!!b.happy,sBoss:!!S.boss,chap:chap(),goal:document.getElementById('goal').textContent}),1500)})""")
            print(mid,r);await pg.evaluate("while(DLG)nextLine();closeModal&&closeModal()");await pg.wait_for_timeout(300)
        # adults cannot use them
        await pg.evaluate("S.age=30;goMap('desert2','up')");await pg.wait_for_timeout(1000);await pg.evaluate("while(DLG)nextLine()")
        r=await pg.evaluate("(()=>{const c=kidCrystals()[0];openQuiz(c);return{kidOnlyBlockedForAdult:!document.querySelector('.ch'),msg:document.getElementById('msg').textContent}})()")
        print('adult on kid crystal',r,'errors',errs[:3]);await br.close()
asyncio.run(main())
