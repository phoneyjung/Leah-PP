import asyncio,re,json
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','src','65_more.js'),encoding='utf-8').read()
KEYS=sorted(set(re.findall(r"t\('([A-Za-z0-9_]+)'\)",src))-{'2d'})
HUD="""(()=>{const bs=[...document.querySelectorAll('button')].filter(b=>{const r=b.getBoundingClientRect();const st=getComputedStyle(b);return r.width>0&&r.height>0&&st.display!=='none'&&st.visibility!=='hidden'&&!b.closest('#modal')&&!b.closest('.modal')&&!b.closest('#cr')&&!b.closest('#pk')});
  const R=bs.map(b=>[b.id||b.textContent.trim().slice(0,5),b.getBoundingClientRect()]);let over=[];for(let i=0;i<R.length;i++)for(let j=i+1;j<R.length;j++){const a=R[i][1],c=R[j][1];if(a.left<c.right-2&&c.left<a.right-2&&a.top<c.bottom-2&&c.top<a.bottom-2)over.push(R[i][0]+'x'+R[j][0])}return{n:R.length,ids:R.map(x=>x[0]).join(' '),over}})()"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();errs=[]
        pg=await (await br.new_context(viewport={'width':740,'height':360})).new_page();pg.on('pageerror',lambda e:errs.append(str(e)[:120]))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800)
        miss=await pg.evaluate(f"(()=>{{const k={json.dumps(KEYS)};return{{th:k.filter(x=>!TX.th[x]),en:k.filter(x=>!TX.en[x])}}}})()")
        print('missing text keys:',miss)
        await pg.click('#ca button[data-a="7"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};for(let n=2;n<=10;n++)GAME.S.seen['rank'+n]=1;DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide')")
        for r in [1,3,6,10]:
            await pg.evaluate(f"S.rank={r};hud()");await pg.wait_for_timeout(250);h=await pg.evaluate(HUD);print(f'kid class {r}: {h["n"]} buttons [{h["ids"]}] overlap {h["over"]}')
        await pg.goto(URL.replace('?rank=1',''));await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1300)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=30;S.job='sword';S.slots=['bash','guard'];S.learn=['bash','guard'];S.potions=3;goMap('lake','n')");await pg.wait_for_timeout(900)
        await pg.evaluate("GAME.P.x=GAME.M.fishSpot.x;GAME.P.y=GAME.M.fishSpot.y;hud()");await pg.wait_for_timeout(300)
        h=await pg.evaluate(HUD);print(f'adult worst case 740x360: {h["n"]} buttons overlap {h["over"]}')
        await pg.screenshot(path='/home/claude/chunks/hud740.png')
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
