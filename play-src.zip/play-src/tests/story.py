import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390},device_scale_factor=2)).new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');GAME.S.lv=40")
        for th in ['forest','desert','ulake','sky']:
            for f in [1,2]:
                mid=f'{th}{f}'
                r=await pg.evaluate(f"""(()=>{{const m=getMap('{mid}');const s=m.spawnDefault;let free=0,ok=0;for(const k of m.FLOOR){{if(m.SOLID.has(k))continue;free++;const [x,y]=k.split(',').map(Number);if(GAME.findPath(m,s[0],s[1],x*32+16,y*32+16))ok++}}
                  return{{reach:ok+'/'+free,exits:m.exits.map(e=>e.id+'>'+e.to),crystals:m.crystals.length,boss:!!m.bossSpawn,themed:!!m._themed,bright:!!m.bright,land:m.land,floor:m.floor}}}})()""")
                print(mid,r)
        # warp menu: locked before chapter 3
        await pg.evaluate("GAME.S.chap=1;openWarp()");await pg.wait_for_timeout(200)
        print('lands in warp (chap1):',await pg.evaluate("[...document.querySelectorAll('[data-land]')].map(b=>b.dataset.land+(b.disabled?'🔒':''))"))
        await pg.evaluate("closeModal();setChap(3);openWarp()");await pg.wait_for_timeout(200)
        print('lands in warp (chap3):',await pg.evaluate("[...document.querySelectorAll('[data-land]')].map(b=>b.dataset.land+(b.disabled?'🔒':''))"))
        await pg.click('[data-land="forest1"]');await pg.wait_for_timeout(1500)
        print('in',await pg.evaluate("GAME.M.id"),'scene playing:',await pg.evaluate("!!DLG&&DLG.lines[0][1]"))
        await pg.screenshot(path='/home/claude/chunks/forest.png')
        await pg.evaluate("while(DLG)nextLine()")
        # each land: go to boss floor, calm boss, check chapter + win scene
        for th,L in [('forest',3),('desert',4),('ulake',5),('sky',6)]:
            await pg.evaluate(f"GAME.goMap('{th}2','up')");await pg.wait_for_timeout(1300)
            await pg.evaluate("while(DLG)nextLine()")
            await pg.evaluate("GAME.M.boss.hp=1;GAME.M.boss.hitByMe=1;monHit(GAME.M.boss,999)")
            await pg.wait_for_timeout(2600)
            sc=await pg.evaluate("DLG?DLG.lines.map(l=>l[1]).join(','):'none'")
            await pg.evaluate("while(DLG)nextLine()");await pg.wait_for_timeout(400)
            print(th,'boss calmed -> chap',await pg.evaluate("chap()"),'| win scene',sc,'| town title',await pg.evaluate("t('town')"))
        print('ending seen',await pg.evaluate("!!GAME.S.ended"),'| credits open',await pg.evaluate("!!document.getElementById('crRoll')"))
        await pg.screenshot(path='/home/claude/chunks/credits.png')
        await pg.evaluate("closeModal();GAME.goMap('lake')");await pg.wait_for_timeout(800)
        print('coral cave exit:',await pg.evaluate("JSON.stringify(GAME.M.exits.find(e=>e.id==='cave'))"))
        for mid in ['desert1','sky1','ulake1']:
            await pg.evaluate(f"GAME.goMap('{mid}','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()");await pg.wait_for_timeout(300);await pg.screenshot(path=f'/home/claude/chunks/{mid}.png')
        print('errors',errs[:3]);await br.close()
asyncio.run(main())
