import asyncio
from playwright.async_api import async_playwright
import os
URL='file://'+os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','play-preview.html')
STRESS="""(mode)=>new Promise(res=>{let n=0,t0=performance.now(),worst=0,last=t0;const iv=setInterval(()=>{const mo=GAME.MONS.filter(o=>!o.happy)[0];if(!mo)return;if(mode.includes('hit'))monHit(mo,50,undefined,'staff');if(mode.includes('fire')){JCD.fire=0;useJob('fire')}},120);function f(){const now=performance.now();worst=Math.max(worst,now-last);last=now;n++;if(now-t0<2500)requestAnimationFrame(f);else{clearInterval(iv);res({fps:Math.round(n/2.5),worst:Math.round(worst),fx:FX.length})}}requestAnimationFrame(f)})"""
async def main():
    async with async_playwright() as p:
        br=await p.chromium.launch();pg=await (await br.new_context(viewport={'width':844,'height':390})).new_page()
        await pg.goto(URL);await pg.evaluate("localStorage.clear()");await pg.reload();await pg.wait_for_timeout(1800);await pg.click('#ca button[data-a="30"]');await pg.click('#cgo');await pg.wait_for_timeout(1200)
        await pg.evaluate("GAME.S.seen={intro:1,first:1,floor:1,boss:1,L3in:1};DLG=null;PAUSE=false;document.getElementById('dlg').classList.add('hide');S.lv=30;S.job='mage';S.learn=['fire','ice','bolt'];S.slots=['fire','bolt'];hud();goMap('forest1','up')");await pg.wait_for_timeout(1200);await pg.evaluate("while(DLG)nextLine()")
        await pg.evaluate("(()=>{const a=GAME.MONS[0];GAME.P.x=a.x-60;GAME.P.y=a.y;GAME.MONS.forEach(o=>{o.hp=o.max=1e6})})()")
        for mode in ['none','hit+fire']:
            await pg.evaluate("FX.length=0;TXT.length=0");await pg.wait_for_timeout(300)
            print(mode,await pg.evaluate(STRESS,mode))
        await pg.evaluate("FX.length=0")
        print('forest none again',await pg.evaluate(STRESS,'none'))
        await br.close()
asyncio.run(main())
